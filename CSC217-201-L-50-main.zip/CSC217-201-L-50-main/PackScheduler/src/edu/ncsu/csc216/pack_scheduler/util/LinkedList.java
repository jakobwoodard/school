/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.AbstractSequentialList;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * A custom linked list that doesn't allow for duplicates. Will be used with an iterator and will be responsible for the actions
 * within the FacultyDirectory
 * @author Jakob Woodard
 * @param <E> the general type that a list can hold
 */
public class LinkedList<E> extends AbstractSequentialList<E> {
	
	/** The size of the List */
	private int size;
	/** The front node of the list */
	private ListNode front;
	/** The back node of the list */
	private ListNode back;
	
	/**
	 * Constructor for a LinkedList. Sets the front node to a new ListNode and the back node to the front. Also sets the size to 0.
	 */
	public LinkedList() {
		this.front = new ListNode(null);
		this.back = new ListNode(null);
		front.next = back;
		back.prev = front;
		this.size = 0;
	}
	
	/**
	 * Creates a list iterator for use within the linked list
	 * @param index the index which the iterator is starting at
	 * @return creates and returns a new list iterator starting at the given index
	 */
	@Override
	public ListIterator<E> listIterator(int index) {
		return new LinkedListIterator(index);
	}

	/**
	 * Sets the element at the desired index to the desired element. Throws an IAE if the element already exists in the list
	 * @param index the index of the item being changed
	 * @param element the element which the user is replacing with
	 * @return the element that was just set to
	 * @throws IllegalArgumentException if the element being added is a duplicate
	 */
	@Override
	public E set(int index, E element) {
		if (contains(element)) {
			throw new IllegalArgumentException("Element already exists");
		}
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		if (index == 0 && size() == 0) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		return super.set(index, element);
	}

	/**
	 * Adds an element to the list at the given index. Throws an IAE if the element already exists in the list
	 * @param index the index being added at
	 * @param element the element being added
	 * @throws IllegalArgumentException if the element being added is a duplicate
	 */
	@Override
	public void add(int index, E element) {
		if (contains(element)) {
			throw new IllegalArgumentException("Element already exists");
		}
		super.add(index, element);
		
	}

	/**
	 * Returns the size of the list
	 * @return size the amount of elements in the list
	 */
	@Override
	public int size() {
		return size;
	}

	@Override
	public E get(int index) {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		return super.get(index);
	}

	@Override
	public E remove(int index) {
		if (size() == 0) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		return super.remove(index);
	}



	/** 
	 * ListNode class that is used to create list nodes which will be used to create a linked list
	 * @author Jakob Woodard
	 *
	 */
	private class ListNode {
		
		/** The data stored in the ListNode */
		public E data;
		/** The next list node */
		public ListNode next;
		/** The previous list node */
		public ListNode prev;
		
		/** Generic constructor for the list node, uses just an element to be added
		 * @param data the element to be added to the list
		 */
		public ListNode(E data) {
			this.data = data;
		}
		/**
		 * Constructor for ListNode that uses an element, as well as the previous and next list nodes in the list
		 * @param data the element to be added
		 * @param prev the previous list node
		 * @param next the next list node
		 */
		public ListNode(E data, ListNode prev, ListNode next) {
			this.data = data;
			this.prev = prev;
			this.next = next;
		}
	}
	
	/**
	 * Iterator created specifically for the LinkedList. Since it is an iterator, this class implements the ListIterator interface
	 * @author Jakob Woodard
	 *
	 */
	private class LinkedListIterator implements ListIterator<E> {
		
		/** Represents the ListNode that would be returned on a call to previous() */
		public ListNode previous;
		/** Represents the ListNode that would be returned on a call to next() */
		public ListNode next;
		/** The index that would be returned on a call to previousIndex() */
		public int previousIndex;
		/** The index that would be returned on a call to nextIndex() */
		public int nextIndex;
		/** Represents the ListNode that was returned on the last call to either previous() or next()
		 *  or null if a call to previous() or next() was not the last call on the ListIterator.
		 */
		private ListNode lastRetrieved;
		
		/**
		 * Creates a new list iterator at the given index. If the index is not valid, an IOOB Exception is thrown.
		 * @param index the index which the iterator is starting at
		 * @throws IndexOutOfBoundsException if the index is less than 0 or greater than the size of the list
		 */
		public LinkedListIterator(int index) {
			if (index < 0 || index > size()) {
				throw new IndexOutOfBoundsException("Invalid index");
			}
			this.previous = front;
			this.next = front.next;
			this.previousIndex = -1;
			this.nextIndex = 1;
			lastRetrieved = null;
			if (size != 0) {
				for (int i = 0; i < index; i++) {
				next();
				}
			}
			
		}

		/**
		 * Returns whether or not there is another element in the list
		 * @return true if there is another element in the list
		 */
		@Override
		public boolean hasNext() {
			return next != null;
		}

		/**
		 * Returns the value of the "next" node in a list. Throws a NoSuchElementException if there is not another element
		 * @return the value of the next node
		 * @throws NoSuchElementException if the next node has null for its data
		 */
		@Override
		public E next() {
			E value = null;
			if (!hasNext()) {
				throw new NoSuchElementException("The next element is null");
			}
			lastRetrieved = next;
			value = next.data;
			next = next.next;
			nextIndex++;
			previous = previous.next;
			previousIndex++;
			return value;
		}


		/**
		 * Returns whether or not there is a previous value in the list
		 * @return true if there is a previous value
		 */
		@Override
		public boolean hasPrevious() {
			return previous != null;
		}


		/**
		 * Returns the value of the previous element in a list. Throws a NSEE if the previous element is null
		 * @return the value of the previous node
		 * @throws NoSuchElementException if the previous element is null
		 */
		@Override
		public E previous() {
			E value = null;
			if (!hasPrevious()) {
				throw new NoSuchElementException("The previous element is null");
			}
			lastRetrieved = previous;
			value = previous.data;
			next = next.prev;
			nextIndex--;
			previous = previous.prev;
			previousIndex--;
			return value;
			
		}

		/**
		 * Returns the index of the next element
		 */
		@Override
		public int nextIndex() {
			return nextIndex;
		}

		/**
		 * Returns the index of the previous element
		 */
		@Override
		public int previousIndex() {
			return previousIndex;
		}

		/**
		 * Removes the return value of either next() or previous() depending on which was called most recently. If remove() or add()
		 * was the most recent call, throws an IllegalStateException.
		 * @throws IllegalStateException if the last retrieved element is null
		 */
		@Override
		public void remove() {
			if (lastRetrieved == null) {
				throw new IllegalStateException();
			}
			previous = lastRetrieved.prev;
			previous.next = next;
			size--;
			lastRetrieved = null;
			
		}

		/**
		 * Sets the value of either next() or previous(). If the provided element is null, a NPE is thrown. If the last 
		 * retrieved element is null, throws an IllegalStateException.
		 * @param e the element which is being set to
		 * @throws NullPointerException if the value trying to be set to is null
		 * @throws IllegalStateException if the last retrieved element is null
		 */
		@Override
		public void set(E e) {
			if (lastRetrieved == null) {
				throw new IllegalStateException();
			}
			if (e == null) {
				throw new NullPointerException("Element cannot be null");
			}
			if (next == lastRetrieved) {
				next.data = e;
			}
			if (previous == lastRetrieved) {
				previous.data = e;
			}
			
		}


		/**
		 * Adds an element at the point of the iterator. If the element attempting to be added is null, a NPE is thrown
		 * @param e the element being added
		 * @throws NullPointerException if the value being added is null
		 */
		@Override
		public void add(E e) {
			if (e == null) {
				throw new NullPointerException("Element cannot be null");
			}
			previous.next = new ListNode(e, previous, next);
			lastRetrieved = null;
			size++;
		}
	}

	

	
}
