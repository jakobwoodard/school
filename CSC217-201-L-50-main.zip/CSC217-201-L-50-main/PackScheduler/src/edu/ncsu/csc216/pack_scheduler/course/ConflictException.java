/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Class to create a custom exception if there is a scheduling conflict between Activities
 * @author Jakob Woodard
 *
 */
public class ConflictException extends Exception {

	/** ID used for serialization. */
	private static final long serialVersionUID = 1L;
	/**
	 * Constructor for ConflictException, passes the given message onto the parent class
	 * @param message the message to be passed to the parent class
	 */
	public ConflictException(String message) {
		super(message);
	}
	/**
	 * Constructor for the ConflicException. Gives the specified message "Schedule conflict." when there is 
	 * a schedule conflict.
	 */
	public ConflictException() {
		this("Schedule conflict.");
	}
}
