/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for LinkedListRecursive
 * @author Jakob Woodard
 *
 */
public class LinkedListRecursiveTest {

	/**
	 * Test method for linkedListRecursive()
	 */
	@Test
	public void testLinkedList() {
		LinkedListRecursive<String> list = new LinkedListRecursive<String>();
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		list.add(8, "Middle");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Middle", list.get(8));
		assertEquals("Eight", list.get(9));
		assertEquals("Nine", list.get(10));
		
		//Invalid get to avoid writing new test
		try {
			list.get(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.get(100);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
	}

	/**
	 * Test method for add()
	 */
	@Test
	public void testAddIntE() {
		LinkedListRecursive<String> list = new LinkedListRecursive<String>();
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		
		assertTrue(list.contains("Nine"));
		assertFalse(list.contains("Different"));
		assertFalse(list.contains(null));
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		//Testing that the capacity of the list is properly increased
		list.add(10, "Ten");
		//Testing adding in the middle
		list.add(8, "Test");
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Test", list.get(8));
		assertEquals("Eight", list.get(9));
		assertEquals("Nine", list.get(10));
		assertEquals("Ten", list.get(11));
		//Adding at the end
		list.add(list.size(), "Last");
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Test", list.get(8));
		assertEquals("Eight", list.get(9));
		assertEquals("Nine", list.get(10));
		assertEquals("Ten", list.get(11));
		assertEquals("Last", list.get(list.size() - 1));
		
		try {
			list.add(10, "Zero");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Duplicate element", e.getMessage());
		}
		
		try {
			list.add(-1, "New");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.add(15, "New");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.add(10, null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals("Null element", e.getMessage());
		}

	}
	
	/**
	 * Test method for add()
	 */
	@Test
	public void testAddE() {
		LinkedListRecursive<String> list = new LinkedListRecursive<String>();
		assertEquals(0, list.size());
		
		//Adding 10 elements
				list.add("Zero");
				list.add("One");
				list.add("Two");
				list.add("Three");
				list.add("Four");
				list.add("Five");
				list.add("Six");
				list.add("Seven");
				list.add("Eight");
				list.add("Nine");
				
				assertTrue(list.contains("Nine"));
				assertFalse(list.contains("Different"));
				assertFalse(list.contains(null));
				//Asserting that all values are where they should be
				assertEquals("Zero", list.get(0));
				assertEquals("One", list.get(1));
				assertEquals("Two", list.get(2));
				assertEquals("Three", list.get(3));
				assertEquals("Four", list.get(4));
				assertEquals("Five", list.get(5));
				assertEquals("Six", list.get(6));
				assertEquals("Seven", list.get(7));
				assertEquals("Eight", list.get(8));
				assertEquals("Nine", list.get(9));
				assertEquals(10, list.size());
				
				list.add("Ten");
	}

	/**
	 * Test method for set()
	 */
	@Test
	public void testSetIntE1() {
		LinkedListRecursive<String> list = new LinkedListRecursive<String>();
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		list.set(0, "0");
		assertEquals("0", list.get(0));
		
		list.set(3, "3");
		assertEquals("3", list.get(3));
		
		
		try {
			list.set(5, "Nine");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Duplicate element", e.getMessage());
		}
		try {
			list.set(4, null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals("Null element", e.getMessage());
		}
		
		try {
			list.set(-1, "new");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.set(15, "new");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
	}

	/**
	 * Test method for remove()
	 */
	@Test
	public void testRemoveInt() {
		LinkedListRecursive<String> list = new LinkedListRecursive<String>();
		assertEquals(0, list.size());
		
		assertFalse(list.remove("new"));
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		list.remove(9);
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		
		list.remove(4);
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Five", list.get(4));
		assertEquals("Six", list.get(5));
		assertEquals("Seven", list.get(6));
		assertEquals("Eight", list.get(7));
		
		list.remove(0);
		assertEquals("One", list.get(0));
		assertEquals("Two", list.get(1));
		assertEquals("Three", list.get(2));
		assertEquals("Five", list.get(3));
		assertEquals("Six", list.get(4));
		assertEquals("Seven", list.get(5));
		assertEquals("Eight", list.get(6));
		
		assertFalse(list.remove(null));
		
		try {
			list.remove(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.remove(15);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		
		
	}
	
	
	/**
	 * Test method for remove(E)
	 */
	@Test
	public void testRemoveE() {
		LinkedListRecursive<String> list = new LinkedListRecursive<String>();
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		list.remove("Nine");
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		
		list.remove("Four");
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Five", list.get(4));
		assertEquals("Six", list.get(5));
		assertEquals("Seven", list.get(6));
		assertEquals("Eight", list.get(7));
		
		list.remove("Zero");
		assertEquals("One", list.get(0));
		assertEquals("Two", list.get(1));
		assertEquals("Three", list.get(2));
		assertEquals("Five", list.get(3));
		assertEquals("Six", list.get(4));
		assertEquals("Seven", list.get(5));
		assertEquals("Eight", list.get(6));
		
		assertEquals(7, list.size());
	}

}
