/**
 * 
 */
package edu.ncsu.csc216.hloj.model.lists;

import java.util.AbstractList;

/**
 * A generic class that extends AbstractList, but it does not allow duplicate elements.
 * It will be used by the classes in the edu.ncsu.csc216.hloj.model.io package
 * @author Jakob Woodard
 * @param <E> generic type that the list can hold
 *
 */
public class UniqueList<E> extends AbstractList<E> {
	
	/** Initial capacity of a created UniquList */
	private static final int INIT_CAPACITY = 10;
	/** Instance of the list */
	private E[] list;
	/** Size of the UniqueList */
	private int size;
	
	
	/**
	 * Constructor of the UniqueList, initially the capacity is 10
	 */
	@SuppressWarnings("unchecked")
	public UniqueList() {
		list = (E[]) new Object[INIT_CAPACITY];
		this.size = 0;
	}
	
	/**
	 * Constructor of the UniqueList with the capacity being set to whatever value is passed
	 * @param capacity of the new list
	 */
	@SuppressWarnings("unchecked")
	public UniqueList(int capacity) {
		if (capacity == 0) {
			throw new IllegalArgumentException("Capacity cannot be 0");
		}
		list = (E[]) new Object[capacity];
		this.size = 0;
	}
	
	/**
	 * Attempts to add an element to the list and returns true if it does.
	 * @param element the element attempting to be added
	 * @return true if the element could be added, false if not.
	 * @throws NullPointerException if the element is null
	 * @throws IllegalArgumentException if the element already exists in the list
	 */
	@Override
	public boolean add(E element) {
		
		boolean isAdded = false;
		
		if (element == null) {
			throw new NullPointerException("Element is null");
		}
		if (list[size()] == null) {
			add(size(), element);
		}
		for (int i = 0; i < size(); i++) {
			if (list[i].equals(element)) {
				isAdded = true;
			}
		}	
		return isAdded;
		
	}
	
	/**
	 * Attempts to add an element to the list.
	 * @param element the element attempting to be added
	 * @throws NullPointerException if the element is null
	 * @throws IllegalArgumentException if the element already exists in the list
	 * @throws IndexOutOfBoundsException if the index is invalid
	 */
	@Override
	public void add(int index, E element) {
		if (element == null) {
			throw new NullPointerException("Element is null");
		}
		validateIndex(index);
		if (list.length == size()) {
			increaseCapacity();
		}
		if (size() == 0) {
			list[0] = element;
			size++;
		}
		else {
			for (int i = 0; i < size; i++) {
				if (element.equals(list[i])) {
					throw new IllegalArgumentException("Element already exists");
				}
			}
			for (int i = size - 1; i >= index; i--) {
				list[i + 1] = list[i];
			}
			list[index] = element;
			size++;
		}
		
	}
	
	/**
	 * Removes the element from the list at the given index and shifts the rest of the list to fit.
	 * @param index index to be removed
	 * @return the value being removed
	 * @throws IndexOutOfBoundsException if the index is invalid
	 */
	@Override
	public E remove(int index) {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Index of " + index + " is out of bounds for size " + size);
		}
		E value = list[index];
		for (int i = index; i < size - 1; i++) {
			list[i] = list[i + 1];
		}
		list[size - 1] = null;
		size--;
		return value;
		
	}
	
	/**
	 * Gets the value of an item at the specified index
	 * @param index of the wanted element
	 * @throws IndexOutOfBoundsException if the index is invalid
	 */
	@Override
	public E get(int index) {
		if (index < 0 || index > size() - 1) {
			throw new IndexOutOfBoundsException("Index of " + index + " is out of bounds for size " + size);
		}
		return list[index];
		
	}
	
	/**
	 * Gets the current size of the list
	 * @return size of the list
	 */
	@Override
	public int size() {
		return size;
	}
	
	/**
	 * Validates that the given index is correct
	 * @param index to be validated
	 * @throws IndexOutOfBoundsException if the index is not valid
	 */
	private void validateIndex(int index) {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Index of " + index + " is out of bounds for size " + size);
		}
	}
	
	/**
	 * Method to increase the capacity of the list if necessary by creating a new list with double the capacity and 
	 * copying in the elements from the previous list.
	 */
	private void increaseCapacity() {
		@SuppressWarnings("unchecked")
		E[] list2 = (E[]) new Object[size * 2];
		for (int i = 0; i < size; i++) {
			list2[i] = list[i];
		}
		this.list = list2;
	}

}
