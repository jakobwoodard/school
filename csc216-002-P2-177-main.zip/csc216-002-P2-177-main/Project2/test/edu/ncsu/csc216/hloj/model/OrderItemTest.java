/**
 * 
 */
package edu.ncsu.csc216.hloj.model;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for OrderItem
 * @author Jakob Woodard
 *
 */
public class OrderItemTest {
	
	/** Type for testing */
	private static String type = "type";
	/** Name for testing */
	private static String name = "name";
	/** Price for testing */
	private static double price = 1.00;

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.OrderItem#OrderItem(edu.ncsu.csc216.hloj.model.MenuItem)}.
	 */
	@Test
	public void testOrderItem() {
		
		try {
			MenuItem m = new MenuItem(type, name, price);
			OrderItem o = new OrderItem(m);
			assertEquals(m, o.getMenuItem());
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.OrderItem#setQuantity(int)}.
	 */
	@Test
	public void testSetQuantity() {
		
		try {
			MenuItem m = new MenuItem(type, name, price);
			OrderItem o = new OrderItem(m);
			o.setQuantity(0);
			fail();
		}
		catch (ModelException e) {
			assertEquals("The quantity of an item in an order has to be greater than zero", e.getMessage());
		}
		
		try {
			MenuItem m = new MenuItem(type, name, price);
			OrderItem o = new OrderItem(m);
			o.setQuantity(2);
			assertEquals(2, o.getQuantity());
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.OrderItem#setMenuItem(edu.ncsu.csc216.hloj.model.MenuItem)}.
	 */
	@Test
	public void testSetMenuItem() {
		
		try {
			MenuItem m = new MenuItem(type, name, price);
			MenuItem m2 = new MenuItem("different", name, price);
			OrderItem o = new OrderItem(m);
			o.setMenuItem(m2);
			assertEquals(m2, o.getMenuItem());
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.OrderItem#compareTo(edu.ncsu.csc216.hloj.model.OrderItem)}.
	 */
	@Test
	public void testCompareTo() {
		
		try {
			MenuItem m = new MenuItem(type, name, price);
			MenuItem m2 = new MenuItem("different", name, price);
			OrderItem o = new OrderItem(m);
			OrderItem o2 = new OrderItem(m2);
			
			assertEquals(0, o.compareTo(o));
			assertEquals(1, o.compareTo(o2));
			assertEquals(-1, o2.compareTo(o));
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

}
