/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import java.util.EmptyStackException;

import org.junit.Test;

/**
 * Test cases for ArrayStack class
 * @author Jakob Woodard
 *
 */
public class ArrayStackTest {

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.util.ArrayStack#push(java.lang.Object)}.
	 */
	@Test
	public void testPushPop() {
		ArrayStack<String> ar = new ArrayStack<String>(0);
		
		assertTrue(ar.isEmpty());
		
		try {
			ar.push("Zero");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Stack is full", e.getMessage());
		}
		
		ar.setCapacity(10);
		ar.push("Zero");
		
		
		assertFalse(ar.isEmpty());
		assertEquals(1, ar.size());
		
		ar.push("One");
		ar.push("Two");
		ar.push("Three");
		assertEquals("Three", ar.pop());
		assertEquals("Two", ar.pop());
		assertEquals("One", ar.pop());
		assertEquals("Zero", ar.pop());
		
		try {
			ar.pop();
			fail();
		}
		catch (EmptyStackException e) {
			assertEquals(e.getMessage(), e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.util.ArrayStack#setCapacity(int)}.
	 */
	@Test
	public void testSetCapacity() {
		ArrayStack<String> ar = new ArrayStack<String>(0);
		ar.setCapacity(10);
		
		
		try {
			ar.setCapacity(-1);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid capacity", e.getMessage());
		}
		
		ar.push("One");
		ar.push("Two");
		ar.push("Three");
		
		try {
			ar.setCapacity(1);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid capacity", e.getMessage());
		}
		
	}

}
