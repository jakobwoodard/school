/**
 * 
 */
package edu.ncsu.csc216.hloj.model.io;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc216.hloj.model.manager.CustomerManager;

/**
 * Test cases for HLOJDataWriter
 * @author Jakob Woodard
 *
 */
public class HLOJDataWriterTest {
	
	/** Data file for testing */
	private final String testFile1 = "test-files/data1.txt";

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.io.HLOJDataWriter#writeData(java.lang.String)}.
	 */
	@Test
	public void testWriteData() {
		
		HLOJDataReader.readData(testFile1);
		HLOJDataWriter.writeData("test-files/data1_actual_output.txt");
		
		HLOJDataReader.readData("test-files/data1_actual_output.txt");
		assertEquals(3, CustomerManager.getInstance().getCustomers().length);
	}

}
