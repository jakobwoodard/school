package edu.ncsu.csc216.project_manager.model.manager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.util.Scanner;

import org.junit.Test;

import edu.ncsu.csc216.project_manager.model.command.Command;
import edu.ncsu.csc216.project_manager.model.user_story.UserStory;
/**
 * Test class for ProjectManager
 * @author Jakob Woodard
 *
 */
public class ProjectManagerTest {
	/** Testing value for title */
	private static final String TITLE = "title";
	/** Testing value for user */
	private static final String USER = "user";
	/** Testing value for action */
	private static final String ACTION = "action";
	/** Testing value for value */
	private static final String VALUE = "value";
	/** Testing priority for executing command */
	private static final String PRIORITY = "High";

	/**
	 * Tests the saveCurrentProjectToFile method
	 */
	@Test
	public void testSaveCurrentProjectToFile() {
		ProjectManager pm = ProjectManager.getInstance();
		
		//Invalid tests
		try {
			pm.saveCurrentProjectToFile("test-files/invalidfile.txt");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Current Project is null", e.getMessage());
		}
		
		//Getting a null array
		assertNull(pm.getUserStoriesAsArray());
		//Getting the null name of current project
		assertNull(pm.getProjectName());
		
		try {
			pm.createNewProject("New Project");
			pm.saveCurrentProjectToFile("test-files/invalidfile.txt");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("No UserStories in the Current Project", e.getMessage());
		}
		
		//Loading from invalid file
		try {
			pm.loadProjectsFromFile(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Unable to save file.", e.getMessage());
		}
		
		
		// Loading valid project
		pm.loadProjectsFromFile("test-files/project1.txt");
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("0", pm.getUserStoriesAsArray()[0][0]);
		assertEquals("Completed", pm.getUserStoriesAsArray()[0][1]);
		assertEquals("Load Catalog", pm.getUserStoriesAsArray()[0][2]);
		assertEquals("sesmith5", pm.getUserStoriesAsArray()[0][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("1", pm.getUserStoriesAsArray()[1][0]);
		assertEquals("Verifying", pm.getUserStoriesAsArray()[1][1]);
		assertEquals("Select Course", pm.getUserStoriesAsArray()[1][2]);
		assertEquals("jctetter", pm.getUserStoriesAsArray()[1][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("2", pm.getUserStoriesAsArray()[2][0]);
		assertEquals("Working", pm.getUserStoriesAsArray()[2][1]);
		assertEquals("Add Event", pm.getUserStoriesAsArray()[2][2]);
		assertEquals("ignacioxd", pm.getUserStoriesAsArray()[2][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("3", pm.getUserStoriesAsArray()[3][0]);
		assertEquals("Backlog", pm.getUserStoriesAsArray()[3][1]);
		assertEquals("Export Schedule", pm.getUserStoriesAsArray()[3][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[3][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("4", pm.getUserStoriesAsArray()[4][0]);
		assertEquals("Submitted", pm.getUserStoriesAsArray()[4][1]);
		assertEquals("Change Title", pm.getUserStoriesAsArray()[4][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[4][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("5", pm.getUserStoriesAsArray()[5][0]);
		assertEquals("Rejected", pm.getUserStoriesAsArray()[5][1]);
		assertEquals("Post to Piazza", pm.getUserStoriesAsArray()[5][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[5][3]);
		
		
		//Invalid save to file
		try {
			pm.saveCurrentProjectToFile(null);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Unable to save file.", e.getMessage());
		}
		//Saving to a file and manually checking
		pm.saveCurrentProjectToFile("test-files/project1_actual2.txt");
		
		
		//Resetting project manager so that other tests can use it
		pm.resetProjectManager();
		
	}
	

	/**
	 * Tests the getUserStoryById method
	 */
	@Test
	public void testGetUserStoryById() {
		// Loading valid project
		ProjectManager pm = ProjectManager.getInstance();
		//Creating UserStory to be tested for equality
		UserStory us = new UserStory(0, "Completed", "Load Catalog", "student", "load a course catalog file", "plan a schedule for next semester", 
				"High", "sesmith5", null);

		
		pm.loadProjectsFromFile("test-files/project1.txt");
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("0", pm.getUserStoriesAsArray()[0][0]);
		assertEquals("Completed", pm.getUserStoriesAsArray()[0][1]);
		assertEquals("Load Catalog", pm.getUserStoriesAsArray()[0][2]);
		assertEquals("sesmith5", pm.getUserStoriesAsArray()[0][3]);
		
		//Creating a Scanner to ensure that the outputs of the Stories are the same
		String expected = us.toString();
		String actual = pm.getUserStoryById(0).toString();
		Scanner exp = new Scanner(expected);
		Scanner act = new Scanner(actual);
		String expLine = exp.next();
		String actLine = act.next();
		assertEquals(expLine, actLine);
		expLine = exp.next();
		actLine = act.next();
		assertEquals(expLine, actLine);
		expLine = exp.next();
		actLine = act.next();
		assertEquals(expLine, actLine);
		expLine = exp.next();
		actLine = act.next();
		assertEquals(expLine, actLine);
		exp.close();
		act.close();
		
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("1", pm.getUserStoriesAsArray()[1][0]);
		assertEquals("Verifying", pm.getUserStoriesAsArray()[1][1]);
		assertEquals("Select Course", pm.getUserStoriesAsArray()[1][2]);
		assertEquals("jctetter", pm.getUserStoriesAsArray()[1][3]);
		
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("2", pm.getUserStoriesAsArray()[2][0]);
		assertEquals("Working", pm.getUserStoriesAsArray()[2][1]);
		assertEquals("Add Event", pm.getUserStoriesAsArray()[2][2]);
		assertEquals("ignacioxd", pm.getUserStoriesAsArray()[2][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("3", pm.getUserStoriesAsArray()[3][0]);
		assertEquals("Backlog", pm.getUserStoriesAsArray()[3][1]);
		assertEquals("Export Schedule", pm.getUserStoriesAsArray()[3][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[3][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("4", pm.getUserStoriesAsArray()[4][0]);
		assertEquals("Submitted", pm.getUserStoriesAsArray()[4][1]);
		assertEquals("Change Title", pm.getUserStoriesAsArray()[4][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[4][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("5", pm.getUserStoriesAsArray()[5][0]);
		assertEquals("Rejected", pm.getUserStoriesAsArray()[5][1]);
		assertEquals("Post to Piazza", pm.getUserStoriesAsArray()[5][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[5][3]);
		
		//Resetting for further testing
		pm.resetProjectManager();
	}

	/**
	 * Tests the executeCommand method
	 */
	@Test
	public void testExecuteCommand() {
		// Loading valid project
		ProjectManager pm = ProjectManager.getInstance();
		
		//Creating Commands to be used
		Command c1 = new Command(Command.CommandValue.BACKLOG, PRIORITY);
		
		pm.loadProjectsFromFile("test-files/project1.txt");
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("0", pm.getUserStoriesAsArray()[0][0]);
		assertEquals("Completed", pm.getUserStoriesAsArray()[0][1]);
		assertEquals("Load Catalog", pm.getUserStoriesAsArray()[0][2]);
		assertEquals("sesmith5", pm.getUserStoriesAsArray()[0][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("1", pm.getUserStoriesAsArray()[1][0]);
		assertEquals("Verifying", pm.getUserStoriesAsArray()[1][1]);
		assertEquals("Select Course", pm.getUserStoriesAsArray()[1][2]);
		assertEquals("jctetter", pm.getUserStoriesAsArray()[1][3]);
		
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("2", pm.getUserStoriesAsArray()[2][0]);
		assertEquals("Working", pm.getUserStoriesAsArray()[2][1]);
		assertEquals("Add Event", pm.getUserStoriesAsArray()[2][2]);
		assertEquals("ignacioxd", pm.getUserStoriesAsArray()[2][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("3", pm.getUserStoriesAsArray()[3][0]);
		assertEquals("Backlog", pm.getUserStoriesAsArray()[3][1]);
		assertEquals("Export Schedule", pm.getUserStoriesAsArray()[3][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[3][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("4", pm.getUserStoriesAsArray()[4][0]);
		assertEquals("Submitted", pm.getUserStoriesAsArray()[4][1]);
		assertEquals("Change Title", pm.getUserStoriesAsArray()[4][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[4][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("5", pm.getUserStoriesAsArray()[5][0]);
		assertEquals("Rejected", pm.getUserStoriesAsArray()[5][1]);
		assertEquals("Post to Piazza", pm.getUserStoriesAsArray()[5][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[5][3]);
		
		pm.executeCommand(4, c1);
		assertEquals("Backlog", pm.getUserStoriesAsArray()[4][1]);
		assertEquals("Change Title", pm.getUserStoriesAsArray()[4][2]);
		
		//Resetting for further testing
		pm.resetProjectManager();

	}

	/**
	 * Tests the deleteUserStoryById method
	 */
	@Test
	public void testDeleteUserStoryById() {
		// Loading valid project
		ProjectManager pm = ProjectManager.getInstance();
		
		pm.loadProjectsFromFile("test-files/project1.txt");
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("0", pm.getUserStoriesAsArray()[0][0]);
		assertEquals("Completed", pm.getUserStoriesAsArray()[0][1]);
		assertEquals("Load Catalog", pm.getUserStoriesAsArray()[0][2]);
		assertEquals("sesmith5", pm.getUserStoriesAsArray()[0][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("1", pm.getUserStoriesAsArray()[1][0]);
		assertEquals("Verifying", pm.getUserStoriesAsArray()[1][1]);
		assertEquals("Select Course", pm.getUserStoriesAsArray()[1][2]);
		assertEquals("jctetter", pm.getUserStoriesAsArray()[1][3]);
		
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("2", pm.getUserStoriesAsArray()[2][0]);
		assertEquals("Working", pm.getUserStoriesAsArray()[2][1]);
		assertEquals("Add Event", pm.getUserStoriesAsArray()[2][2]);
		assertEquals("ignacioxd", pm.getUserStoriesAsArray()[2][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("3", pm.getUserStoriesAsArray()[3][0]);
		assertEquals("Backlog", pm.getUserStoriesAsArray()[3][1]);
		assertEquals("Export Schedule", pm.getUserStoriesAsArray()[3][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[3][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("4", pm.getUserStoriesAsArray()[4][0]);
		assertEquals("Submitted", pm.getUserStoriesAsArray()[4][1]);
		assertEquals("Change Title", pm.getUserStoriesAsArray()[4][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[4][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("5", pm.getUserStoriesAsArray()[5][0]);
		assertEquals("Rejected", pm.getUserStoriesAsArray()[5][1]);
		assertEquals("Post to Piazza", pm.getUserStoriesAsArray()[5][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[5][3]);
		
		pm.deleteUserStoryById(0);
		assertEquals(5, pm.getUserStoriesAsArray().length);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("1", pm.getUserStoriesAsArray()[0][0]);
		assertEquals("Verifying", pm.getUserStoriesAsArray()[0][1]);
		assertEquals("Select Course", pm.getUserStoriesAsArray()[0][2]);
		assertEquals("jctetter", pm.getUserStoriesAsArray()[0][3]);
		
		//Resetting for further testing
		pm.resetProjectManager();
	}

	/**
	 * Tests the addUserStoryToProject method
	 */
	@Test
	public void testAddUserStoryToProject() {
		// Loading valid project
		ProjectManager pm = ProjectManager.getInstance();
		
		pm.loadProjectsFromFile("test-files/project1.txt");
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("0", pm.getUserStoriesAsArray()[0][0]);
		assertEquals("Completed", pm.getUserStoriesAsArray()[0][1]);
		assertEquals("Load Catalog", pm.getUserStoriesAsArray()[0][2]);
		assertEquals("sesmith5", pm.getUserStoriesAsArray()[0][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("1", pm.getUserStoriesAsArray()[1][0]);
		assertEquals("Verifying", pm.getUserStoriesAsArray()[1][1]);
		assertEquals("Select Course", pm.getUserStoriesAsArray()[1][2]);
		assertEquals("jctetter", pm.getUserStoriesAsArray()[1][3]);
		
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("2", pm.getUserStoriesAsArray()[2][0]);
		assertEquals("Working", pm.getUserStoriesAsArray()[2][1]);
		assertEquals("Add Event", pm.getUserStoriesAsArray()[2][2]);
		assertEquals("ignacioxd", pm.getUserStoriesAsArray()[2][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("3", pm.getUserStoriesAsArray()[3][0]);
		assertEquals("Backlog", pm.getUserStoriesAsArray()[3][1]);
		assertEquals("Export Schedule", pm.getUserStoriesAsArray()[3][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[3][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("4", pm.getUserStoriesAsArray()[4][0]);
		assertEquals("Submitted", pm.getUserStoriesAsArray()[4][1]);
		assertEquals("Change Title", pm.getUserStoriesAsArray()[4][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[4][3]);
		
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("5", pm.getUserStoriesAsArray()[5][0]);
		assertEquals("Rejected", pm.getUserStoriesAsArray()[5][1]);
		assertEquals("Post to Piazza", pm.getUserStoriesAsArray()[5][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[5][3]);
		
		//Adding a new Story to the project
		pm.addUserStoryToProject(TITLE, USER, ACTION, VALUE);
		assertEquals("WolfScheduler", pm.getProjectName());
		assertEquals("6", pm.getUserStoriesAsArray()[6][0]);
		assertEquals("Submitted", pm.getUserStoriesAsArray()[6][1]);
		assertEquals("title", pm.getUserStoriesAsArray()[6][2]);
		assertEquals(null, pm.getUserStoriesAsArray()[6][3]);
		
		//Resetting pm for further testing
		pm.resetProjectManager();
		
	}


	/**
	 * Tests getProjectList method
	 */
	@Test
	public void testGetProjectList() {
		ProjectManager pm = ProjectManager.getInstance();
		
		// Loading valid project
		pm.loadProjectsFromFile("test-files/project2.txt");
		
		assertEquals("WolfScheduler", pm.getProjectList()[0]);
		assertEquals("PackScheduler", pm.getProjectList()[1]);
	}


}
