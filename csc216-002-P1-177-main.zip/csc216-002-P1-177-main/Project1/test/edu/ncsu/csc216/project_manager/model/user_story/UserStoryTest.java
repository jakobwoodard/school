package edu.ncsu.csc216.project_manager.model.user_story;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.project_manager.model.command.Command;
/**
 * Tests for the UserStory class
 * @author Jakob Woodard
 *
 */
public class UserStoryTest {
	/** Example of a story title */
	private final String title = "title";
	/** Example of a story user */
	private final String user = "user";
	/** Example of a story action */
	private final String action = "action";
	/** Example of a story value */
	private final String value = "value";
	/** Valid story priority */
	private final String priority = "High";
	/** Valid story priority */
	private final String priority2 = "Medium";
	/** Valid story priority */
	private final String priority3 = "Low";
	/** Example of dev id for story */
	private final String developerId = "id";
	/** Valid rejection reason */
	private final String rejectionReason = "Duplicate";
	/** Valid rejection reason */
	private final String rejectionReason2 = "Inappropriate";
	/** Valid rejection reason */
	private final String rejectionReason3 = "Infeasible";

	/**
	 * Resets UserStory counter
	 * @throws Exception if there isn't a counter to be set
	 */
	@Before
	public void setUp() throws Exception {
		//Reset the counter at the beginning of every test.
		UserStory.setCounter(0);
	}
	
	/**
	 * Tests the UserStory constructor with some inputs
	 */
	@Test
	public void testUserStoryStringStringStringString() {
		//Creating valid UserStory
		UserStory us = new UserStory(title, user, action, value);
		assertEquals(us.getId(), 0);
		assertEquals(us.getState(), "Submitted");
		assertEquals(us.getPriority(), null);
		assertEquals(us.getDeveloperId(), null);
		assertEquals(us.getRejectionReason(), null);
		//Testing that by creating another story, the counter is incremented
		UserStory userStory = new UserStory("different", "different", "different", "different");
		assertEquals(userStory.getId(), 1);
		
		//Testing invalid cases
		//Title null or empty
		try {
			new UserStory (null, user, action, value);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid title", e.getMessage());
		}
		try {
			new UserStory ("", user, action, value);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid title", e.getMessage());
		}
		//User null or empty
		try {
			new UserStory (title, null, action, value);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid user", e.getMessage());
		}
		try {
			new UserStory (title, "", action, value);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid user", e.getMessage());
		}
		//Action null or empty
		try {
			new UserStory (title, user, null, value);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid action", e.getMessage());
		}
		try {
			new UserStory (title, user, "", value);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid action", e.getMessage());
		}
		//Value is null or empty
		try {
			new UserStory (title, user, action, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid value", e.getMessage());
		}
		try {
			new UserStory (title, user, action, "");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid value", e.getMessage());
		}
	}

	/**
	 * Tests the UserStory constructor with all inputs 
	 */
	@Test
	public void testUserStoryIntStringStringStringStringStringStringStringString() {
		//Creating valid User Story in Submitted state with null values where needed
		UserStory s1 = new UserStory(0, "Submitted", title, user, action, value, null, null, null);
		assertEquals("Submitted", s1.getState());
		assertEquals(title, s1.getTitle());
		assertEquals(user, s1.getUser());
		assertEquals(action, s1.getAction());
		assertEquals(value, s1.getValue());
		assertEquals(null, s1.getPriority());
		assertEquals(null, s1.getDeveloperId());
		assertEquals(null, s1.getRejectionReason());
		assertEquals(0, s1.getId());
		
		//Creating valid User Story in Submitted state with empty values where needed
		UserStory s2 = new UserStory(3, "Submitted", title, user, action, value, "", "", "");
		assertEquals("Submitted", s2.getState());
		assertEquals(title, s2.getTitle());
		assertEquals(user, s2.getUser());
		assertEquals(action, s2.getAction());
		assertEquals(value, s2.getValue());
		assertEquals(null, s2.getPriority());
		assertEquals(null, s2.getDeveloperId());
		assertEquals(null, s2.getRejectionReason());
		assertEquals(3, s2.getId());
		
		//Invalid id
		try {
			new UserStory(-1, "Submitted", title, user, action, value, null, null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid id", e.getMessage());
		}
		//Invalid state name
		try {
			new UserStory(0, "state", title, user, action, value, null, null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid state", e.getMessage());
		}
		
		//Invalid Submitted state
		//Priority not null/empty
		try {
			new UserStory(0, "Submitted", title, user, action, value, priority, null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		//DeveloperId not null/empty
		try {
			new UserStory(0, "Submitted", title, user, action, value, null, developerId, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid developer id", e.getMessage());
		}
		//Rejection reason not null/empty
		try {
			new UserStory(0, "Submitted", title, user, action, value, null, null, rejectionReason);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid rejection reason", e.getMessage());
		}
		
		//Valid Backlog state with null values where needed
		UserStory b1 = new UserStory(0, "Backlog", title, user, action, value, priority, null, null);
		assertEquals("Backlog", b1.getState());
		assertEquals(title, b1.getTitle());
		assertEquals(user, b1.getUser());
		assertEquals(action, b1.getAction());
		assertEquals(value, b1.getValue());
		assertEquals(priority, b1.getPriority());
		assertEquals(null, b1.getDeveloperId());
		assertEquals(null, b1.getRejectionReason());
		assertEquals(0, b1.getId());
		
		//Valid Backlog state with empty values where needed
		UserStory b2 = new UserStory(0, "Backlog", title, user, action, value, priority, "", "");
		assertEquals("Backlog", b2.getState());
		assertEquals(title, b2.getTitle());
		assertEquals(user, b2.getUser());
		assertEquals(action, b2.getAction());
		assertEquals(value, b2.getValue());
		assertEquals(priority, b2.getPriority());
		assertEquals(null, b2.getDeveloperId());
		assertEquals(null, b2.getRejectionReason());
		assertEquals(0, b2.getId());
		
		//Invalid Backlog state
		//Priority is null
		try {
			new UserStory(0, "Backlog", title, user, action, value, null, null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		//Priority is empty
		try {
			new UserStory(0, "Backlog", title, user, action, value, "", null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}

		//DeveloperId not null/empty
		try {
			new UserStory(0, "Backlog", title, user, action, value, priority, developerId, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid developer id", e.getMessage());
		}
		
		//Rejection reason not null/empty
		try {
			new UserStory(0, "Backlog", title, user, action, value, priority, null, rejectionReason);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid rejection reason", e.getMessage());
		}
		
		//Invalid priority string
		try {
			new UserStory(0, "Backlog", title, user, action, value, "priority", null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		
		//Valid Working state with null values where needed
		UserStory w1 = new UserStory(0, "Working", title, user, action, value, priority, developerId, null);
		assertEquals("Working", w1.getState());
		assertEquals(title, w1.getTitle());
		assertEquals(user, w1.getUser());
		assertEquals(action, w1.getAction());
		assertEquals(value, w1.getValue());
		assertEquals(priority, w1.getPriority());
		assertEquals(developerId, w1.getDeveloperId());
		assertEquals(null, w1.getRejectionReason());
		assertEquals(0, w1.getId());
		
		//Valid Working state with empty values where needed
		UserStory w2 = new UserStory(0, "Working", title, user, action, value, priority2, developerId, "");
		assertEquals("Working", w2.getState());
		assertEquals(title, w2.getTitle());
		assertEquals(user, w2.getUser());
		assertEquals(action, w2.getAction());
		assertEquals(value, w2.getValue());
		assertEquals(priority2, w2.getPriority());
		assertEquals(developerId, w2.getDeveloperId());
		assertEquals(null, w2.getRejectionReason());
		assertEquals(0, w2.getId());
		
		//Invalid Working states
		//Null priority
		try {
			new UserStory(0, "Working", title, user, action, value, null, developerId, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		//Priority is empty
		try {
			new UserStory(0, "Working", title, user, action, value, "", developerId, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		//Priority is invalid
		try {
			new UserStory(0, "Working", title, user, action, value, "priority", developerId, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		
		//Developer id is null
		try {
			new UserStory(0, "Working", title, user, action, value, priority, null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid developer id", e.getMessage());
		}
		//Developer id is empty
		try {
			new UserStory(0, "Working", title, user, action, value, priority, "", null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid developer id", e.getMessage());
		}
		
		//Rejection reason not null/empty
		try {
			new UserStory(0, "Working", title, user, action, value, priority, developerId, rejectionReason);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid rejection reason", e.getMessage());
		}
		
		//Valid Verifying state with null values where needed
		UserStory v1 = new UserStory(0, "Verifying", title, user, action, value, priority3, developerId, null);
		assertEquals("Verifying", v1.getState());
		assertEquals(title, v1.getTitle());
		assertEquals(user, v1.getUser());
		assertEquals(action, v1.getAction());
		assertEquals(value, v1.getValue());
		assertEquals(priority3, v1.getPriority());
		assertEquals(developerId, v1.getDeveloperId());
		assertEquals(null, v1.getRejectionReason());
		assertEquals(0, v1.getId());
		
		//Valid Verifying state with empty values where needed
		UserStory v2 = new UserStory(0, "Verifying", title, user, action, value, priority, developerId, "");
		assertEquals("Verifying", v2.getState());
		assertEquals(title, v2.getTitle());
		assertEquals(user, v2.getUser());
		assertEquals(action, v2.getAction());
		assertEquals(value, v2.getValue());
		assertEquals(priority, v2.getPriority());
		assertEquals(developerId, v2.getDeveloperId());
		assertEquals(null, v2.getRejectionReason());
		assertEquals(0, v2.getId());
		
		//Invalid Verifying states
		//Priority is null
		try {
			new UserStory(0, "Verifying", title, user, action, value, null, developerId, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		//Priority is empty
		try {
			new UserStory(0, "Verifying", title, user, action, value, "", developerId, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		
		//Developer id is null
		try {
			new UserStory(0, "Verifying", title, user, action, value, priority, null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid developer id", e.getMessage());
		}
		//Developer id is empty
		try {
			new UserStory(0, "Verifying", title, user, action, value, priority, "", null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid developer id", e.getMessage());
		}
		
		//Rejection reason not null/empty
		try {
			new UserStory(0, "Verifying", title, user, action, value, priority, developerId, rejectionReason);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid rejection reason", e.getMessage());
		}
		
		//Valid Completed state with null values where needed
		UserStory c1 = new UserStory(0, "Completed", title, user, action, value, priority, developerId, null);
		assertEquals("Completed", c1.getState());
		assertEquals(title, c1.getTitle());
		assertEquals(user, c1.getUser());
		assertEquals(action, c1.getAction());
		assertEquals(value, c1.getValue());
		assertEquals(priority, c1.getPriority());
		assertEquals(developerId, c1.getDeveloperId());
		assertEquals(null, c1.getRejectionReason());
		assertEquals(0, c1.getId());
		
		//Valid Verifying state with empty values where needed
		UserStory c2 = new UserStory(0, "Completed", title, user, action, value, priority, developerId, "");
		assertEquals("Completed", c2.getState());
		assertEquals(title, c2.getTitle());
		assertEquals(user, c2.getUser());
		assertEquals(action, c2.getAction());
		assertEquals(value, c2.getValue());
		assertEquals(priority, c2.getPriority());
		assertEquals(developerId, c2.getDeveloperId());
		assertEquals(null, c2.getRejectionReason());
		assertEquals(0, c2.getId());
		
		//Invaid Completed states
		//Priority is null
		try {
			new UserStory(0, "Completed", title, user, action, value, null, developerId, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		//Priority is empty
		try {
			new UserStory(0, "Completed", title, user, action, value, "", developerId, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		
		//Developer id is null
		try {
			new UserStory(0, "Completed", title, user, action, value, priority, null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid developer id", e.getMessage());
		}
		//Developer id is empty
		try {
			new UserStory(0, "Completed", title, user, action, value, priority, "", null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid developer id", e.getMessage());
		}
		
		//Rejection reason not null/empty
		try {
			new UserStory(0, "Completed", title, user, action, value, priority, developerId, rejectionReason);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid rejection reason", e.getMessage());
		}
		
		//Valid Rejected state with null values where needed
		UserStory r1 = new UserStory(0, "Rejected", title, user, action, value, null, null, rejectionReason);
		assertEquals("Rejected", r1.getState());
		assertEquals(title, r1.getTitle());
		assertEquals(user, r1.getUser());
		assertEquals(action, r1.getAction());
		assertEquals(value, r1.getValue());
		assertEquals(null, r1.getPriority());
		assertEquals(null, r1.getDeveloperId());
		assertEquals(rejectionReason, r1.getRejectionReason());
		assertEquals(0, r1.getId());
		
		//Valid Rejected state with empty values where needed
		UserStory r2 = new UserStory(0, "Rejected", title, user, action, value, "", "", rejectionReason2);
		assertEquals("Rejected", r2.getState());
		assertEquals(title, r2.getTitle());
		assertEquals(user, r2.getUser());
		assertEquals(action, r2.getAction());
		assertEquals(value, r2.getValue());
		assertEquals(null, r2.getPriority());
		assertEquals(null, r2.getDeveloperId());
		assertEquals(rejectionReason2, r2.getRejectionReason());
		assertEquals(0, r2.getId());
		
		//Valid Rejected state with empty values where needed and using last rejection reason
		UserStory r3 = new UserStory(0, "Rejected", title, user, action, value, "", "", rejectionReason3);
		assertEquals("Rejected", r3.getState());
		assertEquals(title, r3.getTitle());
		assertEquals(user, r3.getUser());
		assertEquals(action, r3.getAction());
		assertEquals(value, r3.getValue());
		assertEquals(null, r3.getPriority());
		assertEquals(null, r3.getDeveloperId());
		assertEquals(rejectionReason3, r3.getRejectionReason());
		assertEquals(0, r3.getId());
		
		//Invalid Rejection states
		//Priority is not null/empty
		try {
			new UserStory(0, "Rejected", title, user, action, value, priority, null, rejectionReason);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid priority", e.getMessage());
		}
		//DeveloperId not null/empty
		try {
			new UserStory(0, "Rejected", title, user, action, value, null, developerId, rejectionReason);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid developer id", e.getMessage());
		}
		//Rejection reason is null
		try {
			new UserStory(0, "Rejected", title, user, action, value, null, null, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid rejection reason", e.getMessage());
		}
		//Rejection reason is empty
		try {
			new UserStory(0, "Rejected", title, user, action, value, null, null, "");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid rejection reason", e.getMessage());
		}
		//Rejection reason is invalid
		try {
			new UserStory(0, "Rejected", title, user, action, value, null, null, "rejection");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid rejection reason", e.getMessage());
		}
	}

	/**
	 * Tests the toString method
	 */
	@Test
	public void testToString() {
		//Creating valid User Story in Submitted state with null values where needed
		UserStory s1 = new UserStory(0, "Submitted", title, user, action, value, null, null, null);
		assertEquals("* " + s1.getId() + "," + s1.getState() + "," + s1.getTitle() + "," + "\n- " + s1.getUser() + "\n- " + s1.getAction() + "\n- " + s1.getValue(), s1.toString());
		//Valid Backlog state with null values where needed
		UserStory b1 = new UserStory(0, "Backlog", title, user, action, value, priority, null, null);
		assertEquals("* " + b1.getId() + "," + b1.getState() + "," + b1.getTitle() + "," + b1.getPriority() + "," + "\n- " + b1.getUser() + "\n- " + b1.getAction() + "\n- " + b1.getValue(), b1.toString());
		//Valid Working state with null values where needed
		UserStory w1 = new UserStory(0, "Working", title, user, action, value, priority, developerId, null);
		assertEquals("* " + w1.getId() + "," + w1.getState() + "," + w1.getTitle() + "," + w1.getPriority() + "," + w1.getDeveloperId() + "\n- " + w1.getUser() + "\n- " + w1.getAction() + "\n- " + w1.getValue(), w1.toString());
		//Valid Verifying state with null values where needed
		UserStory v1 = new UserStory(0, "Verifying", title, user, action, value, priority3, developerId, null);
		assertEquals("* " + v1.getId() + "," + v1.getState() + "," + v1.getTitle() + "," + v1.getPriority() + "," + v1.getDeveloperId() + "\n- " + v1.getUser() + "\n- " + v1.getAction() + "\n- " + v1.getValue(), v1.toString());
		//Valid Completed state with null values where needed
		UserStory c1 = new UserStory(0, "Completed", title, user, action, value, priority, developerId, null);
		assertEquals("* " + c1.getId() + "," + c1.getState() + "," + c1.getTitle() + "," + c1.getPriority() + "," + c1.getDeveloperId() + "\n- " + c1.getUser() + "\n- " + c1.getAction() + "\n- " + c1.getValue(), c1.toString());
		//Valid Rejected state with null values where needed
		UserStory r1 = new UserStory(0, "Rejected", title, user, action, value, null, null, rejectionReason);
		assertEquals("* " + r1.getId() + "," + r1.getState() + "," + r1.getTitle() + "," + r1.getRejectionReason() + "\n- " + r1.getUser() + "\n- " + r1.getAction() + "\n- " + r1.getValue(), r1.toString());
	}

	/**
	 * Tests the update method
	 */
	@Test
	public void testUpdate() {
		//Creating Commands to be used
		Command c1 = new Command(Command.CommandValue.BACKLOG, priority);
		Command c2 = new Command(Command.CommandValue.ASSIGN, developerId);
		Command c3 = new Command(Command.CommandValue.REVIEW, null);
		Command c4 = new Command(Command.CommandValue.CONFIRM, null);
		Command c5 = new Command(Command.CommandValue.REOPEN, null);
		Command c6 = new Command(Command.CommandValue.REJECT, rejectionReason);
		Command c7 = new Command(Command.CommandValue.RESUBMIT, null);
		Command c8 = new Command(Command.CommandValue.ASSIGN, "different");
		
		//Creating multiple valid User Story in Submitted state with null values where needed to test all transitions
		UserStory s = new UserStory(0, "Submitted", title, user, action, value, null, null, null);
		UserStory s2 = new UserStory(0, "Submitted", title, user, action, value, null, null, null);
		
		//Invalid update using REOPEN
		try {
			s.update(c5);
			fail();
		}
		catch (UnsupportedOperationException e) {
			assertEquals("Submitted UserStorys can only be updated to the Backlog or Rejected after being Reviewed", e.getMessage());
			assertEquals("Submitted", s.getState());
		}
		//Updating to the backlog
		s.update(c1);
		assertEquals("Backlog", s.getState());
		assertEquals(priority, s.getPriority());
		
		//Updating to Rejected
		s2.update(c6);
		assertEquals("Rejected", s2.getState());
		assertEquals(rejectionReason, s2.getRejectionReason());
		

		
		//Multiple valid Backlog state with null values where needed for testing all possible transitions
		UserStory b = new UserStory(0, "Backlog", title, user, action, value, priority, null, null);
		UserStory b2 = new UserStory(0, "Backlog", title, user, action, value, priority, null, null);
		
		//Invalid update using REOPEN
		try {
			b.update(c5);
			fail();
		}
		catch (UnsupportedOperationException e) {
			assertEquals("Backloged UserStorys can only be Assigned a developer or Rejected", e.getMessage());
			assertEquals("Backlog", b.getState());
		}
		//Updating to Working state
		b.update(c2);
		assertEquals("Working", b.getState());
		assertEquals(developerId, b.getDeveloperId());
		
		//Updating to Rejected
		b2.update(c6);
		assertEquals("Rejected", b2.getState());
		assertEquals(rejectionReason, b2.getRejectionReason());
		
		//Multiple valid Working state with null values where needed
		UserStory w = new UserStory(0, "Working", title, user, action, value, priority, developerId, null);
		UserStory w2 = new UserStory(0, "Working", title, user, action, value, priority, developerId, null);
		UserStory w3 = new UserStory(0, "Working", title, user, action, value, priority, developerId, null);
		UserStory w4 = new UserStory(0, "Working", title, user, action, value, priority, developerId, null);
		
		//Invalid update using CONFIRM
		try {
			w.update(c4);
			fail();
		}
		catch (UnsupportedOperationException e) {
			assertEquals("Working UserStorys can only be Assigned a new developer, moved to Backlog, or Rejected", e.getMessage());
			assertEquals("Working", w.getState());
		}
		//Updating to Working
		w.update(c8);
		assertEquals("Working", w.getState());
		assertEquals("different", w.getDeveloperId());
		
		//Updating to Rejected
		w2.update(c6);
		assertEquals("Rejected", w2.getState());
		assertEquals(rejectionReason, w2.getRejectionReason());
		
		//Updating to Backlog
		w3.update(c5);
		assertEquals("Backlog", w3.getState());
		assertEquals(null, w3.getDeveloperId());
		assertEquals(priority, w3.getPriority());
		
		//Updating to Verifying
		w4.update(c3);
		assertEquals("Verifying", w4.getState());
		assertEquals(developerId, w4.getDeveloperId());
		assertEquals(priority, w4.getPriority());
		
		
		//Multiple valid Verifying state with null values where needed for testing all possible transitions
		UserStory v = new UserStory(0, "Verifying", title, user, action, value, priority3, developerId, null);
		UserStory v2 = new UserStory(0, "Verifying", title, user, action, value, priority3, developerId, null);
		
		//Invalid update using ASSIGN
		try {
			v.update(c1);
			fail();
		}
		catch (UnsupportedOperationException e) {
			assertEquals("Verifying UserStorys can only be sent to Confirm or Reviewed and sent back to Working", e.getMessage());
			assertEquals("Verifying", v.getState());
		}
		//Updating to Working
		v.update(c5);
		assertEquals("Working", v.getState());
		assertEquals(priority3, v.getPriority());
		assertEquals(developerId, v.getDeveloperId());
		
		//Updating to Completed
		v2.update(c4);
		assertEquals("Completed", v2.getState());
		assertEquals(priority3, v2.getPriority());
		assertEquals(developerId, v2.getDeveloperId());
		
		
		//Valid Completed state with null values where needed for testing all possible transitions
		UserStory c = new UserStory(0, "Completed", title, user, action, value, priority, developerId, null);
		
		//Invalid update using ASSIGN
		try {
			c.update(c1);
			fail();
		}
		catch (UnsupportedOperationException e) {
			assertEquals("Completed UserStorys can only be Reopened", e.getMessage());
			assertEquals("Completed", c.getState());
		}
		//Updating to Working
		c.update(c5);
		assertEquals("Working", c.getState());
		assertEquals(priority, c.getPriority());
		assertEquals(developerId, c.getDeveloperId());
		
		
		//Valid Rejected state with null values where needed for testing all possible transitions
		UserStory r = new UserStory(0, "Rejected", title, user, action, value, null, null, rejectionReason);
		
		//Invalid update using ASSIGN
		try {
			r.update(c1);
			fail();
		}
		catch (UnsupportedOperationException e) {
			assertEquals("Rejected UserStorys can only be Resubmitted", e.getMessage());
			assertEquals("Rejected", r.getState());
		}
		//Updating to Submitted
		r.update(c7);
		assertEquals("Submitted", r.getState());
		assertEquals(null, r.getPriority());
		assertEquals(null, r.getDeveloperId());
		assertEquals(null, r.getRejectionReason());
	}

}
