/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.EmptyStackException;

/**
 * Creates a linked stack to be used for class organization
 * @author Jakob Woodard
 * @param <E> the generic type that a linked stack can hold
 */
public class LinkedStack<E> implements Stack<E> {

	/** Field type for LinkedStack */
	private LinkedAbstractList<E> list;
	/** Capacity of the LinkedStack */
	private int capacity;
	
	/**
	 * Constructor for the LinkedStack, sets the initial capacity for the stack to 10.
	 * @param capacity the capacity of the LinkedStack
	 */
	public LinkedStack(int capacity) {
		list = new LinkedAbstractList<E>(capacity);
		setCapacity(capacity);
		
	}
	
	/**
	 * Adds an element to the stack
	 * @throws IllegalArgumentException if there is no room.
	 */
	@Override
	public void push(E element) throws IllegalArgumentException {
		if (size() == capacity) {
			throw new IllegalArgumentException("Stack is full");
		}
		else {
			list.add(element);
		}
	}

	/**
	 * Removes the top element from the stack
	 * @throws EmptyStackException if the stack is empty
	 */
	@Override
	public E pop() throws EmptyStackException {
		if (list.isEmpty()) {
			throw new EmptyStackException();
		}
		else {
			E value = list.get(size() - 1);
			list.remove(size() - 1);
			return value;
		}
	}

	/**
	 * Checks to see if the stack is empty or not
	 * @return true if the stack is empty
	 */
	@Override
	public boolean isEmpty() {
		return list.isEmpty();
	}

	/**
	 * Method to tell how many elements are in the stack
	 * @return number of elements in the stack
	 */
	@Override
	public int size() {
		return list.size();
	}

	/**
	 * Sets the capacity for the stack
	 * @throws IllegalArgumentException if the capacity is less than the amount of elements in the stack
	 * or if the capacity is negative.
	 */
	@Override
	public void setCapacity(int capacity) throws IllegalArgumentException {
		if (capacity < 0 || size() > capacity) {
			throw new IllegalArgumentException("Invalid capacity");
		}
		this.capacity = capacity;
		
	}


}
