/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.NoSuchElementException;

/**
 * Queue interface to be used to create a wait list of students for a course
 * @author Jakob Woodard
 * @param <E> generic type that a queue can store.
 *
 */
public interface Queue<E> {

	/**
	 * Adds the element to the back of the Queue if there is no room, an IAE is thrown
	 * @param element element to add to the queue
	 * @throws IllegalArgumentException if there is no room.
	 */
	void enqueue(E element) throws IllegalArgumentException;
	
	/**
	 * Removes and returns the element at the front of the Queue
	 * If the Queue is empty, a NoSuchEleemntException is thrown
	 * @return the element at the front of the queue
	 * @throws NoSuchElementException if the queue is empty
	 */
	E dequeue() throws NoSuchElementException;
	
	/**
	 * Checks to see if the queue is empty or not
	 * @return true if the queue is empty
	 */
	boolean isEmpty();
	
	/**
	 * Checks how many elements are in the queue
	 * @return the amount of elements in the queue
	 */
	int size();
	
	/**
	 * Sets the queue's capacity. If the parameter is negative or less than the number of elements already in the queue,
	 * an IllegalArgumentException is thrown
	 * @param capacity the desired capacity of the queue
	 * @throws IllegalArgumentException if the capacity is negative or less than the number of elements in the queue
	 */
	void setCapacity(int capacity) throws IllegalArgumentException;
}
