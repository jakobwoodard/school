/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.validator;

/**
 * Custom exception for an invalid FSM transition
 * @author Jakob Woodard
 *
 */
public class InvalidTransitionException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructor for ConflictException, passes the given message onto the parent class
	 * @param message the message to be passed to the parent class
	 */
	public InvalidTransitionException(String message) {
		super(message);
	}
	/**
	 * Constructor for the ConflicException. Gives the specified message "Schedule conflict." when there is 
	 * a schedule conflict.
	 */
	public InvalidTransitionException() {
		this("Invalid FSM Transition.");
	}

}
