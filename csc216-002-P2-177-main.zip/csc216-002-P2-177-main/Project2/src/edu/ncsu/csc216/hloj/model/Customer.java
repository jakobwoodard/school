/**
 * 
 */
package edu.ncsu.csc216.hloj.model;

/**
 * This class represents a customer with first and last names and a String identifier. Leading and trailing whitespaces are removed
 * from all Strings and strings cannot be empty
 * @author Jakob Woodard
 *
 */
public class Customer implements Comparable<Customer> {
	
	/** Customer's first name */
	private String firstName;
	/** Customer's last name */
	private String lastName;
	/** Customer's unique id */
	private String id;
	
	/**
	 * Constructor method for a customer that is created from a first name, last name, and unique id. Throws a ModelException if one
	 * of the setter methods also throws a ModelException
	 * @param firstName first name of the customer
	 * @param lastName last name of the customer
	 * @param id id of the customer
	 * @throws ModelException if the setters thrown a model exception during creation.
	 */
	public Customer(String firstName, String lastName, String id) throws ModelException {
		
		setFirstName(firstName);
		setLastName(lastName);
		setId(id);
	}
	
	/**
	 * Gets the Customer's first name
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}


	/**
	 * Error checks and trims the given first name then sets it to the customer's first name
	 * @param firstName the firstName to set
	 * @throws ModelException if the string is empty or only contains whitespace
	 */
	public void setFirstName(String firstName) throws ModelException {
		String name = firstName.trim();
		if ("".equals(name)) {
			throw new ModelException("The first name of the customer cannot be empty");
		}
		this.firstName = name;
	}


	/**
	 * Gets the Customer's last name
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}


	/**
	 * Error checks and trims the given last name then sets it to the customer's last name
	 * @param lastName the lastName to set
	 * @throws ModelException if the string is empty or only contains whitespace
	 */
	public void setLastName(String lastName) throws ModelException {
		String name = lastName.trim();
		if ("".equals(name)) {
			throw new ModelException("The last name of the customer cannot be empty");
		}
		this.lastName = name;
	}


	/**
	 * Gets the Customer's unique id
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * Error checks and trims the id then sets it to the customer's id
	 * @param id the id to set
	 * @throws ModelException if the string is empty or only contains whitespace
	 */
	public void setId(String id) throws ModelException {
		String check = id.trim();
		if ("".equals(check)) {
			throw new ModelException("The id of the customer cannot be empty");
		}
		this.id = check;
	}

	/**
	 * Creates the string object of the Customer's unique information to be used to render values into the GUI
	 */
	@Override
	public String toString() {
		return firstName + " " + lastName + " " + "(" + id + ")";
	}
	
	/**
	 * Compares two customers and returns -1 if the passed customer is "less" than another, 1 if the passed customer is "greater"
	 * than the other, or 0 if the two customers are equal
	 * @param c new customer being compared with
	 * @return -1, 0, or 1 depending on how the passed customer compares to the one being constructed.
	 */
	@Override
	public int compareTo(Customer c) {
		//Might be able to add function for seeing if ids are the same and throwing an error.
		//Setting return value to ensure statement coverage at the end 
		int returnValue = 100;
		//.this comes before compared
		if (this.getLastName().compareToIgnoreCase(c.getLastName()) < 0) {
			returnValue = -1;
		}
		//.this comes after compared
		if (this.getLastName().compareToIgnoreCase(c.getLastName()) > 0) {
			returnValue = 1;
		}
		if (this.getLastName().compareToIgnoreCase(c.getLastName()) == 0) {
			//.this comes before compared
			if (this.getFirstName().compareToIgnoreCase(c.getFirstName()) < 0) {
				returnValue = -1;
			}
			//.this comes after compared
			if (this.getFirstName().compareToIgnoreCase(c.getFirstName()) > 0) {
				returnValue = 1;
			}
			if (this.getFirstName().compareToIgnoreCase(c.getFirstName()) == 0) {
				returnValue = 0;
			}
		}
		return returnValue;
	}
	
	
	
	
	
}
