/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.validator;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test covering all possible transitions in the CourseNameValidatorFSM
 * @author Jakob Woodard
 *
 */
public class CourseNameValidatorFSMTest {

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.course.validator.CourseNameValidatorFSM#isValid(java.lang.String)}.
	 */
	@Test
	public void testIsValid() {
		CourseNameValidatorFSM fsm = new CourseNameValidatorFSM();
		//Valid Classes
		try {
			assertTrue(fsm.isValid("CSCA116"));
		} catch (InvalidTransitionException e) {
			fail("Unexpected InvalidTransistionExcpetion");
		}
		try {
			assertTrue(fsm.isValid("CSC116"));
		} catch (InvalidTransitionException e) {
			fail("Unexpected InvalidTransistionExcpetion");
		}
		try {
			assertTrue(fsm.isValid("CSC116A"));
		} catch (InvalidTransitionException e) {
			fail("Unexpected InvalidTransistionExcpetion");
		}
		try {
			assertTrue(fsm.isValid("CSCA116"));
		} catch (InvalidTransitionException e) {
			fail("Unexpected InvalidTransistionExcpetion");
		}
		try {
			assertTrue(fsm.isValid("C116"));
		} catch (InvalidTransitionException e) {
			fail("Unexpected InvalidTransistionExcpetion");
		}
		try {
			assertTrue(fsm.isValid("CS116"));
		} catch (InvalidTransitionException e) {
			fail("Unexpected InvalidTransistionExcpetion");
		}
		//Invalid Classes
		try {
			assertTrue(fsm.isValid("CSC2!6"));
			fail();
		} catch (InvalidTransitionException e) {
			assertEquals("Course name can only contain letters and digits.", e.getMessage());
		}
		try {
			assertTrue(fsm.isValid("216"));
			fail();
		} catch (InvalidTransitionException e) {
			assertEquals("Course name must start with a letter.", e.getMessage());
		}
		try {
			assertTrue(fsm.isValid("C!"));
			fail();
		} catch (InvalidTransitionException e) {
			assertEquals("Course name can only contain letters and digits.", e.getMessage());
		}
		try {
			assertFalse(fsm.isValid("C1"));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name can only contain letters and digits.", e.getMessage());
		}
		try {
			assertTrue(fsm.isValid("CSC1166"));
			fail();
		} catch (InvalidTransitionException e) {
			assertEquals("Course name can only have 3 digits.", e.getMessage());
		}
		try {
			assertTrue(fsm.isValid("CSC116A1"));
			fail();
		} catch (InvalidTransitionException e) {
			assertEquals("Course name cannot contain digits after the suffix.", e.getMessage());
		}
		try {
			assertTrue(fsm.isValid("CSC116AA"));
			fail();
		} catch (InvalidTransitionException e) {
			assertEquals("Course name can only have a 1 letter suffix.", e.getMessage());
		}
		try {
			assertTrue(fsm.isValid("CSCCS"));
			fail();
		} catch (InvalidTransitionException e) {
			assertEquals("Course name cannot start with more than 4 letters.", e.getMessage());
		}
		try {
			assertTrue(fsm.isValid("CSC1C"));
			fail();
		} catch (InvalidTransitionException e) {
			assertEquals("Course name must have 3 digits.", e.getMessage());
		}
		try {
			assertTrue(fsm.isValid("CSC11C"));
			fail();
		} catch (InvalidTransitionException e) {
			assertEquals("Course name must have 3 digits.", e.getMessage());
		}
		
		
		
		
		
	}

}
