/**
 * 
 */
package edu.ncsu.csc216.hloj.model.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

import edu.ncsu.csc216.hloj.model.Customer;
import edu.ncsu.csc216.hloj.model.MenuItem;
import edu.ncsu.csc216.hloj.model.ModelException;
import edu.ncsu.csc216.hloj.model.Order;
import edu.ncsu.csc216.hloj.model.lists.UniqueList;
import edu.ncsu.csc216.hloj.model.manager.CustomerManager;
import edu.ncsu.csc216.hloj.model.manager.MenuManager;
import edu.ncsu.csc216.hloj.model.manager.OrderManager;

/**
 * Resets the state of the system and reads a file to populate a new state. If the file cannot be loaded because it 
 * doesn�t exist, the method will throw an IllegalArgumentException with the message �Unable to load file.�
 * @author Jakob Woodard
 */
public class HLOJDataReader {
	
	/** List of menu items from a file */
	private static UniqueList<MenuItem> menuItems;
	/** List of menu item ids from a file */
	private static UniqueList<String> menuItemIDs;
	
	/**
	 * Processes a file, separating all of the data to be used for object construction. Also resets the state of the system
	 * @param fileName name of the file being read
	 * @throws FileNotFoundException if the file cannot be read
	 * @throws IllegalArgumentException if the file cannot be read
	 */
	public static void readData(String fileName) {
		//Resetting the state of the system
		OrderManager om = OrderManager.getInstance();
		MenuManager mm = MenuManager.getInstance();
		CustomerManager cm = CustomerManager.getInstance();
		om.removeAllOrders();
		mm.removeAllMenuItems();
		cm.removeAllCustomers();
		menuItems = new UniqueList<MenuItem>();
		menuItemIDs = new UniqueList<String>();
		
		int orderNumber = 0;
		
		Customer c = null;
		MenuItem m = null;
		Order o = null;
		
		Scanner fileReader;
		try {
			fileReader = new Scanner(new FileInputStream(fileName));
		} catch (FileNotFoundException e1) {
			throw new IllegalArgumentException("Unable to load file.");
		}
		orderNumber = Integer.parseInt(fileReader.nextLine());
//		System.out.print(orderNumber + "STOP");
		while (fileReader.hasNextLine()) {
			fileReader.useDelimiter("\\r?\\n?");
			
			String test = fileReader.nextLine();
			if (test.contains("#")) {
				String first = "";
				String last = "";
				String id = "";
				String customerString = test.substring(2);
				Scanner in = new Scanner(customerString);
				in.useDelimiter(",");
				first = in.next();
				last = in.next();
				id = in.next();
				try {
					c = new Customer(first, last, id);
					cm.addCustomer(c);
				} catch (ModelException e) {
					// Expected to have valid inputs
				}
				in.close();
			}
			else if (test.contains("*")) {
				String id = "";
				String type = "";
				String name = "";
				double price = 0;
				String itemString = test.substring(2);
				Scanner in = new Scanner(itemString);
				in.useDelimiter(",");
				id = in.next();
				type = in.next();
				name = in.next();
				price = in.nextDouble();
				try {
					m = new MenuItem(type, name, price);
					menuItems.add(m);
					menuItemIDs.add(id);
					in.close();
				} catch (ModelException e) {
					// Expected to have valid inputs, if they aren't, skip
				}
//				menuItems.add(m);
//				menuItemIDs.add(id);
//				in.close();
			}
			else if (test.contains("-")) {
				String id = "";
				String menuId = "";
				int number = 0;
				String orderString = test.substring(2);
				Scanner in = new Scanner(orderString);
				in.useDelimiter(",");
				number = in.nextInt();
				if (number > orderNumber) {
					while (in.hasNext()) {
						in.next();
					}
				}
				else {
					id = in.next();
					try {
							o = new Order(number, cm.getCustomer(id));
						} catch (ModelException e1) {
							e1.printStackTrace();
						}
					
					while (in.hasNext()) {
						
						menuId = in.next();
//						System.out.println(menuId);
//						System.out.println(in.next());
						
						for (int i = 0; i < menuItemIDs.size(); i++) {
							if (menuId.equals(menuItemIDs.get(i))) {
								o.addMenuItem(menuItems.get(i));
//								MenuItem temp = menuItems.get(i);
//								mm.addMenuItem(temp);
							}
						}
						
					}
					try {
						om.placeOrder(o);
					} 
					catch (ModelException e) {
						// If an exception is thrown, just skip and move on
					}
					
				}
				in.close();
			}
//			for (int i = 0; i < menuItems.size(); i++) {
//				try {
//					m = new MenuItem(menuItems.get(i).getType(), menuItems.get(i).getName(), menuItems.get(i).getPrice());
//				} catch (ModelException e) {
//					e.printStackTrace();
//				}
//				MenuManager.getInstance().addMenuItem(m);
//			}
			
			}

    }
}
