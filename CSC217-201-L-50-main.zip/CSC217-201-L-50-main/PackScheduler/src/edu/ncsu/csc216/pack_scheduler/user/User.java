package edu.ncsu.csc216.pack_scheduler.user;
/**
 * Abstract class that allows for the use of both a "Student" and a "Registrar" to access and edit PackScheduler.
 * @author Jakob Woodard
 *
 */
public abstract class User {
	/** student first name */
	private String firstName;
	/** student last name */
	private String lastName;
	/** student email */
	private String email;
	/** student id */
	private String id;
	/** student password */
	private String password;

	 /**
	  * Constructor class for a User
	 * @param firstName of the User
	 * @param lastName of the User
	 * @param email of the User
	 * @param id of the User
	 * @param password of the User
	 */
	public User(String firstName, String lastName, String id, String email, String password) {
		setFirstName(firstName);
		setLastName(lastName);
		setEmail(email);
		setId(id);
		setPassword(password);
	}

	/**
	  * Getter for the firstName
	  * @return firstName of the User
	  */
	public String getFirstName() {
		return firstName; 
	}

	/**
	 * Setter for first name
	 * @param firstName of the User
	 */
	public void setFirstName(String firstName) {
		if (firstName == null || "".equals(firstName)) {
			throw new IllegalArgumentException("Invalid first name");	
		}
		this.firstName = firstName;
	}

	/**
	 * Getter for the last name of a user
	 * @return lastName of the User
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * setter for last name
	 * @param lastName the lastName to set
	 * @throws IllegalArgumentException if last name is null or has no length
	 */
	public void setLastName(String lastName) {
		if (lastName == null || "".equals(lastName)) {
			throw new IllegalArgumentException("Invalid last name");
		}
		this.lastName = lastName;
	}

	/**
	 * Getter method for the user's email
	 * @return email of the user
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * setter for email
	 * @param email the email to set
	 * @throws IllegalArgumentException if email is null/has no length
	 * or if it has no '@' or '.' as well as if the last '.' comes before
	 * the '@'.
	 */
	public void setEmail(String email) {
		if (email == null || "".equals(email)) {
			throw new IllegalArgumentException("Invalid email");	
		}
		if (!email.contains("@") || !email.contains(".")) {
			throw new IllegalArgumentException("Invalid email");
		}
		if (email.indexOf('@') > email.lastIndexOf('.')) {
			throw new IllegalArgumentException("Invalid email");
		}
		this.email = email;
	}

	/**
	 * Getter method for the user's id
	 * @return id of the User
	 */
	public String getId() {
		return id;
	}

	/**
	 * setter for id, 
	 * @param id the id to set
	 * @throws IllegalArgumentException if id is null or has no length
	 */
	protected void setId(String id) {
		if (id == null || "".equals(id)) {
			throw new IllegalArgumentException("Invalid id");	
		}
		this.id = id;
	}

	/**
	 * Getter method for a user's password
	 * @return password of the user
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * setter for password
	 * @param password the password to set
	 * @throws IllegalArgumentException if password is null or has no length
	 */
	public void setPassword(String password) {
		if (password == null || "".equals(password)) {
			throw new IllegalArgumentException("Invalid password");	
		}
		this.password = password;
		
	}

	/**
	 * Checks to see that the hashCode is generated correctly
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	/**
	 * Checks to see that a User object is created correctly
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	
	
	
}