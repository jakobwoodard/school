/**
 * 
 */
package edu.ncsu.csc216.hloj.model.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

import edu.ncsu.csc216.hloj.model.MenuItem;
import edu.ncsu.csc216.hloj.model.lists.UniqueList;
import edu.ncsu.csc216.hloj.model.manager.CustomerManager;
import edu.ncsu.csc216.hloj.model.manager.MenuManager;
import edu.ncsu.csc216.hloj.model.manager.OrderManager;

/**
 * Writes the current state of the system to a file. If there are any errors or exceptions, 
 * an IllegalArgumentException is thrown with the message �Unable to save file.�
 * @author Jakob Woodard
 *
 */
public class HLOJDataWriter {
	
	/** List of menu items from a file */
	private static UniqueList<MenuItem> menuItems;
	/** List of menu item ids from a file */
	private static UniqueList<String> menuItemIDs;
	
	/**
	 * Writes the data from a list of orders to a specified file
	 * @param fileName name of the file being written to
	 * @throws IllegalArgumentException if the file cannot be written to
	 */
	public static void writeData(String fileName) {
		OrderManager om = OrderManager.getInstance();
		MenuManager mm = MenuManager.getInstance();
		CustomerManager cm = CustomerManager.getInstance();
		menuItems = new UniqueList<MenuItem>();
		menuItemIDs = new UniqueList<String>();
		int orderNumber = 0;
		PrintStream fileWriter;
		try {
			fileWriter = new PrintStream(new File(fileName));
			
			// Order number for top of the file
			for (int i = 0; i < om.getOrders().length; i++) {
				if (om.getOrders()[i].getNumber() > orderNumber) {
					orderNumber = om.getOrders()[i].getNumber();
				}
			}
			fileWriter.println(orderNumber);
			
			// Customer information
			for (int i = 0; i < cm.getCustomers().length; i++) {
				fileWriter.println("# " + cm.getCustomers()[i].getFirstName() + "," + cm.getCustomers()[i].getLastName()
					+ "," + cm.getCustomers()[i].getId());
			}
			
			// Menu item information
			System.out.println(mm.getMenuItems().length);
			for (int i = 0; i < mm.getMenuItems().length; i++) {
				
				String itemId = "MI" + i;
				menuItemIDs.add(itemId);
				menuItems.add(mm.getMenuItems()[i]);
				MenuItem temp = mm.getMenuItems()[i];
				fileWriter.println("* " + itemId + "," + temp.getType() + "," + temp.getName() + "," + temp.getPrice());
				
			}
			
			// Order information
			for (int i = 0; i < om.getOrders().length; i++) {
				String print = "";
				print = "- " + om.getOrders()[i].getNumber() + "," + om.getOrders()[i].getCustomer().getId() + ",";
				for (int j = 0; j < om.getOrders()[i].getItems().length; j++) {
					for (int k = 0; k < menuItems.size(); k++) {
						if (om.getOrders()[i].getItems()[j].getMenuItem().equals(menuItems.get(k))) {
							for (int x = 0; x < om.getOrders()[i].getItems()[j].getQuantity(); x++) {
								print += menuItemIDs.get(k) + ",";
							}
						}
					}
				}
				fileWriter.println(print);
			}
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("Unable to save file.");
		}


		fileWriter.close();
	}

}
