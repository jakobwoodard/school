/**
 * 
 */
package edu.ncsu.csc216.hloj.model.lists;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Test cases for SortedList
 * @author Jakob Woodard
 *
 */
public class SortedListTest {


	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.lists.SortedList#SortedList()}.
	 */
	@Test
	public void testSortedList() {
		SortedList<String> list = new SortedList<String>();
		assertEquals(0, list.size());
		
		//Adding 10 elements
		list.add("Zero");
		list.add("One");
		list.add("Two");
		list.add("Three");
		list.add("Four");
		list.add("Five");
		list.add("Six");
		list.add("Seven");
		list.add("Eight");
		list.add("Nine");
		System.out.print(list);
		
		
		//Asserting that all values are where they should be
		
		assertEquals("Eight", list.get(0));
		assertEquals("Five", list.get(1));
		assertEquals("Four", list.get(2));
		assertEquals("Nine", list.get(3));
		assertEquals("One", list.get(4));
		assertEquals("Seven", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Three", list.get(7));
		assertEquals("Two", list.get(8));
		assertEquals("Zero", list.get(9));
		
		try {
			list.add(null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals("Element is null", e.getMessage());
		}
		
		try {
			list.get(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.get(100);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		
	}
	

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.lists.SortedList#remove(int)}.
	 */
	@Test
	public void testRemoveInt() {
		SortedList<String> list = new SortedList<String>();
		assertEquals(0, list.size());
		
		//Adding 10 elements
		list.add("Zero");
		list.add("One");
		list.add("Two");
		list.add("Three");
		list.add("Four");
		list.add("Five");
		list.add("Six");
		list.add("Seven");
		list.add("Eight");
		list.add("Nine");
		
		//Asserting that all values are where they should be
		assertEquals("Eight", list.get(0));
		assertEquals("Five", list.get(1));
		assertEquals("Four", list.get(2));
		assertEquals("Nine", list.get(3));
		assertEquals("One", list.get(4));
		assertEquals("Seven", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Three", list.get(7));
		assertEquals("Two", list.get(8));
		assertEquals("Zero", list.get(9));
		
		list.remove(9);
		assertEquals("Eight", list.get(0));
		assertEquals("Five", list.get(1));
		assertEquals("Four", list.get(2));
		assertEquals("Nine", list.get(3));
		assertEquals("One", list.get(4));
		assertEquals("Seven", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Three", list.get(7));
		assertEquals("Two", list.get(8));
		
		list.remove(0);
		assertEquals("Five", list.get(0));
		assertEquals("Four", list.get(1));
		assertEquals("Nine", list.get(2));
		assertEquals("One", list.get(3));
		assertEquals("Seven", list.get(4));
		assertEquals("Six", list.get(5));
		assertEquals("Three", list.get(6));
		assertEquals("Two", list.get(7));
		
		list.remove(3);
		assertEquals("Five", list.get(0));
		assertEquals("Four", list.get(1));
		assertEquals("Nine", list.get(2));
		assertEquals("Seven", list.get(3));
		assertEquals("Six", list.get(4));
		assertEquals("Three", list.get(5));
		assertEquals("Two", list.get(6));
		
		try {
			list.remove(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.remove(15);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
	}


}
