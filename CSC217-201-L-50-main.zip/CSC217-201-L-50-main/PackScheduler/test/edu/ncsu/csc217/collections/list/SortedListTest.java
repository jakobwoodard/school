package edu.ncsu.csc217.collections.list;

import static org.junit.Assert.*;

import org.junit.Test;
/**
 * Testing class for SortedList to ensure that there are no unforeseen bugs in the implemented library.
 * @author Jakob Woodard
 *
 */
public class SortedListTest {
	/**
	 * Tests the creation of a sorted list to ensure that a new list is completely empty and that, since a list's original capacity is 10, if an 11th element gets added,
	 * the list properly grows.
	 */
	@Test
	public void testSortedList() {
		SortedList<String> list = new SortedList<String>();
		assertEquals(0, list.size());
		assertFalse(list.contains("apple"));
		
		//Tests that a newly created List is empty
		SortedList<String> newList = new SortedList<String>();
		assertEquals(0, newList.size());
		assertTrue(newList.isEmpty());
		
		//Tests that a list can correctly grow after adding an 11th element
		list.add("one");
		list.add("two");
		list.add("three");
		list.add("four");
		list.add("five");
		list.add("six");
		list.add("seven");
		list.add("eight");
		list.add("nine");
		list.add("ten");
		list.add("eleven");
		assertEquals(11, list.size());
		
		
	}
	/**
	 * Tests adding various elements to a list at various places to ensure that adding to a list works properly
	 */
	@Test
	public void testAdd() {
		SortedList<String> list = new SortedList<String>();
		
		//Starting with 1 element
		list.add("carrot");
		
		//Tests adding at the beginning
		list.add("banana");
		assertEquals(2, list.size());
		assertEquals("banana", list.get(0));
		
		
		//Tests "adding" at the end
		list.add("pineapple");
		assertEquals(3, list.size());
		assertEquals("pineapple", list.get(2));
		
		//Tests "adding" at the middle
		list.add("grape");
		assertEquals(4, list.size());
		assertEquals("grape", list.get(2));
		
		//Tests adding null element
		try {
			list.add(null);
			fail("Unable to add null elements");
		}
		catch (NullPointerException e) {
			assertEquals(4, list.size());
		}
		
		//Tests to add duplicate element
		try {
			list.add("banana");
			fail("Unable to add duplicate elements");
		}
		catch (IllegalArgumentException e) {
			assertEquals(4, list.size());
		}			
		
		

	}
	/**
	 * Test for getting specific elements of the list at a given index
	 */
	@Test
	public void testGet() {
		SortedList<String> list = new SortedList<String>();
		
		//Since get() is used throughout the tests to check the
		//contents of the list, we don't need to test main flow functionality
		//here.  Instead this test method should focus on the error 
		//and boundary cases.
		
		//Test getting element from an empty list
		try {
			assertEquals("", list.get(0));
			fail("Can't access empty list");
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals(0, list.size());
		}
		
		//Adding elements to list
		list.add("apple");
		list.add("pineapple");
		list.add("orange");
		list.add("banana");
		try {
			list.get(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals(4, list.size());
		}
		
		//Tests getting an element at size
		try {
			list.get(list.size());
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals(4, list.size());
		}

		
	}
	/**
	 * Tests removing an element from a list.
	 */
	@Test
	public void testRemove() {
		SortedList<String> list = new SortedList<String>();
		
		//Test removing from empty list
		try {
			list.remove(0);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals(0, list.size());
		}
		
		//Adding elements
		list.add("apple");
		list.add("pineapple");
		list.add("orange");
		list.add("banana");
		
		//Test removing element at an index < 0
		try {
			list.remove(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals(4, list.size());
		}
		
		//Tests removing element at size
		try {
			list.remove(list.size());
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals(4, list.size());
		}
		
		//Test removing element from middle
		list.remove(2);
		assertEquals(3, list.size());
		
		//Test removing last element
		list.remove(list.size() - 1);
		assertEquals(2, list.size());
		//Test removing first element
		list.remove(0);
		assertEquals(1, list.size());
		//Test removing last element
		list.remove(list.size() - 1);
		assertEquals(0, list.size());
	}
	/**
	 * Tests getting the index of a specific element. If an element isn't in the list, -1 is returned.
	 */
	@Test
	public void testIndexOf() {
		SortedList<String> list = new SortedList<String>();
		
		//Test getting index of empty List
		assertEquals(0, list.size());
		assertEquals(-1, list.indexOf("hello"));
		
		//Adding elements
		list.add("apple");
		list.add("pineapple");
		list.add("orange");
		list.add("banana");
		
		//Test various calls to indexOf for elements in the list
		//and not in the list
		//All elements in list
		assertEquals(1, list.indexOf("banana"));
		assertEquals(2, list.indexOf("orange"));
		assertEquals(3, list.indexOf("pineapple"));
		assertEquals(0, list.indexOf("apple"));
		//Element not in list
		assertEquals(-1, list.indexOf("strawberry"));
		
		//Test checking the index of null
		try {
			list.indexOf(null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals(4, list.size());
		}
		
	}
	/**
	 * Tests clear() which removes all the elements of a List
	 */
	@Test
	public void testClear() {
		SortedList<String> list = new SortedList<String>();

		//Adding elements
		list.add("apple");
		list.add("pineapple");
		list.add("orange");
		list.add("banana");
		
		//Clear the list
		list.clear();
		
		//Test that the list is empty
		assertEquals(0, list.size());
	}
	/**
	 * Test to see if a list is empty or not
	 */
	@Test
	public void testIsEmpty() {
		SortedList<String> list = new SortedList<String>();
		
		//Test that the list starts empty
		assertTrue(list.isEmpty());
		
		//Adding elements
		list.add("apple");
		list.add("pineapple");
		list.add("orange");
		list.add("banana");
		
		//Check that the list is no longer empty
		assertFalse(list.isEmpty());
	}
	/**
	 * Tests contains() which returns true if the specified element appears in the SortedList, false if it does not.
	 */
	@Test
	public void testContains() {
		SortedList<String> list = new SortedList<String>();
		
		assertFalse(list.contains("anything"));
		
		//Add some elements
		list.add("apple");
		list.add("pineapple");
		list.add("orange");
		list.add("banana");
		
		//Test some true cases
		assertTrue(list.contains("apple"));
		assertTrue(list.contains("pineapple"));
		assertTrue(list.contains("orange"));
		assertTrue(list.contains("banana"));
		
		//Test some false cases
		assertFalse(list.contains("strawberry"));
		assertFalse(list.contains("peach"));
	}
	/**
	 * Tests to make sure that the equals() method works properly when comparing two lists
	 */
	@Test
	public void testEquals() {
		SortedList<String> list1 = new SortedList<String>();
		SortedList<String> list2 = new SortedList<String>();
		SortedList<String> list3 = new SortedList<String>();
		
		//Making two lists the same and one list different
		list1.add("apple");
		list1.add("pineapple");
		list1.add("orange");
		list1.add("banana");
		
		list2.add("apple");
		list2.add("pineapple");
		list2.add("orange");
		list2.add("banana");
		
		list3.add("apple");
		list3.add("pineapple");
		list3.add("orange");
		list3.add("different");
		
		//Test for equality and non-equality
		assertEquals(list1, list2);
		assertEquals(list2, list1);
		
		assertNotEquals(list1, list3);
		assertNotEquals(list2, list3);
	}
	/**
	 * Tests to make sure that the hashCode() is generated properly.
	 */
	@Test
	public void testHashCode() {
		SortedList<String> list1 = new SortedList<String>();
		SortedList<String> list2 = new SortedList<String>();
		SortedList<String> list3 = new SortedList<String>();
		
		//Making two lists the same and one list different
		list1.add("apple");
		list1.add("pineapple");
		list1.add("orange");
		list1.add("banana");
				
		list2.add("apple");
		list2.add("pineapple");
		list2.add("orange");
		list2.add("banana");
				
		list3.add("apple");
		list3.add("pineapple");
		list3.add("orange");
		list3.add("different");
		
		//Tests for the same and different hashCodes
		assertEquals(list1.hashCode(), list2.hashCode());
		assertEquals(list2.hashCode(), list1.hashCode());
		
		assertNotEquals(list1.hashCode(), list3.hashCode());
		assertNotEquals(list2.hashCode(), list3.hashCode());
	}

}
 