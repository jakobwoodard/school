/**
 * 
 */
package edu.ncsu.csc216.hloj.model;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for MenuItem
 * @author Jakob Woodard
 *
 */
public class MenuItemTest {
	
	/** Type for testing */
	private static String type = "type";
	/** Name for testing */
	private static String name = "name";
	/** Price for testing */
	private static double price = 1.00;
	/** Delta for testing with prices */
	private static double delta = .001;
	
	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.MenuItem#MenuItem(java.lang.String, java.lang.String, double)}.
	 */
	@Test
	public void testMenuItem() {
		
		try {
			MenuItem m = new MenuItem(type, name, price);
			assertEquals("type", m.getType());
			assertEquals("name", m.getName());
			assertEquals(1.00, m.getPrice(), delta);
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.MenuItem#setType(java.lang.String)}.
	 */
	@Test
	public void testSetType() {
		
		try {
			MenuItem m = new MenuItem(type, name, price);
			m.setType(" ");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The type of the menu item cannot be empty", e.getMessage());
		}
		try {
			MenuItem m = new MenuItem(type, name, price);
			m.setType("");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The type of the menu item cannot be empty", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.MenuItem#setName(java.lang.String)}.
	 */
	@Test
	public void testSetName() {
		
		try {
			MenuItem m = new MenuItem(type, name, price);
			m.setName(" ");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The name of the menu item cannot be empty", e.getMessage());
		}
		try {
			MenuItem m = new MenuItem(type, name, price);
			m.setName("");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The name of the menu item cannot be empty", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.MenuItem#setPrice(double)}.
	 */
	@Test
	public void testSetPrice() {

		try {
			MenuItem m = new MenuItem(type, name, price);
			m.setPrice(0);
			fail();
		}
		catch (ModelException e) {
			assertEquals("The price of the menu item must be greater than zero", e.getMessage());
		}
		try {
			MenuItem m = new MenuItem(type, name, price);
			m.setPrice(-1.0);
			fail();
		}
		catch (ModelException e) {
			assertEquals("The price of the menu item must be greater than zero", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.MenuItem#toString()}.
	 */
	@Test
	public void testToString() {
		
		try {
			MenuItem m = new MenuItem(type, name, price);
			assertEquals("(" + type + ") " + name + " - $" + price, m.toString());
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.MenuItem#compareTo(edu.ncsu.csc216.hloj.model.MenuItem)}.
	 */
	@Test
	public void testCompareTo() {

		try {
			MenuItem m1 = new MenuItem(type, name, price);
			MenuItem m2 = new MenuItem(type, type, price);
			MenuItem m4 = new MenuItem("v", name, price);
			
			assertEquals(0, m1.compareTo(m2));
			assertEquals(0, m2.compareTo(m1));
			assertEquals(0, m1.compareTo(m1));
			assertEquals(-1, m1.compareTo(m4));
			assertEquals(1, m4.compareTo(m1));
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

}
