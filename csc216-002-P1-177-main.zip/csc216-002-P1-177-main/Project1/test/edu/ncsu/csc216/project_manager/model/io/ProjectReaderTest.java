package edu.ncsu.csc216.project_manager.model.io;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import edu.ncsu.csc216.project_manager.model.manager.Project;
/**
 * Testing class for ProjectReader
 * @author Jakob Woodard
 *
 */
public class ProjectReaderTest {
	/** Valid test file with 1 project */
	private String project1 = "test-files/project1.txt";
	/** Valid test file with 2 projects */
	private String project2 = "test-files/project2.txt";
	/** Valid test file where ids are out of order*/
	private String project3 = "test-files/project3.txt";
	/**  missing project name */
	private String project4 = "test-files/project4.txt";
	/** missing id */
	private String project5 = "test-files/project5.txt";
	/** incorrect state */
	private String project6 = "test-files/project6.txt";
	/** missing state */
	private String project7 = "test-files/project7.txt";
	/** missing title */
	private String project8 = "test-files/project8.txt";
	/** empty user */
	private String project9 = "test-files/project9.txt";
	/** empty action */
	private String project10 = "test-files/project10.txt";
	/** empty value */
	private String project11 = "test-files/project11.txt";
	/** missing user/action/value */
	private String project12 = "test-files/project12.txt";
	/** extra user/action/value */
	private String project13 = "test-files/project13.txt";

	/**
	 * Tests that input files are correctly read and broken down
	 */
	@Test
	public void testReadProjectFile()  {
		List<Project> projects = new ArrayList<Project>();
		//Valid file read
		try {
			//First story
			projects = ProjectReader.readProjectFile(project1);
			assertEquals("WolfScheduler", projects.get(0).getProjectName());
			assertEquals(0, projects.get(0).getUserStoryById(0).getId());
			assertEquals("Completed", projects.get(0).getUserStoryById(0).getState());
			assertEquals("Load Catalog", projects.get(0).getUserStoryById(0).getTitle());
			assertEquals("High", projects.get(0).getUserStoryById(0).getPriority());
			assertEquals("sesmith5", projects.get(0).getUserStoryById(0).getDeveloperId());
			assertEquals("student", projects.get(0).getUserStoryById(0).getUser());
			assertEquals("load a course catalog file", projects.get(0).getUserStoryById(0).getAction());
			assertEquals("plan a schedule for next semester", projects.get(0).getUserStoryById(0).getValue());
			//Second story
			assertEquals(1, projects.get(0).getUserStoryById(1).getId());
			assertEquals("Verifying", projects.get(0).getUserStoryById(1).getState());
			assertEquals("Select Course", projects.get(0).getUserStoryById(1).getTitle());
			assertEquals("Medium", projects.get(0).getUserStoryById(1).getPriority());
			assertEquals("jctetter", projects.get(0).getUserStoryById(1).getDeveloperId());
			assertEquals("student", projects.get(0).getUserStoryById(1).getUser());
			assertEquals("select a course to add to my schedule", projects.get(0).getUserStoryById(1).getAction());
			assertEquals("plan a schedule for next semester", projects.get(0).getUserStoryById(1).getValue());
			//Third story (assume that any story after the third will also be valid
			assertEquals(2, projects.get(0).getUserStoryById(2).getId());
			assertEquals("Working", projects.get(0).getUserStoryById(2).getState());
			assertEquals("Add Event", projects.get(0).getUserStoryById(2).getTitle());
			assertEquals("Medium", projects.get(0).getUserStoryById(2).getPriority());
			assertEquals("ignacioxd", projects.get(0).getUserStoryById(2).getDeveloperId());
			assertEquals("student", projects.get(0).getUserStoryById(2).getUser());
			assertEquals("add a recurring event", projects.get(0).getUserStoryById(2).getAction());
			assertEquals("schedule extra curricular activities", projects.get(0).getUserStoryById(2).getValue());
				
		} catch (Exception e1) {
			fail("Unexpected fail");
			
		}
		try {
			projects = ProjectReader.readProjectFile(project2);
			//First story, first project
			assertEquals("WolfScheduler", projects.get(0).getProjectName());
			assertEquals(0, projects.get(0).getUserStoryById(0).getId());
			assertEquals("Completed", projects.get(0).getUserStoryById(0).getState());
			assertEquals("Load Catalog", projects.get(0).getUserStoryById(0).getTitle());
			assertEquals("High", projects.get(0).getUserStoryById(0).getPriority());
			assertEquals("sesmith5", projects.get(0).getUserStoryById(0).getDeveloperId());
			assertEquals("student", projects.get(0).getUserStoryById(0).getUser());
			assertEquals("load a course catalog file", projects.get(0).getUserStoryById(0).getAction());
			assertEquals("plan a schedule for next semester", projects.get(0).getUserStoryById(0).getValue());
			//Second story
			assertEquals(1, projects.get(0).getUserStoryById(1).getId());
			assertEquals("Verifying", projects.get(0).getUserStoryById(1).getState());
			assertEquals("Select Course", projects.get(0).getUserStoryById(1).getTitle());
			assertEquals("Medium", projects.get(0).getUserStoryById(1).getPriority());
			assertEquals("jctetter", projects.get(0).getUserStoryById(1).getDeveloperId());
			assertEquals("student", projects.get(0).getUserStoryById(1).getUser());
			assertEquals("select a course to add to my schedule", projects.get(0).getUserStoryById(1).getAction());
			assertEquals("plan a schedule for next semester", projects.get(0).getUserStoryById(1).getValue());
			//Third story (assume that any story after the third will also be valid
			assertEquals(2, projects.get(0).getUserStoryById(2).getId());
			assertEquals("Working", projects.get(0).getUserStoryById(2).getState());
			assertEquals("Add Event", projects.get(0).getUserStoryById(2).getTitle());
			assertEquals("Medium", projects.get(0).getUserStoryById(2).getPriority());
			assertEquals("ignacioxd", projects.get(0).getUserStoryById(2).getDeveloperId());
			assertEquals("student", projects.get(0).getUserStoryById(2).getUser());
			assertEquals("add a recurring event", projects.get(0).getUserStoryById(2).getAction());
			assertEquals("schedule extra curricular activities", projects.get(0).getUserStoryById(2).getValue());
			
			//Next project
			assertEquals("PackScheduler", projects.get(1).getProjectName());
			assertEquals(1, projects.get(1).getUserStoryById(1).getId());
			assertEquals("Backlog", projects.get(1).getUserStoryById(1).getState());
			assertEquals("Load Student Directory", projects.get(1).getUserStoryById(1).getTitle());
			assertEquals("High", projects.get(1).getUserStoryById(1).getPriority());
			assertEquals(null, projects.get(1).getUserStoryById(1).getDeveloperId());
			assertEquals("administrator", projects.get(1).getUserStoryById(1).getUser());
			assertEquals("load the student directory into the registration system", projects.get(1).getUserStoryById(1).getAction());
			assertEquals("students can register for classes next semester", projects.get(1).getUserStoryById(1).getValue());
		}
		catch (Exception e) {
			fail("Unexpected FNF exception");
		}
		//Using file where IDs are out of order
		try {
			//First story
			projects = ProjectReader.readProjectFile(project3);
			assertEquals("WolfScheduler", projects.get(0).getProjectName());
			assertEquals(3, projects.get(0).getUserStoryById(3).getId());
			assertEquals("Backlog", projects.get(0).getUserStoryById(3).getState());
			assertEquals("Export Schedule", projects.get(0).getUserStoryById(3).getTitle());
			assertEquals("Low", projects.get(0).getUserStoryById(3).getPriority());
			assertEquals(null, projects.get(0).getUserStoryById(3).getDeveloperId());
			assertEquals("student\n" + 
					"a second line on a user\n" + 
					"to test that second and third lines work", projects.get(0).getUserStoryById(3).getUser());
			assertEquals("export my schedule", projects.get(0).getUserStoryById(3).getAction());
			assertEquals("so it's available when I register for classes", projects.get(0).getUserStoryById(3).getValue());
			//Second story
			assertEquals(4, projects.get(0).getUserStoryById(4).getId());
			assertEquals("Submitted", projects.get(0).getUserStoryById(4).getState());
			assertEquals("Change Title", projects.get(0).getUserStoryById(4).getTitle());
			assertEquals(null, projects.get(0).getUserStoryById(4).getPriority());
			assertEquals(null, projects.get(0).getUserStoryById(4).getDeveloperId());
			assertEquals("student", projects.get(0).getUserStoryById(4).getUser());
			assertEquals("change the title of my schedule\n" + 
					"this is a second line to test that second lines work", projects.get(0).getUserStoryById(4).getAction());
			assertEquals("so I can have different schedules to consider", projects.get(0).getUserStoryById(4).getValue());
			//Third story (assume that any story after the third will also be valid
			assertEquals(5, projects.get(0).getUserStoryById(5).getId());
			assertEquals("Rejected", projects.get(0).getUserStoryById(5).getState());
			assertEquals("Post to Piazza", projects.get(0).getUserStoryById(5).getTitle());
			assertEquals(null, projects.get(0).getUserStoryById(5).getPriority());
			assertEquals(null, projects.get(0).getUserStoryById(5).getDeveloperId());
			assertEquals("student", projects.get(0).getUserStoryById(5).getUser());
			assertEquals("post my schedule to Piazza for feedback", projects.get(0).getUserStoryById(5).getAction());
			assertEquals("see which of my friends are interested in taking the same courses", projects.get(0).getUserStoryById(5).getValue());
			assertEquals("Inappropriate", projects.get(0).getUserStoryById(5).getRejectionReason());
		}
		catch (Exception e) {
			fail("Unexpected FNF exception");
		}
		
		//missing project name
		try {
			projects = ProjectReader.readProjectFile(project4);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid name", e.getMessage());
		}
		
		//Missing id
		try {
			projects = ProjectReader.readProjectFile(project5);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid id", e.getMessage());
		}
		
		//Incorrect state
		try {
			projects = ProjectReader.readProjectFile(project6);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid state", e.getMessage());
		}
		
		//Missing state
		try {
			projects = ProjectReader.readProjectFile(project7);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid state", e.getMessage());
		}
		
		//Missing title
		try {
			projects = ProjectReader.readProjectFile(project8);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid state", e.getMessage());
		}
		
		//Empty user
		try {
			projects = ProjectReader.readProjectFile(project9);
		}
		catch (IllegalArgumentException e) {
			assertEquals("User is empty", e.getMessage());
		}
		
		//Empty action
		try {
			projects = ProjectReader.readProjectFile(project10);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Action is empty", e.getMessage());
		}
		
		//Empty value
		try {
			projects = ProjectReader.readProjectFile(project11);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Value is empty", e.getMessage());
		}
		
		//Missing user/action/value
		try {
			projects = ProjectReader.readProjectFile(project12);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Missing information", e.getMessage());
		}
		
		//Extra user/action/value
		try {
			projects = ProjectReader.readProjectFile(project13);
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid user/action/value information", e.getMessage());
		}
		
		//Invalid file
		try {
			projects = ProjectReader.readProjectFile("invalid");
		}
		catch (IllegalArgumentException e) {
			assertEquals("Unable to save file.", e.getMessage());
		}
		
	}

}
