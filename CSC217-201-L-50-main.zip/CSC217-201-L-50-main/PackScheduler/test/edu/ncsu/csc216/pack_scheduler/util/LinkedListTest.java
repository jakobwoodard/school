/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import java.util.ListIterator;

import org.junit.Test;

/**
 * Test cases for LinkedList
 * @author Jakob Woodard
 *
 */
public class LinkedListTest {

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.util.LinkedList#LinkedList()}.
	 */
	@Test
	public void testLinkedList() {
		LinkedList<String> list = new LinkedList<String>();
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		//Invalid get to avoid writing new test
		try {
			list.get(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.get(100);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.util.LinkedList#add(int, java.lang.Object)}.
	 */
	@Test
	public void testAddIntE() {
		LinkedList<String> list = new LinkedList<String>();
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		//Testing that the capacity of the list is properly increased
		list.add(10, "Ten");
		//Testing adding in the middle
		list.add(8, "Test");
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Test", list.get(8));
		assertEquals("Eight", list.get(9));
		assertEquals("Nine", list.get(10));
		assertEquals("Ten", list.get(11));
		//Adding at the end
		list.add(list.size(), "Last");
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Test", list.get(8));
		assertEquals("Eight", list.get(9));
		assertEquals("Nine", list.get(10));
		assertEquals("Ten", list.get(11));
		assertEquals("Last", list.get(list.size() - 1));
		
		try {
			list.add(10, "Zero");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Element already exists", e.getMessage());
		}

	}

	/**
	 * Test method for {@link java.util.AbstractSequentialList#set(int, java.lang.Object)}.
	 */
	@Test
	public void testSetIntE1() {
		LinkedList<String> list = new LinkedList<String>();
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		list.set(0, "0");
		assertEquals("0", list.get(0));
		
		try {
			list.set(4, "Four");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Element already exists", e.getMessage());
		}
	}

	/**
	 * Test method for {@link java.util.AbstractSequentialList#remove(int)}.
	 */
	@Test
	public void testRemoveInt() {
		LinkedList<String> list = new LinkedList<String>();
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		list.remove(9);
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		
		list.remove(4);
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Five", list.get(4));
		assertEquals("Six", list.get(5));
		assertEquals("Seven", list.get(6));
		assertEquals("Eight", list.get(7));
		
		list.remove(0);
		assertEquals("One", list.get(0));
		assertEquals("Two", list.get(1));
		assertEquals("Three", list.get(2));
		assertEquals("Five", list.get(3));
		assertEquals("Six", list.get(4));
		assertEquals("Seven", list.get(5));
		assertEquals("Eight", list.get(6));
		
		
	}

	/**
	 * Test method for {@link java.util.AbstractSequentialList#listIterator(int)}.
	 */
	@Test
	public void testListIteratorInt1() {
		LinkedList<String> list = new LinkedList<String>();
		ListIterator<String> iterator = list.listIterator(0);
		
		assertTrue(iterator.hasNext());
		assertNull(iterator.previous());
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
	}

}
