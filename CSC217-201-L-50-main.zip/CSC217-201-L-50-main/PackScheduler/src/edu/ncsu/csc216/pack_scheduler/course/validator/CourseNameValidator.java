/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.validator;


/**
 * Class that uses the State Pattern and FSM created for CourseNameValidator to check to see if a given course name is valid
 * @author Jakob Woodard
 *
 */
public class CourseNameValidator {
	/** Boolean to see if the end state is valid */
	private boolean validEndState = false;
	/** Counter for letters in course name */
	private int letterCount;
	/** Counter for digits in course name */
	private int digitCount;
	/** InitialState object used for isValid */
	private InitialState stateInitial = new InitialState();
	/** NumberState object used for isValid */
	private NumberState1 stateD = new NumberState1();
	/** NumberState object used for isValid */
	private NumberState2 stateDD = new NumberState2();
	/** NumberState object used for isValid */
	private NumberState3 stateDDD = new NumberState3();
	/** LetterState object used for isValid */
	private LetterState1 stateL = new LetterState1();
	/** LetterState object used for isValid */
	private LetterState2 stateLL = new LetterState2();
	/** LetterState object used for isValid */
	private LetterState3 stateLLL = new LetterState3();
	/** LetterState object used for isValid */
	private LetterState4 stateLLLL = new LetterState4();
	/** SuffixState object used for isValid */
	private SuffixState stateSuffix = new SuffixState();
	/** Current state of the string */
	private State currentState;
	/**
	 * Boolean method to see if the given course name is valid
	 * @param courseName course name to be checked
	 * @return true if the courseName is valid
	 * @throws InvalidTransitionException if invalid transition in the FSM
	 */
	public boolean isValid(String courseName) throws InvalidTransitionException  {
		if (courseName == null || "".equals(courseName)) {
			throw new IllegalArgumentException("Invalid course name");
		}
		this.letterCount = 0;
		this.digitCount = 0;
		currentState = stateInitial;
		int charIndex = 0;
		char c;
		
		while (charIndex < courseName.length()) {
			
			
			c = courseName.charAt(charIndex);
			
			if (!Character.isLetter(c) && !Character.isDigit(c)) {
				currentState.onOther();
			}
			if (currentState.equals(stateSuffix)) {
				if (Character.isLetter(c)) {
					currentState.onLetter();
				}
				else if (Character.isDigit(c)) {
					currentState.onDigit();
				}
			}
			if (currentState.equals(stateDDD)) {
				if (Character.isLetter(c)) {
					stateDDD.onLetter();
					currentState = stateSuffix;
				}
				else if (Character.isDigit(c)) {
					stateDDD.onDigit();
				}
			}
			if (currentState.equals(stateDD)) {
				if (Character.isLetter(c)) {
					stateDD.onLetter();
				}
				else if (Character.isDigit(c)) {
					stateDD.onDigit();
					currentState = stateDDD;
				}
			}
			if (currentState.equals(stateD)) {
				if (Character.isLetter(c)) {
					stateD.onLetter();
				}
				else if (Character.isDigit(c)) {
					stateD.onDigit();
					currentState = stateDD;
				}
			}
			if (currentState.equals(stateLLLL)) {
				if (Character.isLetter(c)) {
					stateLLLL.onLetter();
				}
				else if (Character.isDigit(c)) {
					stateLLLL.onDigit();
					currentState = stateD;
				}
			}
			if (currentState.equals(stateLLL)) {
				if (Character.isLetter(c)) {
					stateLLL.onLetter();
					currentState = stateLLLL;
				}
				else if (Character.isDigit(c)) {
					stateLLL.onDigit();
					currentState = stateD;
				}
			}
			if (currentState.equals(stateLL)) {
				if (Character.isLetter(c)) {
					stateLL.onLetter();
					currentState = stateLLL;
				}
				else if (Character.isDigit(c)) {
					stateLL.onDigit();
					currentState = stateD;
				}
			}
			if (currentState.equals(stateL)) {
				if (Character.isLetter(c)) {
					stateL.onLetter();
					currentState = stateLL;
				}
				else if (Character.isDigit(c)) {
					stateL.onDigit();
					currentState = stateD;
				}
			}
			if (currentState.equals(stateInitial)) {
				if (Character.isLetter(c)) {
					stateInitial.onLetter();
					currentState = stateL;
				}
				else if (Character.isDigit(c)) {
					stateInitial.onDigit();
				}
			}
			charIndex++;
		}
		
		if (digitCount < 3) {
			throw new InvalidTransitionException("Course name must have 3 digits.");
		}
		if (letterCount > 5) {
			throw new InvalidTransitionException("Course name cannot have more than 5 letters");
		}
		
		
		if (currentState == stateSuffix || currentState == stateDDD) {
			validEndState = true;
	}
	return validEndState;
}
	
	abstract class State {
		/** Abstract method for encountering a letter
		 * @throws InvalidTransitionException when a letter is encountered invalidly
		 */
		public abstract void onLetter() throws InvalidTransitionException;
		/**Abstract method for encountering a digit
		 * @throws InvalidTransitionException when a digit is encountered invalidly
		 */
		public abstract void onDigit() throws InvalidTransitionException;
		/**
		 * Concrete method for encountering a character other than a digit or letter, throws an ITE
		 * @throws InvalidTransitionException when a non digit or letter character is encountered
		 */
		public void onOther() throws InvalidTransitionException {
			throw new InvalidTransitionException("Course name can only contain letters and digits.");
		}
	}
	/**
	 * Inner concrete class to determine what to do when encountering a character in the initial state
	 * @author Jakob Woodard
	 */
	public class InitialState extends State {
		/** Method for encountering a letter, the letter count is increased */
		public void onLetter() {
			letterCount++;
		}
		/**
		 * Method for encountering a digit
		 * @throws InvalidTransitionException if a digit is encountered
		 */
		public void onDigit() throws InvalidTransitionException {
			throw new InvalidTransitionException("Course name must start with a letter.");
		}
	}
	
	/**
	 * Inner concrete class to determine what to do when encountering a character in the number state
	 * @author Jakob Woodard
	 */
	public class NumberState1 extends State {
		/** Method for encountering a letter 
		 * @throws InvalidTransitionException if there are not 3 digits before the letter
		 */
		public void onLetter() throws InvalidTransitionException {
			throw new InvalidTransitionException("Course name must have 3 digits.");
		}
		/** Method for encountering a digit 
		 */
		public void onDigit() throws InvalidTransitionException {
			digitCount++;
		}
	}
	
	/**
	 * Inner concrete class to determine what to do when encountering a character in the number state
	 * @author Jakob Woodard
	 */
	public class NumberState2 extends State {
		/** Method for encountering a letter 
		 * @throws InvalidTransitionException if there are not 3 digits before the letter
		 */
		public void onLetter() throws InvalidTransitionException {
			throw new InvalidTransitionException("Course name must have 3 digits.");
		}
		/** Method for encountering a digit 
		 */
		public void onDigit() throws InvalidTransitionException {
			digitCount++;
		}
	}
	
	/**
	 * Inner concrete class to determine what to do when encountering a character in the number state
	 * @author Jakob Woodard
	 */
	public class NumberState3 extends State {
		/** Method for encountering a letter 
		 */
		public void onLetter() {
			letterCount++;
		}
		/** Method for encountering a digit 
		 * @throws InvalidTransitionException if there are already 3 digits in the course name
		 */
		public void onDigit() throws InvalidTransitionException {
			throw new InvalidTransitionException("Course name can only have 3 digits.");
		}
	}
	
	/**
	 * Inner concrete class to determine what to do when encountering a character in the letter state
	 * @author Jakob Woodard
	 */
	public class LetterState1 extends State {
		/**
		 * Method for encountering a letter in the letter state. Throws an ITE if the amount of letters is already over 4
		 */
		public void onLetter() {
			letterCount++;
		}
		/**
		 * Method for encountering a digit in the letter state. Increases the digit count
		 */
		public void onDigit() {
			digitCount++;
		}
	}
	
	/**
	 * Inner concrete class to determine what to do when encountering a character in the letter state
	 * @author Jakob Woodard
	 */
	public class LetterState2 extends State {
		/**
		 * Method for encountering a letter in the letter state. Throws an ITE if the amount of letters is already over 4
		 */
		public void onLetter() {
			letterCount++;
		}
		/**
		 * Method for encountering a digit in the letter state. Increases the digit count
		 */
		public void onDigit() {
			digitCount++;
		}
	}
	
	/**
	 * Inner concrete class to determine what to do when encountering a character in the letter state
	 * @author Jakob Woodard
	 */
	public class LetterState3 extends State {
		/**
		 * Method for encountering a letter in the letter state. Throws an ITE if the amount of letters is already over 4
		 */
		public void onLetter() {
			letterCount++;
		}
		/**
		 * Method for encountering a digit in the letter state. Increases the digit count
		 */
		public void onDigit() {
			digitCount++;
		}
	}
	
	/**
	 * Inner concrete class to determine what to do when encountering a character in the letter state
	 * @author Jakob Woodard
	 */
	public class LetterState4 extends State {
		/**
		 * Method for encountering a letter in the letter state. Throws an ITE if the amount of letters is already over 4
		 * @throws InvalidTransitionException if the amount of present letters is over 4
		 */
		public void onLetter() throws InvalidTransitionException {
			throw new InvalidTransitionException("Course name cannot start with more than 4 letters.");
		}
		/**
		 * Method for encountering a digit in the letter state. Increases the digit count
		 */
		public void onDigit() {
			digitCount++;
		}
	}
	
	
	/**
	 * Inner concrete class to determine what to do when encountering a character in the letter state
	 * @author Jakob Woodard
	 */
	public class SuffixState extends State {
		/**
		 * Method for encountering letters. Throws in ITE if a letter is encountered since a course can only have 1 letter after the number
		 * @throws InvalidTransitionException if a letter is encountered
		 */
		public void onLetter() throws InvalidTransitionException {
			throw new InvalidTransitionException("Course name can only have a 1 letter suffix.");
		}
		/**
		 * Method for encountering digits. Throws in ITE if a digit is encountered since a course can't have a digit after the suffix
		 * @throws InvalidTransitionException if a digit is encountered
		 */
		public void onDigit() throws InvalidTransitionException {
			throw new InvalidTransitionException("Course name cannot contain digits after the suffix.");
		}
	}
	
	

}
