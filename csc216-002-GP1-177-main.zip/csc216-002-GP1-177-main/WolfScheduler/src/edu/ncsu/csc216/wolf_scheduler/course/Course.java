/**
 * 
 */
package edu.ncsu.csc216.wolf_scheduler.course;
/**
 * Class for adding/creating Courses
 * @author Jakob Woodard
 *
 */
public class Course {
	/** Minimum length of a name */
	private static final int MIN_NAME_LENGTH = 5;
	/** Maximum length of a name */
	private static final int MAX_NAME_LENGTH = 8;
	/** Minimum amount of letters */
	private static final int MIN_LETTER_COUNT = 1;
	/** Maximum amount of letters */
	private static final int MAX_LETTER_COUNT = 4;
	/** Amount of digits */
	private static final int DIGIT_COUNT = 3;
	/** Length of the section */
	private static final int SECTION_LENGTH = 3;
	/** Maximum amount of credits */
	private static final int MAX_CREDITS = 5;
	/** Minimum amount of credits */
	private static final int MIN_CREDITS = 1;
	/** Highest hour number */
	private static final int UPPER_HOUR = 24;
	/** Highest minute number */
	private static final int UPPER_MINUTE = 60;
	/** Course's name. */
	private String name;
	/** Course's title. */
	private String title;
	/** Course's section. */
	private String section;
	/** Course's credit hours */
	private int credits;
	/** Course's instructor */
	private String instructorId;
	/** Course's meeting days */
	private String meetingDays;
	/** Course's starting time */
	private int startTime;
	/** Course's ending time */
	private int endTime;
	
	/**
	 * Constructs a Course object with values for all fields
	 * @param name name of the Course
	 * @param title title of the Course
	 * @param section section of the Course
	 * @param credits credit hours for the Course
	 * @param instructorId instructor's unity id
	 * @param meetingDays meeting days for the Course as a series of chars
	 * @param startTime starting time of the Course
	 * @param endTime ending time of the Course
	 */
	public Course(String name, String title, String section, int credits, String instructorId, String meetingDays,
			int startTime, int endTime) {
		setName(name);
	    setTitle(title);
	    setSection(section);
	    setCredits(credits);
	    setInstructorId(instructorId);
	    setMeetingDaysAndTime(meetingDays, startTime, endTime);
	}
	

	/**
	 * Creates a Course with the given name, title, section, credits, instructorId, and meetingDays for
	 * courses that are arranged
	 * @param name name of Course
	 * @param title title of Course
	 * @param section section of Course
	 * @param credits credit hours for Course
	 * @param instructorId instructor's unity id
	 * @param meetingDays meeting days for the Course as a series of chars
	 */
	public Course(String name, String title, String section, int credits, String instructorId, String meetingDays) {
		this(name, title, section, credits, instructorId, meetingDays, 0, 0);
	}

	/**
	 * Returns the Course's name
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the Course's name.
	 * @param name the name to set
	 * @throws IllegalArguemntExpection if null
	 * @throws IllegalArgumentExecption if less than 5 characters or more than 8
	 * @throws IllegalArgumentException if name doesn't contain a space between letter and number characters
	 * @throws IllegalArgumentExecption if name doesn't start with 1-4 letter characters
	 * @throws IllegalArgumentException if name doesn't end with 3 digit characters
	 */
	private void setName(String name) {
		if (name == null) {
			throw new IllegalArgumentException("Name cannot be null.");
		}
		if (name.length() < MIN_NAME_LENGTH || name.length() > MAX_NAME_LENGTH) {
			throw new IllegalArgumentException("Name's length should be between 5 and 8, inclusive.");
		}
		
		int letterCount = 0;
		int digitCount = 0;
		boolean space = false;
		//Scanner in = new Scanner(name);
		for (int i = 0; i <= name.length() - 1; i++) {
			char c = name.charAt(i);
			String character = Character.toString(c);
			if (!space) {
				if (Character.isLetter(c)) {
					letterCount++;
				}
				else if (" ".equals(character)) {
					space = true;
				}
				else {
					throw new IllegalArgumentException("Names should have 1-4 letters, a space, and 3 digits.");	
					}
			}
			
			else if (space) {
				if (Character.isDigit(c)) {
					digitCount++;
				}
				else {
					throw new IllegalArgumentException("Names should have 1-4 letters, a space, and 3 digits.");
				}	
			}
		}
		//Check that the number of letters is correct
		if (letterCount < MIN_LETTER_COUNT || letterCount > MAX_LETTER_COUNT) {
			throw new IllegalArgumentException("Names should have 1-4 letters, a space, and 3 digits.");
		}
			
		if (digitCount != DIGIT_COUNT) {
			throw new IllegalArgumentException("Names should have 1-4 letters, a space, and 3 digits.");
		}
	this.name = name;
	}
	

	/**
	 * Returns the Course's title
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the Course's title
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		if (title == null || "".equals(title)) {
			throw new IllegalArgumentException("Invalid title.");
		}
		this.title = title;
	}

	/**
	 * Returns the Course's section
	 * @return the section
	 */
	public String getSection() {
		return section;
	}

	/**
	 * Sets the Course's section
	 * @param section the section to set
	 */
	public void setSection(String section) {
		if (section == null || section.length() != SECTION_LENGTH) {
			throw new IllegalArgumentException("Invalid section.");
		}
		for (int i = 0; i <= section.length() - 1; i++) {
			char c = section.charAt(i);
			if (!Character.isDigit(c)) {
				throw new IllegalArgumentException("Section should be three digits.");			
			}
		}
		this.section = section;
	}

	/**
	 * Returns the Course's credits
	 * @return the credits
	 */
	public int getCredits() {
		return credits;
	}

	/**
	 * Sets the Course's credits
	 * @param credits the credits to set
	 */
	public void setCredits(int credits) {
		if (credits < MIN_CREDITS || credits > MAX_CREDITS) {
			throw new IllegalArgumentException("Credits should be between 1 and 5, inclusive.");
		}
		try {
			String s = String.valueOf(credits);
			Integer.parseInt(s);
		}
		catch(NumberFormatException e) {
			throw new NumberFormatException("Invalid credits.");
		}
		this.credits = credits;
	}

	/**
	 * Returns the Course's Instructor
	 * @return the instructorId
	 */
	public String getInstructorId() {
		return instructorId;
	}

	/**
	 * Sets the Course's Instructor
	 * @param instructorId the instructorId to set
	 */
	public void setInstructorId(String instructorId) {
		if (instructorId == null || "".equals(instructorId)) {
			throw new IllegalArgumentException("Invalid instructor id.");
		}
		this.instructorId = instructorId;
	}

	/**
	 * Returns the Course's meeting days
	 * @return the meetingDays
	 */
	public String getMeetingDays() {
		return meetingDays;
	}
	
	/**
	 * Sets the meeting days as well as start and end times for Course.
	 * @param meetingDays meeting days expressed as a series of chars
	 * @param startTime start time of Course
	 * @param endTime end time of Course
	 * @throws IllegalArgumentException if meetingDays is null or empty
	 * @throws IllegalArgumentException if there are duplicate weekdays
	 * @throws IllegalArgumentException if starting hour is invalid
	 * @throws IllegalArgumentException if starting minute is invalid
	 * @throws IllegalArgumentException if ending hour is invalid
	 * @throws IllegalArgumentException if ending minute is invalid
	 * @throws IllegalArgumentException if start time is not a valid military time
	 * @throws IllegalArgumentException if end time is not a valid military time
	 * @throws IllegalArgumentException if end time is less than start time
	 */
	public void setMeetingDaysAndTime(String meetingDays, int startTime, int endTime) {
		if (meetingDays == null || "".equals(meetingDays)) {
			throw new IllegalArgumentException("Invalid meeting days.");
		}
		if ("A".equals(meetingDays)) {
			this.meetingDays = meetingDays;
			this.startTime = 0;
			this.endTime = 0;
		}
		else {
			int mCount = 0;
			int tCount = 0;
			int wCount = 0;
			int hCount = 0;
			int fCount = 0;
			for (int i = 0; i <= meetingDays.length() - 1; i++) {
				if (meetingDays.charAt(i) == 'M') {
					mCount++;	
				}
				else if (meetingDays.charAt(i) == 'T') {
					tCount++;	
				}
				else if (meetingDays.charAt(i) == 'W') {
					wCount++;	
				}
				else if (meetingDays.charAt(i) == 'H') {
					hCount++;	
				}
				else if (meetingDays.charAt(i) == 'F') {
					fCount++;	
				}
				else {
					throw new IllegalArgumentException("Invalid meeting days.");
				}
				
			}
			
			if (mCount > 1 || tCount > 1 || wCount > 1 || hCount > 1 || fCount > 1) {
				throw new IllegalArgumentException ("Invalid meeting days.");
			}
			
			
			int startHour = startTime / 100;
			int startMin = startTime % 100;
			int endHour = endTime / 100;
			int endMin = endTime % 100;
			
			if (startTime < 0 || startTime >= 2400) {
				throw new IllegalArgumentException("Invalid start time.");
			}
			if (endTime < 0 || endTime >= 2400) {
				throw new IllegalArgumentException("Invalid end time.");
			}
			if (startHour < 0 || startHour >= UPPER_HOUR) {
				throw new IllegalArgumentException("Invalid start time.");
			}
			if (startMin < 0 || startMin >= UPPER_MINUTE) {
				throw new IllegalArgumentException("Invalid start time.");
			}
			if (endHour < 0 || endHour >= UPPER_HOUR) {
				throw new IllegalArgumentException("Invalid end time.");
			}
			if (endMin < 0 || endMin >= UPPER_MINUTE) {
				throw new IllegalArgumentException("Invalid end time.");
			}
			if (startTime > endTime) {
				throw new IllegalArgumentException("End time cannot be before start time.");
			}
			this.meetingDays = meetingDays;
			this.startTime = startTime;
			this.endTime = endTime;
			
		}
	}

	/**
	 * Returns the Course's start time
	 * @return the startTime
	 */
	public int getStartTime() {
		return startTime;
	}
	
	/**
	 * Returns the Course's end time
	 * @return the endTime
	 */
	public int getEndTime() {
		return endTime;
	}
	
	/**
	 * Generates a hashCode for Course using all fields.
	 * @return hashCode for Course
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + credits;
		result = prime * result + endTime;
		result = prime * result + ((instructorId == null) ? 0 : instructorId.hashCode());
		result = prime * result + ((meetingDays == null) ? 0 : meetingDays.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((section == null) ? 0 : section.hashCode());
		result = prime * result + startTime;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	/**
	 * Compares a given object to this object for equality on all fields.
	 * @param obj the Object to compare
	 * @return true if the objects are the same on all fields
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		if (credits != other.credits)
			return false;
		if (endTime != other.endTime)
			return false;
		if (instructorId == null) {
			if (other.instructorId != null)
				return false;
		} else if (!instructorId.equals(other.instructorId))
			return false;
		if (meetingDays == null) {
			if (other.meetingDays != null)
				return false;
		} else if (!meetingDays.equals(other.meetingDays))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (section == null) {
			if (other.section != null)
				return false;
		} else if (!section.equals(other.section))
			return false;
		if (startTime != other.startTime)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}


	/**
	 * Creates a string of the Course object
	 * @return the string of the Course
	 */
	@Override
	public String toString() {

		if ("A".equals(meetingDays)) {
			return name + "," + title + "," + section + "," + credits + "," + instructorId + "," + meetingDays;
		}
		return name + "," + title + "," + section + "," + credits + "," + instructorId + "," + meetingDays
				+ "," + startTime + "," + endTime;
	}
	
	/**
	 * Helper method to convert military time into normal time
	 * @param time the military time you want to convert
	 * @return a string of the normal time followed by either "AM" or "PM" depending
	 */
	private String getTimeString(int time) {
		String classTime = "";
		String extraZero = "00";
		int milHour = time / 100;
		int min = time % 100;
		int normTime = 0;
		

		if (milHour > 12) {
			normTime = milHour - 12;
			if (min == 0) {
				classTime = classTime + normTime + ":" + extraZero + "PM";
			}
			else {
				classTime = classTime + normTime + ":" + min + "PM";
			}
			
		}
		else {
			normTime = milHour;
			if (min == 0) {
				classTime = classTime + normTime + ":" + extraZero + "AM";
			}
			else {
				classTime = classTime + normTime + ":" + min + "AM";
			}
		}
		return classTime;
	}
	/**
	 * Creates a string for the meeting days and times of a Course
	 * @return the string of days and times for the Course
	 */
	public String getMeetingString() {
		String meeting = "";
		String days = getMeetingDays();
		if (!"A".equals(days)) {
			int startingTime = getStartTime();
			int endingTime = getEndTime();
			String start = getTimeString(startingTime);
			String end = getTimeString(endingTime);
			meeting = meeting + days + " " + start + "-" + end;
		}
		else {
			meeting += "Arranged";
		}
		
		return meeting;
	}

}
