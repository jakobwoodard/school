/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Interface that allows the checking to see if Activities occur at the same time and day instances
 * @author Jakob Woodard
 *
 */
public interface Conflict {
	/**
	 * Method that will take an Activity and compare it with already selected activities to see if it will 
	 * conflict in a time slot
	 * @param possibleConflictingActivity the activity being tested
	 * @throws ConflictException if there is a conflict between the given Activity and already added
	 * activities
	 */
	void checkConflict(Activity possibleConflictingActivity) throws ConflictException;
}
