/**
 * 
 */
package edu.ncsu.csc216.hloj.model.manager;

import edu.ncsu.csc216.hloj.model.Customer;
import edu.ncsu.csc216.hloj.model.ModelException;
import edu.ncsu.csc216.hloj.model.lists.SortedList;

/**
 * This singleton class maintains a sorted list of Customers
 * @author Jakob Woodard
 *
 */
public class CustomerManager {

	/** Instance of CustomerManager to allow CustomerManager to be singleton */
	private static CustomerManager instance;
	/** List of customers */
	private SortedList<Customer> customers;
	
	/**
	 * Constructor for CustomerManager. Can only be used if when the getInstance() method is ran and results in instance being null
	 */
	private CustomerManager() {
		this.customers = new SortedList<Customer>();
	}
	
	/**
	 * Method to get the instance of CustomerManager to ensure that there is only one instance of it occurring at any given time.
	 * If the instance is null, then a new Customer Manager can be created using the constructor.
	 * @return instance the instance of the registration manager
	 */
	public static CustomerManager getInstance() {
		if (instance == null) {
			CustomerManager.instance = new CustomerManager();
		}
		return instance;
		
	}
	
	/**
	 * Adds a Customer to the list of customers
	 * @param c Customer to be added
	 * @throws ModelException if the Customer being added has the same id as another customer in the list
	 */
	public void addCustomer(Customer c) throws ModelException {
		
		for (int i = 0; i < customers.size(); i++) {
			if (c.getId().equals(customers.get(i).getId())) {
				throw new ModelException("A customer with this id already exists");
			}
		}
		customers.add(c);
	}
	
	/**
	 * Getter method for the list of all customers
	 * @return allCustomers the list of every customer
	 */
	public Customer[] getCustomers() {
		
		Customer[] allCustomers = new Customer[customers.size()];
		for (int i = 0; i < customers.size(); i++) {
			allCustomers[i] = customers.get(i);
		}
		return allCustomers;
	}
	
	/**
	 * Gets the customer at a specified index
	 * @param index of the wanted customer
	 * @return the Customer stored at the specific index
	 */
	public Customer getCustomer(int index) {
		return customers.get(index);
		
	}
	
	/**
	 * Gets the customer with the specified id
	 * @param id of the desired customer
	 * @return the customer with the desired id or null if the customer does not exist
	 */
	public Customer getCustomer(String id) {
		for (int i = 0; i < customers.size(); i++) {
			if (customers.get(i).getId().equals(id)) {
				return customers.get(i);
			}
		}
		return null;
		
	}
	
	/**
	 * Removes the specified customer from the list. Throws exceptions if the customer doesn't exists or if
	 * the customer does not have any open orders
	 * @param c the customer to be removed
	 * @throws ModelException if the customer being removed has an open order
	 */
	public void removeCustomer(Customer c) throws ModelException {
		for (int i = 0; i < customers.size(); i++) {
			if (OrderManager.getInstance().getOrdersByCustomer(c).length != 0) {
				throw new ModelException("Cannot remove a customer with open orders");
			}
		}
		customers.remove(c);
	}
	
	/**
	 * Replaces the Customer stored at the specified index with the provided customer. Throws a ModelException if the new customer
	 * has the same id as another customer, but different than the customer being edited, already in the system.
	 * @param index index of the customer to replace
	 * @param c customer to replace with
	 * @throws ModelException if a customer already exists within the system (excluding the one being replaced)
	 */
	public void editCustomer(int index, Customer c) throws ModelException {
		
		Customer temp = customers.get(index);
		customers.remove(index);
		try {
			addCustomer(c);
		}
		catch (ModelException e) {
			customers.add(temp);
			throw new ModelException(e.getMessage());
		}
	}
	
	/**
	 * Removes all customers from the system by creating a new SortedList of customers
	 * Used for testing to reset the instance of the CustomerManager
	 */
	public void removeAllCustomers() {
		customers = new SortedList<Customer>();
	}
}
