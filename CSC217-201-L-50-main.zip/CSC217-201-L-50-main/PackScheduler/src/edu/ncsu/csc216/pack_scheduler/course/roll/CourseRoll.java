package edu.ncsu.csc216.pack_scheduler.course.roll;


import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.user.Student;
import edu.ncsu.csc216.pack_scheduler.util.ArrayQueue;
import edu.ncsu.csc216.pack_scheduler.util.LinkedAbstractList;

/**
 * Class to be used by Course and Student in order to sign a student up for a desired class. This class checks for availability
 * within the desired course as well as if the student is already enrolled in the course. The student can also be dropped from the 
 * course using this class.
 * @author Jakob Woodard
 *
 */
public class CourseRoll {
	/** Custom LinkedAbstractList of Students */
	private LinkedAbstractList<Student> roll;
	/** The roll's enrollment cap */
	private int enrollmentCap;
	/** The smallest class size is 10 */
	private static final int MIN_ENROLLMENT = 10;
	/** The largest class size is 250 */
	private static final int MAX_ENROLLMENT = 250;
	/** Wait list of Students with initial capacity of 10 */
	private ArrayQueue<Student> waitlist = new ArrayQueue<Student>(10);
	/** Course of the course roll */
	private Course course;
	
	/**
	 * Constructor method for the CouresRoll. Creates an empty LinkedAbstractList of students with capacity equal to 
	 * the enrollment cap.
	 * @param students number of students allowed in the class
	 * @param c course associated with the roll
	 */
	public CourseRoll(int students, Course c) {
		if (c == null) {
			throw new IllegalArgumentException("Course is null");
		}
		roll = new LinkedAbstractList<Student>(students);
		setEnrollmentCap(students);
		this.course = c;
	}
	/**
	 * Getter method for the enrollmentCap
	 * @return enrollmentCap the enrollment cap of the course
	 */
	public int getEnrollmentCap() {
		return enrollmentCap;
	}
	/**
	 * Sets the enrollmentCap to the desired value. IAE is thrown if the cap is invalid
	 * @param enrollmentCap the new enrollmentCap
	 * @throws IllegalArgumentException if the desired cap is less than 10 or greater than 250
	 */
	public void setEnrollmentCap(int enrollmentCap) {
		if (enrollmentCap < MIN_ENROLLMENT || enrollmentCap > MAX_ENROLLMENT) {
			throw new IllegalArgumentException("Invalid enrollment cap");
		}
		this.enrollmentCap = enrollmentCap;
	}
	
	/**
	 * Method to enroll a student in a course. IAEs are thrown if the student is null, the capacity has been reached, 
	 * the student is already enrolled, or if there is an exception thrown when trying to add to the roll.
	 * @param s student to be added
	 * @throws IllegalArgumentException if the student is null, the capacity has been reached, 
	 * the student is already enrolled, or if there is an exception thrown when trying to add to the roll
	 */
	public void enroll (Student s) {
		
		if (s == null) {
			throw new IllegalArgumentException("Student is null");
		}
		for (int i = 0; i < roll.size() - 1; i++) {
			if (roll.get(i).equals(s)) {
				throw new IllegalArgumentException("Course cannot be added to schedule.");
			}
		}
		
		if (getOpenSeats() != 0 && canEnroll(s)) {
			roll.add(s);
			s.getSchedule().addCourseToSchedule(course);
		}
		else if (getOpenSeats() == 0 && canEnroll(s)) {
			waitlist.enqueue(s);
		}
		else if (waitlist.size() == 10) {
			throw new IllegalArgumentException("Wait list is full");
		}
		
		
	}
	/**
	 * Method to drop a student from a class. IAEs are thrown if the student is null or if an exception is created trying
	 * to remove the student to the roll
	 * @param s student to drop
	 * @throws IllegalArgumentException if the student is null or an exception is created when dropping.
	 */
	public void drop (Student s) {
		if (s == null) {
			throw new IllegalArgumentException("Student is null");
		}
		for (int i = 0; i < roll.size(); i++) {
			if (s.equals(roll.get(i))) {
				try {
					roll.remove(s);
					s.getSchedule().removeCourseFromSchedule(course);
					if (waitlist.size() != 0) {
						Student temp = waitlist.dequeue();
						roll.add(temp);
						temp.getSchedule().addCourseToSchedule(course);
					}
				}
				catch (Exception e) {
					throw new IllegalArgumentException(e.getMessage());
				}
			}
		}
		ArrayQueue<Student> temp = new ArrayQueue<Student>(10);
		temp = waitlist;
		ArrayQueue<Student> trash = new ArrayQueue<Student>(10); // Queue to hold student being extracted
		for (int i = 0; i < waitlist.size(); i++) {
			Student tempStudent = waitlist.dequeue();
			if (tempStudent.equals(s)) {
				trash.enqueue(tempStudent);
			}
			else {
				temp.enqueue(tempStudent);
			}
		}
		for (int i = 0; i < temp.size(); i++) {
			waitlist.enqueue(temp.dequeue());
		}
		
		
		
	}
	/**
	 * Returns the amount of open seats by subtracting the enrollment cap from the size of the roll
	 * @return number of open seats left
	 */
	public int getOpenSeats() {
		return enrollmentCap - roll.size();
	}
	
	/**
	 * Boolean method to see if a student can be enrolled. A student cannot be enrolled if they are already enrolled or the 
	 * enrollment capacity has already been met
	 * @param s student to be added
	 * @return true if the student can enroll, false if not
	 */
	public boolean canEnroll(Student s) {
		if (waitlist.contains(s)) {
			return false;
		}
		if (getOpenSeats() == 0 && waitlist.size() == 10 || getNumberOnWaitlist() == 10) {
			return false;
		}
		for (int i = 0; i < roll.size() - 1; i++) {
			if (roll.get(i).equals(s)) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Checks the amount of students on the wait list
	 * @return the amount of students on the wait list
	 */
	public int getNumberOnWaitlist() {
		return waitlist.size();
	}
}
