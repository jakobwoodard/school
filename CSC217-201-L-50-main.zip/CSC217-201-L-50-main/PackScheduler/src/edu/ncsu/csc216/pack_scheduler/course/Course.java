/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

import edu.ncsu.csc216.pack_scheduler.course.roll.CourseRoll;
import edu.ncsu.csc216.pack_scheduler.course.validator.CourseNameValidator;
import edu.ncsu.csc216.pack_scheduler.course.validator.InvalidTransitionException;

/**
 * Class for adding/creating Courses
 * @author Jakob Woodard
 *
 */
public class Course extends Activity implements Comparable<Course> {
	/** Minimum length of a name */
	private static final int MIN_NAME_LENGTH = 4;
	/** Maximum length of a name */
	private static final int MAX_NAME_LENGTH = 7;
//	/** Minimum amount of letters */
//	private static final int MIN_LETTER_COUNT = 1;
//	/** Maximum amount of letters */
//	private static final int MAX_LETTER_COUNT = 4;
//	/** Amount of digits */
//	private static final int DIGIT_COUNT = 3;
	/** Length of the section */
	private static final int SECTION_LENGTH = 3;
	/** Maximum amount of credits */
	private static final int MAX_CREDITS = 5;
	/** Minimum amount of credits */
	private static final int MIN_CREDITS = 1;
	/** Course's name. */
	private String name;
	/** Course's section. */
	private String section;
	/** Course's credit hours */
	private int credits;
	/** Course's instructor */
	private String instructorId;
	/** Validator for courses */
	private CourseNameValidator validator = new CourseNameValidator();
	/** Course roll */
	private CourseRoll roll;
	/**
	 * Constructs a Course object with values for all fields
	 * @param name name of the Course
	 * @param title title of the Course
	 * @param section section of the Course
	 * @param credits credit hours for the Course
	 * @param instructorId instructor's unity id
	 * @param enrollmentCap the enrollmentCap of the course
	 * @param meetingDays meeting days for the Course as a series of chars
	 * @param startTime starting time of the Course
	 * @param endTime ending time of the Course
	 */
	public Course(String name, String title, String section, int credits, String instructorId, int enrollmentCap, String meetingDays,
			int startTime, int endTime) {
			super(title, meetingDays, startTime, endTime);
			setName(name);
			setSection(section);
			setCredits(credits);
			setInstructorId(instructorId);
			this.roll = new CourseRoll(enrollmentCap, this);

	}
	

	/**
	 * Creates a Course with the given name, title, section, credits, instructorId, and meetingDays for
	 * courses that are arranged
	 * @param name name of Course
	 * @param title title of Course
	 * @param section section of Course
	 * @param credits credit hours for Course
	 * @param instructorId instructor's unity id
	 * @param enrollmentCap the enrollmentCap of the course
	 * @param meetingDays meeting days for the Course as a series of chars
	 */
	public Course(String name, String title, String section, int credits, String instructorId, int enrollmentCap, String meetingDays) {
		super(title, meetingDays, 0, 0);
			setName(name);
		    setSection(section);
		    setCredits(credits);
		    setInstructorId(instructorId);
		    this.roll = new CourseRoll(enrollmentCap, this);
		
		
	}

	/**
	 * Returns the Course's name
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the Course's name. Throws IAEs if the name is null or if it is not between 5 and 8 characters inclusive.
	 * Also creates a letter and digit count. These counts are used to throw IAEs if there is not 1-4 letters in a name followed
	 * by a space character and 3 digits exactly.
	 * @param name the name to set
	 * @throws IllegalArguemntExpection if null
	 * @throws IllegalArgumentExecption if less than 5 characters or more than 8
	 * @throws IllegalArgumentException if name doesn't contain a space between letter and number characters
	 * @throws IllegalArgumentExecption if name doesn't start with 1-4 letter characters
	 * @throws IllegalArgumentException if name doesn't end with 3 digit characters
	 */
	private void setName(String name) {
		if (name == null) {
			throw new IllegalArgumentException("Invalid name");
		}
		if (name.length() < MIN_NAME_LENGTH || name.length() > MAX_NAME_LENGTH) {
			throw new IllegalArgumentException("Invalid name");
		}
//		
//		int letterCount = 0;
//		int digitCount = 0;
//		boolean space = false;
//		//Scanner in = new Scanner(name);
//		for (int i = 0; i <= name.length() - 1; i++) {
//			char c = name.charAt(i);
//			String character = Character.toString(c);
//			if (!space) {
//				if (Character.isLetter(c)) {
//					letterCount++;
//				}
//				else if (" ".equals(character)) {
//					space = true;
//				}
//				else {
//					throw new IllegalArgumentException("Invalid course name");	
//					}
//			}
//			
//			else if (space) {
//				if (Character.isDigit(c)) {
//					digitCount++;
//				}
//				else {
//					throw new IllegalArgumentException("Invalid course name");
//				}	
//			}
//		}
//		//Check that the number of letters is correct
//		if (letterCount < MIN_LETTER_COUNT || letterCount > MAX_LETTER_COUNT) {
//			throw new IllegalArgumentException("Invalid course name");
//		}
//			
//		if (digitCount != DIGIT_COUNT) {
//			throw new IllegalArgumentException("Invalid course name");
//		}
		try {
			validator.isValid(name);
		} catch (InvalidTransitionException e) {
			throw new IllegalArgumentException("Invalid name");
		}
	this.name = name;
	}
	

	/**
	 * Returns the Course's section
	 * @return the section
	 */
	public String getSection() {
		return section;
	}

	/**
	 * Sets the Course's section. Throws IAEs if the section is null or not exactly 3 digits or if the section contains letters.
	 * @param section the section to set
	 * @throws IllegalArgumentException if the section is null or not 3 characters
	 * @throws IllegalArgumentException if the section contains anything that is not a digit
	 */
	public void setSection(String section) {
		if (section == null || section.length() != SECTION_LENGTH) {
			throw new IllegalArgumentException("Invalid section number");
		}
		for (int i = 0; i <= section.length() - 1; i++) {
			char c = section.charAt(i);
			if (!Character.isDigit(c)) {
				throw new IllegalArgumentException("Invalid section number");			
			}
		}
		this.section = section;
	}

	/**
	 * Returns the Course's credits
	 * @return the credits
	 */
	public int getCredits() {
		return credits;
	}

	/**
	 * Sets the Course's credits. Throws an IAE if the credits are not between 3 and 15 inclusive. Throws a NFE if the value being read-in is 
	 * not an integer.
	 * @param credits the credits to set
	 * @throws IllegalArgumentException if the credits are not between 3 and 15 inclusive
	 * @throws NumberFormatException if the string being read-in cannot be turned into an integer.
	 */
	public void setCredits(int credits) {
		if (credits < MIN_CREDITS || credits > MAX_CREDITS) {
			throw new IllegalArgumentException("Credits should be between 1 and 5, inclusive.");
		}
		try {
			String s = String.valueOf(credits);
			Integer.parseInt(s);
		}
		catch(NumberFormatException e) {
			throw new NumberFormatException("Invalid credits.");
		}
		this.credits = credits;
	}

	/**
	 * Returns the Course's Instructor
	 * @return the instructorId
	 */
	public String getInstructorId() {
		return instructorId;
	}

	/**
	 * Sets the Course's Instructor. If the instructor id is null or empty, an IAE is thrown.
	 * @param instructorId the instructorId to set
	 * @throws IllegalArgumentException if the instructor id is null/empty.
	 */
	public void setInstructorId(String instructorId) {
		if ("".equals(instructorId)) {
			throw new IllegalArgumentException("Invalid instructor unity id");
		}
		this.instructorId = instructorId;
	}
	/**
	 * Method to create a string of a Course
	 * @return the string of the course.
	 */
	public String toString() {
		if ("A".equals(getMeetingDays())) {
			return name + "," + getTitle() + "," + section + "," + credits + "," + instructorId + "," + roll.getEnrollmentCap() + "," + getMeetingDays();
		}
		return name + "," + getTitle() + "," + section + "," + credits + "," + instructorId + "," + roll.getEnrollmentCap() + "," + getMeetingDays() + ","
				+ getStartTime() + "," + getEndTime();
	}
	
	/**
	 * Checks to see if an activity is a duplicate or not
	 * @param activity the activity checking for a repeat
	 * @return true if it is a duplicate
	 */
	public boolean isDuplicate(Activity activity) {
		if (activity instanceof Course) {
			return ((Course) activity).getName().equals(getName());
			}
		return false;
		}



	/**
	 * Overrides setMeetingDaysAndTime to be usable for just Course implementation. Creates a counter for each applicable day in a meeting string
	 * if the day is not applicable, an IAE is thrown. Throws IAEs if days appear more than once in the meetingDays string
	 * @param meetingDays a string of characters representing meeting days
	 * @param startTime the start time of the Course
	 * @param endTime the end time of the Course
	 */
	@Override
	public void setMeetingDaysAndTime(String meetingDays, int startTime, int endTime) {
		if ("A".equals(meetingDays)) {
			super.setMeetingDaysAndTime(meetingDays, startTime, endTime);
		}
		else {
			int mCount = 0;
			int tCount = 0;
			int wCount = 0;
			int hCount = 0;
			int fCount = 0;
			for (int i = 0; i <= meetingDays.length() - 1; i++) {
				if (meetingDays.charAt(i) == 'M') {
					mCount++;	
				}
				else if (meetingDays.charAt(i) == 'T') {
					tCount++;	
				}
				else if (meetingDays.charAt(i) == 'W') {
					wCount++;	
				}
				else if (meetingDays.charAt(i) == 'H') {
					hCount++;	
				}
				else if (meetingDays.charAt(i) == 'F') {
					fCount++;	
				}
				else {
					throw new IllegalArgumentException("Invalid meeting days");
				}
				
			}
			
			if (mCount > 1 || tCount > 1 || wCount > 1 || hCount > 1 || fCount > 1) {
				throw new IllegalArgumentException ("Invalid meeting days");
			}
			
			
		}
		super.setMeetingDaysAndTime(meetingDays, startTime, endTime);
	}


	/**
	 * Creates the hashCode for a Course
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + credits;
		result = prime * result + ((instructorId == null) ? 0 : instructorId.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((section == null) ? 0 : section.hashCode());
		return result;
	}

	/**
	 * Checks to see that two Courses are equal
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		if (credits != other.credits)
			return false;
		if (instructorId == null) {
			if (other.instructorId != null)
				return false;
		} else if (!instructorId.equals(other.instructorId))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (section == null) {
			if (other.section != null)
				return false;
		} else if (!section.equals(other.section))
			return false;
		return true;
	}

	/**
	 * Creates an array for a display with name, section, title, and meeting string.
	 * @return the shortened array.
	 */
	@Override
	public String[] getShortDisplayArray() {
		String[] shortDisplay =  new String[5];
		shortDisplay[0] = getName();
		shortDisplay[1] = section;
		shortDisplay[2] = getTitle();
		shortDisplay[3] = getMeetingString();
		shortDisplay[4] = Integer.toString(roll.getOpenSeats());
		return shortDisplay;
	}

	/**
	 * Creates an array for a display with name, section, title, credits, instructorId, and meeting string
	 * as well as an empty string for an event
	 * @return the longer array
	 */
	@Override
	public String[] getLongDisplayArray() {
		String[] longDisplay =  new String[7];
		longDisplay[0] = getName();
		longDisplay[1] = section;
		longDisplay[2] = getTitle();
		longDisplay[3] = Integer.toString(getCredits());
		longDisplay[4] = getInstructorId();
		longDisplay[5] = getMeetingString();
		longDisplay[6] = "";
		return longDisplay;
	}


	@Override
	public int compareTo(Course o) {
		//.this comes before compared
				if (this.getName().compareToIgnoreCase(o.getName()) < 0) {
					return -1;
				}
				//.this comes after compared
				if (this.getName().compareToIgnoreCase(o.getName()) > 0) {
					return 1;
				}
				if (this.getName().compareToIgnoreCase(o.getName()) == 0) {
					//.this comes before compared
					if (this.getTitle().compareToIgnoreCase(o.getTitle()) < 0) {
						return -1;
					}
					//.this comes after compared
					if (this.getTitle().compareToIgnoreCase(o.getTitle()) > 0) {
						return 1;
					}
					if (this.getTitle().compareToIgnoreCase(o.getTitle()) == 0) {
						//.this comes before compared
						if (this.getSection().compareToIgnoreCase(o.getSection()) < 0) {
							return -1;
						}
						//.this comes after compared
						if (this.getSection().compareToIgnoreCase(o.getSection()) > 0) {
							return 1;
						}
						//.this and compared have same order
						if (this.getSection().compareToIgnoreCase(o.getSection()) == 0) {
							return 0;
						}
					}
				}
				//This should never be reached
				return credits;
	}
	
	/**
	 * Getter method for the roll of a course.
	 * @return roll the roll of the course
	 */
	public CourseRoll getCourseRoll() {
		return roll;
	}
	
	

}
