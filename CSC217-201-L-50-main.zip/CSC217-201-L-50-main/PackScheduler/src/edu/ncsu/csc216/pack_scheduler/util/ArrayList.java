/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.AbstractList;

/**
 * Custom ArrayList class to be used to manipulate the schedule
 * @author Jakob Woodard
 * @param <E> generic object type to be held in the list
 */
public class ArrayList<E> extends AbstractList<E> {
	/** Initial size of the ArrayList */
	static final int INIT_SIZE = 10;
	/** Instance of the list */
	private E[] list;
	/** Current size of the list */
	private int size;
	/**
	 * Constructor for the ArrayList. When first constructed, the list has a size of 10.
	 */
	@SuppressWarnings("unchecked")
	public ArrayList() {
		list = (E[]) new Object[INIT_SIZE];
		this.size = 0;
	}
	/**
	 * Method to add an element to the array list
	 * @param idx index to be added at
	 * @param element element to be added
	 * @throws NullPointerException if the element is null
	 * @throws IndexOutOfBoundsException if the index is invalid
	 * @throws IllegalArgumentException if the element already exists in the list
	 */
	public void add(int idx, E element) {
		if (element == null) {
			throw new NullPointerException("Element is null");
		}
		if (idx < 0 || idx > size()) {
			throw new IndexOutOfBoundsException("Index of " + idx + " is out of bounds for size " + size);
		}
		if (list.length == size()) {
			growArray();
		}
		for (int i = 0; i < size; i++) {
			if (element.equals(list[i])) {
				throw new IllegalArgumentException("Element already exists");
			}
		}
		for (int i = size - 1; i >= idx; i--) {
			list[i + 1] = list[i];
		}
		list[idx] = element;
		size++;
		
	}
	
	/**
	 * Method to grow the size of the array if the capacity is the same as the size. A new list is created with double the size and the values from
	 * the first list are copied over. This only happens if the size of the list divided by 
	 */
	@SuppressWarnings("unchecked")
	private void growArray() {
		E[] list2 = (E[]) new Object[size * 2];
		for (int i = 0; i < size; i++) {
			list2[i] = list[i];
		}
		this.list = list2;
		
	}
	/**
	 * Removes the element from the list at the given index and shifts the rest of the list to fit.
	 * @param idx index to be removed
	 * @return the value being removed
	 */
	@Override
	public E remove(int idx) {
		if (idx < 0 || idx > size()) {
			throw new IndexOutOfBoundsException("Index of " + idx + " is out of bounds for size " + size);
		}
		E value = list[idx];
		for (int i = idx; i < size - 1; i++) {
			list[i] = list[i + 1];
		}
		list[size - 1] = null;
		size--;
		return value;
	}
	/**
	 * Sets the value of the given index to the desired element
	 * @param idx index to be changed
	 * @param element element to be changed with
	 * @return new element at the given value
	 */
	@Override
	public E set(int idx, E element) {
		if (element == null) {
			throw new NullPointerException("Element is null");
		}
		if (idx < 0 || idx > size()) {
			throw new IndexOutOfBoundsException("Index of " + idx + " is out of bounds for size " + size);
		}
		for (int i = 0; i < size; i++) {
			if (element.equals(list[i])) {
				throw new IllegalArgumentException("Element already exists");
			}
		}
		list[idx] = element;
		return list[idx];
	}
	
	
	@Override
	public E get(int index) {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Index of " + index + " is out of bounds for size " + size);
		}
		return list[index];
	}
	
	@Override
	public int size() {
		return size;
	}

}
