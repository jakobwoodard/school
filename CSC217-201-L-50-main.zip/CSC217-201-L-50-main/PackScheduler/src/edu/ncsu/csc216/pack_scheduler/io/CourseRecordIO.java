package edu.ncsu.csc216.pack_scheduler.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.manager.RegistrationManager;
import edu.ncsu.csc217.collections.list.SortedList;

/**
 * Class to read and write Course Records
 * @author Jakob Woodard
 *
 */
public class CourseRecordIO {
	/**
	 * Reads in a given course record and generates a valid list of Courses. Invalid Courses
	 * are ignored and a FNFE is thrown if permissions are incorrect or if a file cannot be
	 * read
	 * @param fileName name of file being read in
	 * @return a list of valid Courses
	 * @throws FileNotFoundException if no file could be found
	 */
	public static SortedList<Course> readCourseRecords(String fileName) throws FileNotFoundException {
		Scanner fileReader = new Scanner(new FileInputStream(fileName));  //Create a file scanner to read the file
	    SortedList<Course> courses = new SortedList<Course>(); //Create an empty array of Course objects
	    while (fileReader.hasNextLine()) { //While we have more lines in the file
	        try { //Attempt to do the following
	            //Read the line, process it in readCourse, and get the object
	            //If trying to construct a Course in readCourse() results in an exception, flow of control will transfer to the catch block, below
	            Course course = readCourse(fileReader.nextLine()); 

	            //Create a flag to see if the newly created Course is a duplicate of something already in the list  
	            boolean duplicate = false;
	            //Look at all the courses in our list
	            for (int i = 0; i < courses.size(); i++) {
	                //Get the course at index i
	                Course current = courses.get(i);
	                //Check if the name and section are the same
	                if (course.getName().equals(current.getName()) &&
	                        course.getSection().equals(current.getSection())) {
	                    //It's a duplicate!
	                    duplicate = true;
						break; //We can break out of the loop, no need to continue searching
	                }
	            }
	            //If the course is NOT a duplicate
	            if (!duplicate) {
	                courses.add(course); //Add to the ArrayList!
	            } //Otherwise ignore
	        } catch (IllegalArgumentException e) {
	        	fileReader.nextLine();
	            //The line is invalid b/c we couldn't create a course, skip it!
	        }
	    }
	    //Close the Scanner b/c we're responsible with our file handles
	    fileReader.close();
	    //Return the ArrayList with all the courses we read!
	    return courses;
	}
	/**
	 * Helper method for the readCourseRecords method
	 * @param nextLine the next line of code being read
	 * @return null no info is needed for return
	 */
	private static Course readCourse(String nextLine) {
		Scanner in = new Scanner(nextLine);
		in.useDelimiter(",");
		String name = "";
		String title = "";
		String section = "";
		int credits = 0;
		String instructorId = "";
		int cap = 0;
		String meetingDays = "";
		int startTime = 0;
		int endTime = 0;
		while (in.hasNext()) {
			try {
				name = in.next();
				title = in.next();
				section = in.next();
				credits = in.nextInt();
				instructorId = in.next();
				cap = in.nextInt();
				meetingDays = in.next();
				if ("A".equals(meetingDays)) {
					break;
				}
				startTime = in.nextInt();
				endTime = in.nextInt();
			}
			catch (Exception e) {
				throw new IllegalArgumentException();
			}
		}
		in.close();
		if ("A".equals(meetingDays)) {
			Course course = new Course(name, title, section, credits, null, cap, meetingDays);
			startTime = 0;
			endTime = 0;
			if (RegistrationManager.getInstance().getFacultyDirectory().getFacultyById(instructorId) != null) {
				RegistrationManager.getInstance().getFacultyDirectory().getFacultyById(instructorId).getSchedule().addCourseToSchedule(course);
			}
			return course;
		}
		else {
			Course course = new Course(name, title, section, credits, null, cap, meetingDays,
			startTime, endTime);
			if (RegistrationManager.getInstance().getFacultyDirectory().getFacultyById(instructorId) != null) {
				RegistrationManager.getInstance().getFacultyDirectory().getFacultyById(instructorId).getSchedule().addCourseToSchedule(course);
			}
			return course;
		}
	}

	/**
	 * Writes a given list of Courses to
	 * @param fileName name of file to write schedule of Courses to
	 * @param catalog list of courses to write
	 * @throws IOException if cannot write to file
	 */
	public static void writeCourseRecords(String fileName, SortedList<Course> catalog) throws IOException {
		PrintStream fileWriter = new PrintStream(new File(fileName));

		for (int i = 0; i < catalog.size(); i++) {
		    fileWriter.println(catalog.get(i).toString());
		}

		fileWriter.close();
	}
}
