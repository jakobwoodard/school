/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.user;

import edu.ncsu.csc216.pack_scheduler.user.schedule.FacultySchedule;

/**
 * The Faculty class represents an individual faculty record. Faculty extends User and its implementation 
 * is similar to the implementation of Student. The main difference is that Faculty objects have a number 
 * of courses they can teach in a given semester
 * @author Jakob Woodard
 *
 */
public class Faculty extends User {

	/** Amount of courses a faculty member teaches */
	private int maxCourses;
	/** Minimum number of courses a faculty member can teach */
	public static final int MIN_COURSES = 1;
	/** Max number of courses a faculty member can teach */
	public static final int MAX_COURSES = 3;
	/** Schedule of a faculty member */
	private FacultySchedule schedule;
	
	/**
	 * Constructor for a faculty member, uses the constructor for a User for all parameters except maxCourses
	 * @param firstName first name of the faculty member
	 * @param lastName last name of the faculty member
	 * @param id id of the faculty member
	 * @param email email of the faculty member
	 * @param password password of the faculty member
	 * @param maxCourses the amount of courses the faculty member is teaching.
	 */
	public Faculty(String firstName, String lastName, String id, String email, String password, int maxCourses) {
		super(firstName, lastName, id, email, password);
		setMaxCourses(maxCourses);
		schedule = new FacultySchedule(id);
	}
	
	/**
	 * Sets the number of courses that a faculty member is teaching Throws an IAE if the amount is less than 1 or greater than 3
	 * @param courses the amount of courses being set to
	 */
	public void setMaxCourses(int courses) {
		if (courses < MIN_COURSES || courses > MAX_COURSES) {
			throw new IllegalArgumentException("Invalid number of courses");
		}
		this.maxCourses = courses;
	}
	
	/**
	 * Gets the amount of courses that a faculty member is teaching
	 * @return maxCourses the amount of courses a faculty member is teaching
	 */
	public int getMaxCourses() {
		return maxCourses;
	}
	
	/**
	 * Gets the schedule of the faculty
	 * @return schedule the schedule of the faculty
	 */
	public FacultySchedule getSchedule() {
		return schedule;
	}
	
	/**
	 * Method to see if a faculty memeber is overloaded
	 * @return true if the number of scheduled courses is greater than the faculty member's max courses
	 */
	public boolean isOverloaded() {
		return getSchedule().getNumScheduledCourses() > maxCourses;
	}

	/**
	 * Creates a hash-code for the faculty object
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + maxCourses;
		return result;
	}

	/**
	 * Creates a boolean to assert that a given faculty member is actually a faculty member
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Faculty other = (Faculty) obj;
		return maxCourses == other.maxCourses;
	}
	
	/**
	 * Creates a string representation of a faculty member to be used by the reader and writer
	 */
	@Override
	public String toString() {
		return getFirstName() + "," + getLastName() + "," + getId() + "," + getEmail()
		+ "," + getPassword() + "," + maxCourses;
	}
	
}
