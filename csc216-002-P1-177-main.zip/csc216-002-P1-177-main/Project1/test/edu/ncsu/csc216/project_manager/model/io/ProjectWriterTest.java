package edu.ncsu.csc216.project_manager.model.io;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

import org.junit.Test;

/**
 * Test calss for ProjectWriter
 * @author Jakob Woodard
 *
 */
public class ProjectWriterTest {

	/**
	 * Tests that projects are correctly written to a file, checked manually
	 */
	@Test
	public void testWriteProjectToFile() {
		try {
			ProjectWriter.writeProjectToFile("test-files/project1_actual.txt", ProjectReader.readProjectFile("test-files/project1.txt").get(0));
			assertTrue(checkFiles("test-files/project1_actual.txt", "test-files/project1.txt"));
		} 
		catch (Exception e) {
			throw new IllegalArgumentException("Unable to write to file");
		}
		
	}
	
	/**
	 * Helper method to compare two files for the same contents
	 * @param expFile expected output
	 * @param actFile actual output
	 * @return true if the files are matching
	 */
	private boolean checkFiles(String expFile, String actFile) {
	    try {
	        Scanner expScanner = new Scanner(new FileInputStream(expFile));
	        Scanner actScanner = new Scanner(new FileInputStream(actFile));
	        
	        while (expScanner.hasNextLine()  && actScanner.hasNextLine()) {
	            String exp = expScanner.nextLine();
	            String act = actScanner.nextLine();
	            assertEquals("Expected: " + exp + " Actual: " + act, exp, act);
	        }
	        if (expScanner.hasNextLine()) {
	            fail("The expected results expect another line " + expScanner.nextLine());
	        }
	        if (actScanner.hasNextLine()) {
	            fail("The actual results has an extra, unexpected line: " + actScanner.nextLine());
	        }
	        
	        expScanner.close();
	        actScanner.close();
	    } catch (IOException e) {
	        fail("Error reading files.");
	    }
	    return true;
	}
}

