package edu.ncsu.csc216.pack_scheduler.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.pack_scheduler.user.Faculty;
import edu.ncsu.csc216.pack_scheduler.util.LinkedList;

/**
 * Input/Output processes for the faculty class. Very similar to the StudenRecordsIO except that the return type for reading a 
 * faculty record is a LinkedList of faculty members
 * @author Jakob Woodard
 *
 */
public class FacultyRecordIO {
	/**
	 * Reads in a faculty record and generates a valid list of directories. Invalid faculty are
	 * ignored and a FNFE is thrown if permissions are incorrect or if a file cannot be
	 * read
	 * @param fileName name of file being read
	 * @return a list of valid directories
	 * @throws FileNotFoundException if the file could not be found
	 */
	public static LinkedList<Faculty> readFacultyRecords(String fileName) throws FileNotFoundException {
		Scanner fileReader = new Scanner(new FileInputStream(fileName));  //Create a file scanner to read the file
	    LinkedList<Faculty> faculty = new LinkedList<Faculty>(); //Create an empty array of Faculty objects
	    while (fileReader.hasNextLine()) { //While we have more lines in the file
	        try { //Attempt to do the following
	            //Read the line, process it in readFaculty, and get the object
	            //If trying to construct a Faculty in readFaculty() results in an exception, flow of control will transfer to the catch block, below
	            Faculty fac = processFaculty(fileReader.nextLine()); 

	            //Create a flag to see if the newly created Faculty is a duplicate of something already in the list  
	            boolean duplicate = false;
	            //Look at all the Faculty in our list
	            for (int i = 0; i < faculty.size(); i++) {
	                //Get the student at index i
	                Faculty current = faculty.get(i);
	                //Check if the first and last names are the same
	                if (fac.getFirstName().equals(current.getFirstName()) &&
	                        fac.getLastName().equals(current.getLastName())) {
	                    //It's a duplicate!
	                    duplicate = true;
						break; //We can break out of the loop, no need to continue searching
	                }
	            }
	            //If the faculty is NOT a duplicate
	            if (!duplicate) {
	                faculty.add(fac); //Add to the LinkedList!
	            } //Otherwise ignore
	        } 
	        catch (IllegalArgumentException e) {
	        	try {
	        		fileReader.nextLine();
	        	}
	        	catch (NoSuchElementException f) {
	        		break;
	        	}
	            //The line is invalid b/c we couldn't create a faculty, skip it!
	        }
	    }
	    //Close the Scanner b/c we're responsible with our file handles
	    fileReader.close();
	    //Return the LinkedList with all the faculty we read!
	    return faculty;
	}
	/**
	 * Helper method for the readFacultyRecords method	
	 * @param nextLine next line of file being read
	 * @return processed faculty
	 */
	private static Faculty processFaculty(String nextLine) {
			Scanner in = new Scanner(nextLine);
			in.useDelimiter(",");
			String first = "";
			String last = "";
			String id = "";
			String email = "";
			String password = "";
			int courses = 0;
			while (in.hasNext()) {
				try {
					first = in.next();
					last = in.next();
					id = in.next();
					email = in.next();
					password = in.next();
					if (!in.hasNext()) {
						in.close();
						throw new IllegalArgumentException();
					}
					courses = in.nextInt();	
				}
				catch (NoSuchElementException e) {
					throw new IllegalArgumentException();
				}
			}
			Faculty faculty = new Faculty(first, last, id, email, password, courses);
			in.close();
			return faculty;
		}
	/**
	 * Writes a list of faculty records onto a file
	 * @param fileName name of file to write Faculty to
	 * @param facultyDirectory list of faculty to write
	 * @throws IOException if cannot write to a file
	 */
	public static void writeFacultyRecords(String fileName, LinkedList<Faculty> facultyDirectory) throws IOException {
		PrintStream fileWriter = new PrintStream(new File(fileName));

		for (int i = 0; i < facultyDirectory.size(); i++) {
		    fileWriter.println(facultyDirectory.get(i).toString());
		}

		fileWriter.close();
		
	}

}
