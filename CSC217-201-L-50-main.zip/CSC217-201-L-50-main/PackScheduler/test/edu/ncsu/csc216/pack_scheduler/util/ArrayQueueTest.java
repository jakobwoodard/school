/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Test cases for ArrayQueue class
 * @author Jakob Woodard
 *
 */
public class ArrayQueueTest {

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.util.ArrayQueue#enqueue(java.lang.Object)}.
	 */
	@Test
	public void testEnqueue() {
		ArrayQueue<String> ar = new ArrayQueue<String>(0);
		
		assertTrue(ar.isEmpty());
		
		try {
			ar.enqueue("1");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Queue is full", e.getMessage());
		}
		
		ar.setCapacity(10);
		
		ar.enqueue("Zero");
		
		
		assertFalse(ar.isEmpty());
		
		assertEquals(1, ar.size());
		
		ar.enqueue("One");
		ar.enqueue("Two");
		ar.enqueue("Three");
		
		assertTrue(ar.contains("One"));
		assertFalse(ar.contains("Seven"));
		
		assertEquals("Zero", ar.dequeue());
		assertEquals("One", ar.dequeue());
		assertEquals("Two", ar.dequeue());
		assertEquals("Three", ar.dequeue());
		
		try {
			ar.dequeue();
			fail();
		}
		catch (NoSuchElementException e) {
			assertEquals("No element in queue", e.getMessage());
		}
		
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.util.ArrayQueue#setCapacity(int)}.
	 */
	@Test
	public void testSetCapacity() {
		ArrayQueue<String> ar = new ArrayQueue<String>(0);
		ar.setCapacity(10);
		
		try {
			ar.setCapacity(-1);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid capacity", e.getMessage());
		}
		
		ar.setCapacity(2);
		ar.enqueue("One");
		ar.enqueue("Two");
		
		try {
			ar.setCapacity(1);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid capacity", e.getMessage());
		}
	}

}
