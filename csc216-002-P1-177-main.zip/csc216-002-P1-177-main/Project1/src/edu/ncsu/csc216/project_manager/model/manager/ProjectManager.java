/**
 * 
 */
package edu.ncsu.csc216.project_manager.model.manager;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import edu.ncsu.csc216.project_manager.model.command.Command;
import edu.ncsu.csc216.project_manager.model.io.ProjectReader;
import edu.ncsu.csc216.project_manager.model.io.ProjectWriter;
import edu.ncsu.csc216.project_manager.model.user_story.UserStory;

/**
 * Only one instance of ProjectManager can be created. ProjectManager controls the creation and modification of many Projects.
 * @author Jakob Woodard
 *
 */
public class ProjectManager {
	
	/** Current project being worked on */
	private Project currentProject;
	/** All current projects */
	private ArrayList<Project> projects;
	/** Singleton for ProjectManager */
	private static ProjectManager singleton = null;
	
	/**
	 * Constructor class for ProjectManager. It's private to adhere to the singleton design
	 */
	private ProjectManager() {
		this.currentProject = null;
		this.projects = new ArrayList<Project>();
	}
	
	/**
	 * Checks to see if the singleton is null, if so then ProjectManager() is called, creating a single instance and returning said instance.
	 * @return singleton a singleton instance of ProjectManager
	 */
	public static ProjectManager getInstance() {
		if (singleton == null) {
			ProjectManager.singleton = new ProjectManager();
			return ProjectManager.singleton;
		}
		return singleton;
		
	}
	
	/**
	 * Writes the project to the file using the ProjectWriter class. If the currentProject is null or there are no UserStorys in the project,
	 * an IAE is thrown
	 * @param fileName name of the file to write to
	 * @throws IllegalArgumentException if currentProject is null or there are no UserStorys in the currentProject
	 * @throws IllegalArgumentException if the file cannot be written to
	 */
	public void saveCurrentProjectToFile(String fileName) {
		if (currentProject == null) {
			throw new IllegalArgumentException("Current Project is null");
		}
		if (currentProject.getUserStories().size() == 0) {
			throw new IllegalArgumentException("No UserStories in the Current Project");
		}
		try {
			ProjectWriter.writeProjectToFile(fileName, currentProject);
		} catch (Exception e) {
			throw new IllegalArgumentException("Unable to save file.");
		}
	}
	
	/**
	 * Uses the ProjectReader to read the given file, the returned list of Project are then added to the projects field. The first project in the list
	 * is returned from ProjectReader and is made the currentProject
	 * @param fileName name of the file being loaded from
	 * @throws IllegalArgumentException if the wanted file cannot be read
	 */
	public void loadProjectsFromFile(String fileName) {
		try {
			for (int i = 0; i < ProjectReader.readProjectFile(fileName).size(); i++) {
				projects.add(ProjectReader.readProjectFile(fileName).get(i));
				currentProject = ProjectReader.readProjectFile(fileName).get(0);
			}
//			currentProject = ProjectReader.readProjectFile(fileName).get(0);
		}
		catch (Exception e) {
			throw new IllegalArgumentException("Unable to save file."); 
		}
		
	}
	
	/**
	 * Creates a new Project with the given name and adds it to the end of the projects list. The project is then loaded as the currentProject through loadProject()
	 * @param projectName name of the project being created
	 */
	public void createNewProject(String projectName) {
		Project newProject = new Project(projectName);
		projects.add(projects.size(), newProject);
		loadProject(projectName);
	}
	
	/**
	 * Returns a 2D object array that is used to populate the UserStoryTableModel in the GUI with information. Objects store as [row][column] and has 1 row for every 
	 * UserStory that is being returned, with 4 total columns
	 * @return stories the 2D object array of stories
	 */
	public String[][] getUserStoriesAsArray() {
		if (currentProject == null) {
			return null;
		}
		String[][] stories = new String[currentProject.getUserStories().size()][4];
		for (int i = 0; i < currentProject.getUserStories().size(); i++) {
			int id = currentProject.getUserStories().get(i).getId();
			String stringId = Integer.toString(id);
			stories[i][0] = stringId;
			String state = currentProject.getUserStories().get(i).getState();
			stories[i][1] = state;
			String title = currentProject.getUserStories().get(i).getTitle();
			stories[i][2] = title;
			String developerId = currentProject.getUserStories().get(i).getDeveloperId();
			stories[i][3] = developerId;
		}
		return stories;
		
	}
	
	/**
	 * Returns the UserStory of a project by a given id
	 * @param id of the story
	 * @return story with associated id
	 */
	public UserStory getUserStoryById(int id) {
		UserStory story = null;
		if (currentProject == null || currentProject.getUserStories().size() == 0) {
			return null;
		}
		for (int i = 0; i < currentProject.getUserStories().size(); i++) {
			if (currentProject.getUserStories().get(i).getId() == id) {
				story = currentProject.getUserStories().get(i);
			}
			else {
				return story;
			}
		}
		return story;
		
	}
	
	/**
	 * Executed the given command c on a story with the given id
	 * @param id of the story whom the command is acting on
	 * @param c the command being done
	 */
	public void executeCommand(int id, Command c) {
		if (currentProject == null || currentProject.getUserStories().size() == 0) {
			return;
		}
		currentProject.executeCommand(id, c);
	}
	
	/**
	 * Removes a UserStory with a given id
	 * @param id of the story being removed
	 */
	public void deleteUserStoryById(int id) {
		if (currentProject == null || currentProject.getUserStories().size() == 0) {
			return;
		}
		currentProject.deleteUserStoryById(id);
	}
	
	/**
	 * Adds a UserStory with the given information to a project
	 * @param title of the story
	 * @param user of the story
	 * @param action to be done to the story statement
	 * @param value of the story statement
	 */
	public void addUserStoryToProject(String title, String user, String action, String value) {
		currentProject.addUserStory(title, user, action, value);
	}
	
	/**
	 * Finds the Project with the given name in the list, makes it the currentProject, and sets the user story id for the project
	 * so that any new UserStorys added to the project are created with the next correct id.
	 * @param projectName name of the Project in the list
	 */
	public void loadProject(String projectName) {
		for (int i = 0; i < projects.size(); i++) {
			if (projects.get(i).getProjectName().equals(projectName)) {
				this.currentProject = projects.get(i);
//				UserStory.setCounter(currentProject.getUserStories().get(i).getId());
//				UserStory.incrementCounter();
			}
		}
	}
	
	/**
	 * Return the project name for the currentProject. If currentProject is null, then null is returned
	 * @return name of the currentProject or null if currentProject is null.
	 */
	public String getProjectName() {
		if (currentProject == null) {
			return null;
		}
		String name = currentProject.getProjectName();
		return name;
		
	}
	
	/**
	 * Returns a String array of project names in the order they are listed in the projects list. Used by the GUI to populate the project
	 * drop down
	 * @return list of projects
	 */
	public String[] getProjectList() {
		String[] list = new String[projects.size()];
		for (int i = 0; i < projects.size(); i++) {
			list[i] = projects.get(i).getProjectName();
		}
		return list;
		
	}
	
	/**
	 * Resets the ProjectManager and sets the singleton to null
	 */
	protected void resetProjectManager() {
		if (singleton != null) {
			singleton = null;
		}
	}
	
}
