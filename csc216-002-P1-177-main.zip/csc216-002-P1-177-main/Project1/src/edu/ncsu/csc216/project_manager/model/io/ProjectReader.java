package edu.ncsu.csc216.project_manager.model.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.project_manager.model.manager.Project;
import edu.ncsu.csc216.project_manager.model.user_story.UserStory;

/**
 * This class is meant to read in a file name containing one or multiple projects with one or more user stories and process them to break them into individual projects
 * with individual UserStorys.
 * @author Jakob Woodard
 *
 */
public class ProjectReader {
	
	/**
	 * Main method for reading a project file. If the file cannot be read, an IAE is thrown. 
	 * @param fileName of the file being read
	 * @return projects the ArrayList of projects from the file
	 * @throws IllegalArgumentException if the file cannot be read
	 */
	public static List<Project> readProjectFile(String fileName) throws IllegalArgumentException {
		String file = "";
		String project = "";
		try {
			Scanner fileReader = new Scanner(new FileInputStream(fileName)); //Create a file scanner to read the file
			List<Project> projects = new ArrayList<Project>();
		    while (fileReader.hasNextLine()) {
		    	file += fileReader.nextLine() + "\n";    	
		    }
		    Scanner in = new Scanner(file);
		    in.useDelimiter("\\r?\\n?[#]");
		    //Adding first element into the list, with an exception being thrown if there are no valid projects to add
		    try {
		    	project = in.next();
		    	projects.add(processProject(project));
		    }
		    catch (NullPointerException e) {
		    	in.close();
		    	throw new IllegalArgumentException("No valid project found");
		    }
		    while (in.hasNext()) {
		    	project = in.next();
			    projects.add(processProject(project));   
		    }
		    in.close();
		    return projects;
		}
		catch (FileNotFoundException e) {
			throw new IllegalArgumentException("Unable to save file.");
		}
	    
	}
	
	/**
	 * Processes a project in the file, separating it from other projects that can be in the file
	 * @param project project being processed
	 * @return projects the processed projects
	 */
	private static Project processProject(String project) {
		Scanner in = new Scanner(project);
		in.useDelimiter("\\r?\\n?[*]");
		String title = in.next();
		title = title.trim();
		if (title.contains(",")) {
			in.close();
			throw new IllegalArgumentException("Invalid name");
		}
		Project projects = new Project(title);
		//Adding first UserStory
		projects.addUserStory(processUserStory(in.next()));
		//If there are multiple UserStories
		while (in.hasNext()) {
			projects.addUserStory(processUserStory(in.next()));
		}
		in.close();
		return projects;
	}
	
	/**
	 * Processes the UserStorys in a file, breaking down the components of the story
	 * @param story the story being processed
	 * @return processedStory the story after being processed
	 */
	private static UserStory processUserStory(String story) {
		Scanner in = new Scanner(story);
		int id = 0;
		String state = "";
		String title = "";
		String priority = "";
		String developerId = "";
		String rejectionReason = "";
		String user = "";
		String action = "";
		String value = "";
		in.useDelimiter("\\r?\\n?[-]");
		while (in.hasNext()) {
			try {
				String line = in.next();
				Scanner input = new Scanner(line);
				if (line.contains(",")) {
					input.useDelimiter(",");
					try {
						String stringId = input.next();
						stringId = stringId.trim();
						id = Integer.parseInt(stringId);
					}
					catch (NumberFormatException e) {
						input.close();
						throw new IllegalArgumentException("Invalid id");
					}
					state = input.next();
					title = input.next();
					if (state.equals(UserStory.BACKLOG_NAME) || state.equals(UserStory.COMPLETED_NAME) || state.equals(UserStory.WORKING_NAME)
							|| state.equals(UserStory.VERIFYING_NAME)) {
						priority = input.next();
					}
					if (state.equals(UserStory.WORKING_NAME) || state.equals(UserStory.VERIFYING_NAME) || state.equals(UserStory.COMPLETED_NAME)) {
						developerId = input.next();
					}
					if (state.equals(UserStory.REJECTED_NAME)) {
						rejectionReason = input.next();
					}
				}
				user = in.next();
				user = user.trim();
				if (user == null || "".equals(user)) {
					input.close();
					throw new IllegalArgumentException("User is empty");
				}
				action = in.next();
				action = action.trim();
				if (action == null || "".equals(action)) {
					input.close();
					throw new IllegalArgumentException("Action is empty");
				}
				value = in.next();
				value = value.trim();
				if (value == null || "".equals(value)) {
					input.close();
					throw new IllegalArgumentException("Value is empty");
				}
				if (in.hasNext()) {
					input.close();
					throw new IllegalArgumentException("Invalid user/action/value information");
				}
				break;
				
			}	
			catch (NoSuchElementException e) {
				in.close();
				throw new IllegalArgumentException("Missing information");
			}			
		}
		in.close();
		try {
			UserStory processedStory = new UserStory(id, state, title, user, action, value, priority, developerId, rejectionReason);
			return processedStory;
		}
		catch (IllegalArgumentException e) {
			throw new IllegalArgumentException(e.getMessage());
		}	
	}
}
