/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.EmptyStackException;

/**
 * The stack class has 5 methods that can use the generic type to later help organize students that are on a wait list for a 
 * given class with full capacity.
 * @author Jakob Woodard
 * @param <E> denotes that the stack can use a generic type
 *
 */
public interface Stack<E> {
	
	/**
	 * Adds the element to the top of the stack
	 * If there is no room, an IAE is thrown
	 * @param element element to be added to the stack
	 * @throws IllegalArgumentException if there is no room in the stack
	 */
	void push(E element) throws IllegalArgumentException;
	
	/**
	 * Removes and returns the element at the top of the stack
	 * If the stack is empty, an EmptyStackException() is thrown
	 * @return element at the top of the stack
	 * @throws EmpyStackException if the stack is empty
	 */
	E pop() throws EmptyStackException;
	
	/**
	 * Check to see if a stack is empty
	 * @return true if the stack is empty
	 */
	boolean isEmpty();
	
	/**
	 * Check to get the number of elements in the stack
	 * @return the number of elements in the stack
	 */
	int size();
	
	/**
	 * Sets the stack's capacity
	 * @param capacity the stack's wanted capacity
	 * @throws IllegalArgumentException if the parameter is negative or less than the number of elements already in the stack
	 */
	void setCapacity(int capacity) throws IllegalArgumentException;
}
