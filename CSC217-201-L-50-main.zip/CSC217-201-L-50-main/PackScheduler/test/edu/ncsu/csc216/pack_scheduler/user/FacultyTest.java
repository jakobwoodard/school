/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.user;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for the Faculty class
 * @author Jakob Woodard
 *
 */
public class FacultyTest {
	
	/** Student first name */
	private static final String FIRST = "first";
	/** Student last name */
	private static final String LAST = "last";
	/** Student id */
	private static final String ID = "flast";
	/** Student email */
	private static final String EMAIL = "flast@ncsu.edu";
	/** Student password */
	private static final String PASSWORD = "password";
	/** Max credits for class */
	private static final int COURSES = 2;

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.user.Faculty#hashCode()}.
	 */
	@Test
	public void testHashCode() {
		
		Faculty s1 = new Faculty(FIRST, LAST, ID, EMAIL, PASSWORD, COURSES);
		Faculty s2 = new Faculty(FIRST, LAST, ID, EMAIL, PASSWORD, COURSES);
		Faculty s3 = new Faculty(FIRST, "Different", ID, EMAIL, PASSWORD, COURSES);
		Faculty s4 = new Faculty(FIRST, LAST, "Different", EMAIL, PASSWORD, COURSES);
		Faculty s5 = new Faculty(FIRST, LAST, ID, "different@ncsu.edu", PASSWORD, COURSES);
		Faculty s6 = new Faculty(FIRST, LAST, ID, EMAIL, "Different", COURSES);
		Faculty s7 = new Faculty(FIRST, LAST, ID, EMAIL, PASSWORD, 3);
		
		// Tests for the same hash code for the same values
		assertEquals(s1.hashCode(), s2.hashCode());
		
		// Test for each of the fields
		assertNotEquals(s1.hashCode(), s3.hashCode());
		assertNotEquals(s1.hashCode(), s4.hashCode());
		assertNotEquals(s1.hashCode(), s5.hashCode());
		assertNotEquals(s1.hashCode(), s6.hashCode());
		assertNotEquals(s1.hashCode(), s7.hashCode());
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.user.Faculty#equals(java.lang.Object)}.
	 */
	@Test
	public void testEqualsObject() {
		Faculty s1 = new Faculty(FIRST, LAST, ID, EMAIL, PASSWORD, COURSES);
		Faculty s2 = new Faculty(FIRST, LAST, ID, EMAIL, PASSWORD, COURSES);
		Faculty s3 = new Faculty(FIRST, "Different", ID, EMAIL, PASSWORD, COURSES);
		Faculty s4 = new Faculty(FIRST, LAST, "Different", EMAIL, PASSWORD, COURSES);
		Faculty s5 = new Faculty(FIRST, LAST, ID, "different@ncsu.edu", PASSWORD, COURSES);
		Faculty s6 = new Faculty(FIRST, LAST, ID, EMAIL, "Different", COURSES);
		Faculty s7 = new Faculty(FIRST, LAST, ID, EMAIL, PASSWORD, 3);
		
		// Test for equality in both directions
		assertTrue(s1.equals(s2));
		assertTrue(s2.equals(s1));
		
		// Test for each of the fields
		assertFalse(s1.equals(s3));
		assertFalse(s1.equals(s4));
		assertFalse(s1.equals(s5));
		assertFalse(s1.equals(s6));
		assertFalse(s1.equals(s7));
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.user.Faculty#Faculty(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int)}.
	 */
	@Test
	public void testFaculty() {
		Faculty s = null;
		try {
			s = new Faculty(FIRST, LAST, ID, EMAIL, PASSWORD, COURSES);
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(COURSES, s.getMaxCourses());		
		}
		catch (IllegalArgumentException e) {
			fail(e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.user.Faculty#setMaxCourses(int)}.
	 */
	@Test
	public void testSetMaxCourses() {
		Faculty s = null;
		try {
			s = new Faculty(FIRST, LAST, ID, EMAIL, PASSWORD, COURSES);
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(COURSES, s.getMaxCourses());		
		}
		catch (IllegalArgumentException e) {
			fail(e.getMessage());
		}
		
		s.setMaxCourses(3);
		assertEquals(3, s.getMaxCourses());
		
		try {
			s.setMaxCourses(4);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid number of courses", e.getMessage());
		}
		
		try {
			s.setMaxCourses(0);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid number of courses", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.user.Faculty#toString()}.
	 */
	@Test
	public void testToString() {
		Faculty s1 = new Faculty(FIRST, LAST, ID, EMAIL, PASSWORD, COURSES);
		String st1 = "first,last,flast,flast@ncsu.edu,password,2";
		assertEquals(st1, s1.toString());
	}

}
