/**
 * 
 */
package edu.ncsu.csc216.project_manager.model.command;

/**
 * Class that hold the enumeration CommandValue as well as the Command class. A command object is created
 * by using a certain command value and, in some cases, command information.
 * @author Jakob Woodard
 *
 */
public class Command {
	/** Additional information used by a command */
	private String commandInformation;
	/** The command value being used to create a command */
	private CommandValue command;
	/** The enumeration for a command value, as it can only have a few select values */
	public enum CommandValue { BACKLOG, ASSIGN, REVIEW, CONFIRM, REOPEN, REJECT, RESUBMIT }
	/**
	 * Constructor class for a command. An IAE is thrown if the CommandValue is null or if, for certain command
	 * values there is, or is not, additional command information.
	 * @param command the CommandValue for the command
	 * @param commandInformation the additional information used by the command
	 * @throws IllegalArgumentException if the CommandValue is null
	 * @throws IllegalArgumentException if the CommandValue is BACKLOG, ASSIGN, or REJECT and there is no commandInformation
	 * @throws IllegalArgumentException if the CommandValue is REVIEW, CONFIRM, REOPEN, or RESUBMIT and there is commandInformation.
	 */
	public Command(CommandValue command, String commandInformation) {
		//Empty command value
		if (command == null) {
			throw new IllegalArgumentException("A Command MUST have a CommandValue");
		}
		//Command Values that need more info
		if (command == Command.CommandValue.BACKLOG || command == Command.CommandValue.ASSIGN || command == Command.CommandValue.REJECT) {
			if (command == Command.CommandValue.BACKLOG && (commandInformation == null 
				|| "".equals(commandInformation))) {
				throw new IllegalArgumentException("This command requires an additional piece of information");
			}
			else if (command == Command.CommandValue.ASSIGN && (commandInformation == null 
				|| "".equals(commandInformation))) {
				throw new IllegalArgumentException("This command requires an additional piece of information");
			}
			else if (command == Command.CommandValue.REJECT && (commandInformation == null 
				|| "".equals(commandInformation))) {
				throw new IllegalArgumentException("This command requires an additional piece of information");
			}
			this.command = command;
			this.commandInformation = commandInformation;
		}
		
			
		//Command Values that don't need more info
		if (command == Command.CommandValue.REVIEW || command == Command.CommandValue.CONFIRM || command == Command.CommandValue.REOPEN || command == Command.CommandValue.RESUBMIT) {
			if (command == Command.CommandValue.REVIEW && commandInformation != null) {
				throw new IllegalArgumentException("This command doesn't requires an additional piece of information");
			}
			else if (command == Command.CommandValue.CONFIRM && commandInformation != null) {
				throw new IllegalArgumentException("This command doesn't requires an additional piece of information");
			}
			else if (command == Command.CommandValue.REOPEN && commandInformation != null) {
				throw new IllegalArgumentException("This command doesn't requires an additional piece of information");
			}
			else if (command == Command.CommandValue.RESUBMIT && commandInformation != null) {
				throw new IllegalArgumentException("This command doesn't requires an additional piece of information");
			}
			this.command = command;
		}
	}
	/** Getter method for the command
	 * @return the command
	 */
	public CommandValue getCommand() {
		return command; 
	}
	/** Getter method for the commandInformation
	 * @return the commandInformation
	 */
	public String getCommandInformation() {
		return commandInformation;
	}
}
