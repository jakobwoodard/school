/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.AbstractList;

/**
 * Custom Abstract List that will be used together with Course objects in order to create a 
 * list of Courses to be used by the Catalog.
 * @author Jakob Woodard
 * @param <E> generic type to be held in the list
 *
 */
public class LinkedAbstractList<E> extends AbstractList<E> {
	/** Size of the list */
	private int size;
	/** Capacity of the list */
	private int capacity;
	/** A ListNode of type E */
	private ListNode front;
	/** A ListNode that holds the back of the list*/
	private ListNode back;
	
	/**
	 * Constructor for a LinkedAbstractList. Sets front to null, size to 0, and capacity to the passed parameter. If the capacity is
	 * less than 0 or greater than the current size, an IAE is thrown
	 * @param capacity capacity of the new LinkedAbstractList
	 * @throws IllegalArgumentExcpetion if capacity is less than 0
	 * @throws IllegalArgumentException if capacity is less than size
	 */
	public LinkedAbstractList(int capacity) {
		if (capacity < 0 || capacity < size()) {
			throw new IllegalArgumentException("Invalid capacity");
		}
		this.front = new ListNode(null);
		this.size = 0;
		this.capacity = capacity;
		
	}
	/**
	 * Sets the capacity equal to the passed value
	 * @param capacity the desired new capacity
	 */
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	/**
	 * Adds the element to the given index. Updates the references as appropriate.
	 * @param index the index to be added at
	 * @param element the element to be added
	 * @throws NullPointerException if the element being added is null
	 * @throws IndexOutOfBoundsException if the index is less than 0 or larger than size
	 * @throws IllegalArgumentException if the element is a duplicate
	 */
	@Override
	public void add(int index, E element) {
		if (element == null) {
			throw new NullPointerException("Element is null");
		}
		else if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		else if (index == 0) {
			front = new ListNode(element, front);
		}
		else if (size() == capacity) {
			throw new IllegalArgumentException("Size cannot equal capacity");
		}
		else if (size() == 0) {
			ListNode current = front;
			back = new ListNode(element, back);
			current.next = back;
			size++;
		}
		else {
			ListNode current = front;
			for (int i = 0; i < index - 1; i++) {
				if (current.data.equals(element)) {
					throw new IllegalArgumentException("Element already exists");
				}
				current = current.next;
			}
			current.next = new ListNode(element, current.next);
		}
		if (size() == 0) {
			this.back = new ListNode(element);
		}
		size++;
		this.back = new ListNode (get(size() - 1));
		
	}
	@Override
	public E set(int index, E element) {
		E value = null;
		if (element == null) {
			throw new NullPointerException("Element is null");
		}
		else if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		if (index == 0) {
			front = new ListNode(element, front);
		}
		else {
			ListNode current = front;
			for (int i = 0; i < index - 1; i++) {
				if (current.data.equals(element)) {
					throw new IllegalArgumentException("Element already exists");
				}
				current = current.next;
			}
			value = current.next.data;
			current.next.data = element;
		}
		return value;
		
	}
	/**
	 * Removes the value at the specified index and returns said value
	 * @param index the index to be removed at
	 * @return the value that was removed
	 */
	@Override
	public E remove(int index) {
		E value = null;
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		if (index == 0) {
			value = front.data;
			front = front.next;
		}
		else {
			ListNode current = front;
			for (int i = 0; i < index - 1; i++) {
				current = current.next;
			}
			value = current.next.data;
			current.next = current.next.next;
		}
		if (size > 1) {
			back = new ListNode(get(size() - 1));
		}
		back = new ListNode(get(0));
		size--;
		return value;
	}

	@Override
	public E get(int index) {
		if (index < 0 || index >= size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		ListNode current = front;
		for (int i = 0; i < index; i++) {
			current = current.next;
		}
		return current.data;
	}

	@Override
	public int size() {
		return size;
	}
	
	/**
	 * Inner class of LinkedAbstractList which is used to organize the AbstractList
	 * @author Jakob Woodard
	 *
	 */
	private class ListNode {
		/** The data in the node */
		private E data;
		/** The next node in the list */
		private ListNode next;
		/**
		 * Constructor for a ListNode with only a data value
		 * @param data the data in the node
		 */
		public ListNode(E data) {
			this.data = data;
		}
		/**
		 * Constructor for a ListNode with a next value
		 * @param data the data in the node
		 * @param next the next node in the list
		 */
		public ListNode(E data, ListNode next) {
			this.data = data;
			this.next = next;
		}
		
	}

}
