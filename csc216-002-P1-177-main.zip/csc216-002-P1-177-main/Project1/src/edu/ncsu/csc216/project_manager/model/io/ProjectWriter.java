package edu.ncsu.csc216.project_manager.model.io;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

import edu.ncsu.csc216.project_manager.model.manager.Project;

/**
 * Class that receives a given file name to write to and saves a Project to that file, in a properly formated way.
 * @author Jakob Woodard
 *
 */
public class ProjectWriter {
	
	/**
	 * Method that takes a project and a file name and saves the given project to a file in a specific format.
	 * @param fileName of the file to save to
	 * @param project to be saved
	 */
	public static void writeProjectToFile(String fileName, Project project) throws IllegalArgumentException {
		try {
			PrintStream fileWriter = new PrintStream(new File(fileName));
			//Adding project name
			String fullProject = "# " + project.getProjectName();
			for (int i = 0; i < project.getUserStories().size(); i++) {
				fullProject += "\n" + project.getUserStories().get(i).toString();
			}
			
			fileWriter.println(fullProject);

			fileWriter.close();
		}
		catch (IOException e) {
			throw new IllegalArgumentException("Unable to save file.");
		}
	}
//	
//	public static void main(String[] args) {
//		ArrayList<Project> projects = new ArrayList<Project>();
//		try {
//			projects.add(ProjectReader.readProjectFile("test-files/project1.txt").get(0));
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
//		for (int i = 0; i < projects.get(0).getUserStories().size() - 1; i++) {
//			System.out.print(projects.get(0).getUserStories().get(i).toString());
//		}
//		
//	}
}
