/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.roll;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.user.Student;

/**
 * Test cases for the CourseRoll class
 * @author Jakob Woodard
 *
 */
public class CourseRollTest {
	/** Generic first name */
	private static final String FIRST = "first";
	/** Generic last name */
	private static final String LAST = "last";
	/** Generic id */
	private static final String ID = "flast";
	/** Generic email */
	private static final String EMAIL = "flast@ncsu.edu";
	/** Generic password */
	private static final String PASSWORD = "pw";
	/** Generic course credits */
	private static final int CREDITS = 15;

	/**
	 * Tests the constructor for the CourseRoll class as well as the enroll(), canEnroll(), and some setEnrollmentCap() inputs
	 */
	@Test
	public void testCourseRoll() {
		try {
			new CourseRoll(10, null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Course is null", e.getMessage());
		}
		//Students for testing
		Student s1 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s2 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s3 = new Student(FIRST, "Different", ID, EMAIL, PASSWORD, CREDITS);
		Student s4 = new Student(FIRST, LAST, "Different", EMAIL, PASSWORD, CREDITS);
		Student s5 = new Student(FIRST, LAST, ID, "different@ncsu.edu", PASSWORD, CREDITS);
		Student s6 = new Student(FIRST, LAST, ID, EMAIL, "Different", CREDITS);
		Student s7 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, 3);
		Student s8 = new Student("Different", LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s9 = new Student("New", "Different", ID, EMAIL, PASSWORD, CREDITS);
		Student s10 = new Student("Different", "Different", ID, EMAIL, PASSWORD, CREDITS);
		Student s11 = new Student("New", LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s12 = new Student (FIRST, FIRST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s13 = new Student (FIRST, FIRST, LAST, EMAIL, PASSWORD, CREDITS);
		Student s14 = new Student (FIRST, LAST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s15 = new Student (LAST, LAST, LAST, EMAIL, PASSWORD, CREDITS);
		Student s16 = new Student (LAST, FIRST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s17 = new Student (LAST, LAST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s18 = new Student (EMAIL, EMAIL, EMAIL, EMAIL, PASSWORD, CREDITS);
		Student s19 = new Student (EMAIL, EMAIL, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s20 = new Student (EMAIL, FIRST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s21 = new Student ("Different", FIRST, FIRST, EMAIL, PASSWORD, CREDITS);
		Course c = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "A");
		
		CourseRoll cs = new CourseRoll(10, c);
		
		assertEquals(10, cs.getEnrollmentCap());
		assertEquals(10, cs.getOpenSeats());
		
		cs.enroll(s1);
		cs.enroll(s2);
		cs.enroll(s3);
		cs.enroll(s4);
		cs.enroll(s5);
		
		assertEquals(5, cs.getOpenSeats());
		
		assertFalse(cs.canEnroll(s4));
		
		assertTrue(cs.canEnroll(s6));
		
		try {
			cs.enroll(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Student is null", e.getMessage());
		}
		try {
			cs.enroll(s4);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Course cannot be added to schedule.", e.getMessage());
		}
		
		//Adding to get to max capacity
		cs.enroll(s6);
		cs.enroll(s7);
		cs.enroll(s8);
		cs.enroll(s9);
		cs.enroll(s10);
		assertEquals(0, cs.getOpenSeats());
		cs.enroll(s11);
		
		assertEquals(1, cs.getNumberOnWaitlist());
		
		cs.enroll(s12);
		cs.enroll(s13);
		cs.enroll(s14);
		cs.enroll(s15);
		cs.enroll(s16);
		cs.enroll(s17);
		cs.enroll(s18);
		cs.enroll(s19);
		cs.enroll(s20);
		
		assertEquals(10, cs.getNumberOnWaitlist());
		
		assertFalse(cs.canEnroll(s21));
		
		try {
			cs.enroll(s21);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Wait list is full", e.getMessage());
		}
		
		
	
	}
	/**
	 * Tests invalid inputs for the setEnrollmentCap() method of CourseRoll
	 */
	@Test
	public void testSetEnrollmentCap() {
		Course c = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "A");
		
		CourseRoll cs = new CourseRoll(10, c);
		
		try {
			cs.setEnrollmentCap(9);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid enrollment cap", e.getMessage());
		}
		try {
			cs.setEnrollmentCap(251);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid enrollment cap", e.getMessage());
		}
	}
	
	/**
	 * Tests the drop() method of the CourseRoll class
	 */
	@Test
	public void testDrop() {
		//Students for testing
		Student s1 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s2 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s3 = new Student(FIRST, "Different", ID, EMAIL, PASSWORD, CREDITS);
		Student s4 = new Student(FIRST, LAST, "Different", EMAIL, PASSWORD, CREDITS);
		Student s5 = new Student(FIRST, LAST, ID, "different@ncsu.edu", PASSWORD, CREDITS);
		Student s6 = new Student(FIRST, LAST, ID, EMAIL, "Different", CREDITS);
		Student s7 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, 3);
		Student s8 = new Student("Different", LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s9 = new Student("New", "Different", ID, EMAIL, PASSWORD, CREDITS);
		Student s10 = new Student("Different", "Different", ID, EMAIL, PASSWORD, CREDITS);
		Student s11 = new Student("New", LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s12 = new Student (FIRST, FIRST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s13 = new Student (FIRST, FIRST, LAST, EMAIL, PASSWORD, CREDITS);
		Student s14 = new Student (FIRST, LAST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s15 = new Student (LAST, LAST, LAST, EMAIL, PASSWORD, CREDITS);
		Student s16 = new Student (LAST, FIRST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s17 = new Student (LAST, LAST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s18 = new Student (EMAIL, EMAIL, EMAIL, EMAIL, PASSWORD, CREDITS);
		Student s19 = new Student (EMAIL, EMAIL, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s20 = new Student (EMAIL, FIRST, FIRST, EMAIL, PASSWORD, CREDITS);
		Student s21 = new Student ("Different", FIRST, FIRST, EMAIL, PASSWORD, CREDITS);
		Course c = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "A");

		
		CourseRoll cs = new CourseRoll(10, c);
		
		assertEquals(10, cs.getEnrollmentCap());
		assertEquals(10, cs.getOpenSeats());
		assertEquals(0, cs.getNumberOnWaitlist());
		
		cs.enroll(s1);
		cs.enroll(s2);
		cs.enroll(s3);
		cs.enroll(s4);
		cs.enroll(s5);
		assertEquals(5, cs.getOpenSeats());
		
		//Dropping student
		cs.drop(s5);
		assertEquals(6, cs.getOpenSeats());
		
		cs.enroll(s5);
		cs.enroll(s6);
		cs.enroll(s7);
		cs.enroll(s8);
		cs.enroll(s9);
		cs.enroll(s10);
		//Students on the wait list
		cs.enroll(s11);
		cs.enroll(s12);
		
		assertEquals(0, cs.getOpenSeats());
		assertEquals(2, cs.getNumberOnWaitlist());
		
		//Removing from roll and moving student from wait list to course roll
		cs.drop(s5);
		assertEquals(0, cs.getOpenSeats());
		assertEquals(1, cs.getNumberOnWaitlist());
		assertEquals(s11.getSchedule().getScheduledCourses()[0][0], c.getName());
		
		//Removing student from wait list
		cs.drop(s12);
		assertEquals(0, cs.getNumberOnWaitlist());
		
		//Adding a few more students for testing
		cs.enroll(s15);
		assertEquals(1, cs.getNumberOnWaitlist());
		cs.enroll(s16);
		cs.enroll(s17);
		cs.enroll(s18);
		cs.enroll(s19);
		cs.enroll(s20);
		assertEquals(6, cs.getNumberOnWaitlist());
		cs.drop(s18);
		assertEquals(5, cs.getNumberOnWaitlist());
		
		//Adding students to get waitlist full
		cs.enroll(s5);
		cs.enroll(s12);
		cs.enroll(s18);
		cs.enroll(s13);
		cs.enroll(s14);
		
		assertEquals(10, cs.getNumberOnWaitlist());
		assertFalse(cs.canEnroll(s21));
		
		
		try {
			cs.drop(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Student is null", e.getMessage());
		}
		
		assertFalse(cs.canEnroll(s15));
		
	}
	

}
