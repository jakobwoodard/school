/**
 * 
 */
package edu.ncsu.csc216.hloj.model.manager;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.hloj.model.Customer;
import edu.ncsu.csc216.hloj.model.ModelException;

/**
 * Test cases for CustomerManager
 * @author Jakob Woodard
 *
 */
public class CustomerManagerTest {
	
	
	/**
	 * Resets the state of the program
	 */
	@Before
	public void resetManagers() {
		OrderManager.getInstance().removeAllOrders();
		MenuManager.getInstance().removeAllMenuItems();
		CustomerManager.getInstance().removeAllCustomers();
	}
	
	/**
	 * Test method for CustomerManager()
	 */
	@Test
	public void testCustomerManager() {
		CustomerManager cm = CustomerManager.getInstance();
		assertEquals(0, cm.getCustomers().length);
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.manager.CustomerManager#addCustomer(edu.ncsu.csc216.hloj.model.Customer)}.
	 */
	@Test
	public void testAddCustomer() {
		CustomerManager cm = CustomerManager.getInstance();
		assertEquals(0, cm.getCustomers().length);
		
		try {
			Customer c = new Customer("First", "Last", "flast");
			
			
			cm.addCustomer(c);
			assertEquals(1, cm.getCustomers().length);
			assertEquals(c, cm.getCustomer(0));
			assertEquals(c, cm.getCustomer("flast"));
			assertNull(cm.getCustomer("none"));
			
			try {
				cm.addCustomer(c);
				fail();
			}
			catch (ModelException e) {
				assertEquals("A customer with this id already exists", e.getMessage());
			}
		} catch (ModelException e) {
			fail("Unexpected ModelException");
		}
		
		cm.removeAllCustomers();
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.manager.CustomerManager#removeCustomer(edu.ncsu.csc216.hloj.model.Customer)}.
	 */
	@Test
	public void testRemoveCustomer() {
		CustomerManager cm = CustomerManager.getInstance();
		assertEquals(0, cm.getCustomers().length);
		
		try {
			Customer c = new Customer("First", "Last", "flast");
			
			
			cm.addCustomer(c);
			assertEquals(1, cm.getCustomers().length);
			assertEquals(c, cm.getCustomer(0));
			cm.removeCustomer(c);
			assertEquals(0, cm.getCustomers().length);
		} catch (ModelException e) {
			fail("Unexpected ModelException");
		}
		
		cm.removeAllCustomers();
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.manager.CustomerManager#editCustomer(int, edu.ncsu.csc216.hloj.model.Customer)}.
	 */
	@Test
	public void testEditCustomer() {
		CustomerManager cm = CustomerManager.getInstance();
		assertEquals(0, cm.getCustomers().length);
		
		try {
			Customer c = new Customer("First", "Last", "flast");
			Customer c2 = new Customer("First", "Last", "different");
			Customer c3 = new Customer("different", "different", "flast");
			
			cm.addCustomer(c);
			assertEquals(1, cm.getCustomers().length);
			assertEquals(c, cm.getCustomer(0));

			cm.editCustomer(0, c2);
			assertEquals("different", cm.getCustomer(0).getId());
			cm.addCustomer(c);
			assertEquals(2, cm.getCustomers().length);
			assertEquals(c, cm.getCustomer(0));
			assertEquals(c2, cm.getCustomer(1));
			
			try {
				cm.editCustomer(1, c3);
				fail();
			}
			catch (ModelException e) {
				assertEquals("First", cm.getCustomer(0).getFirstName());
			}
			try {
				cm.addCustomer(c2);
				fail();
			}
			catch (ModelException e) {
				assertEquals("A customer with this id already exists", e.getMessage());
			}
			
		} catch (ModelException e) {
			fail(e.getMessage());
		}
		
		
		cm.removeAllCustomers();
	}


}
