/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.EmptyStackException;

/**
 * An array used through the implementation of the Stack interface.
 * @author Jakob Woodard
 * @param <E> the general type that can be held in an array.
 *
 */
public class ArrayStack<E> implements Stack<E> {
	
	/** Field type for ArrayStack */
	private ArrayList<E> list;
	/** Capacity of the ArrayStack */
	private int capacity;

	/**
	 * Constructor for a stack, initiates the size at 0 and creates an empty array list and the capacity to that of an 
	 * array list (10).
	 * @param capacity the capacity of the ArrayStack
	 */
	public ArrayStack(int capacity) {
		list = new ArrayList<E>();
		setCapacity(capacity);
	}
	
	@Override
	public void push(E element) throws IllegalArgumentException {
		if (size() == capacity) {
			throw new IllegalArgumentException("Stack is full");
		}
		else {
			list.add(element);
		}
		
	}

	@Override
	public E pop() throws EmptyStackException {
		if (list.isEmpty()) {
			throw new EmptyStackException();
		}
		else {
			E value = list.get(size() - 1);
			list.remove(size() - 1);
			return value;
		}
	}

	@Override
	public boolean isEmpty() {
		return list.isEmpty();
	}

	@Override
	public int size() {
		return list.size();
	}

	@Override
	public void setCapacity(int capacity) throws IllegalArgumentException {
		if (capacity < 0 || capacity < size()) {
			throw new IllegalArgumentException("Invalid capacity");
		}
		this.capacity = capacity;
		
	}

}
