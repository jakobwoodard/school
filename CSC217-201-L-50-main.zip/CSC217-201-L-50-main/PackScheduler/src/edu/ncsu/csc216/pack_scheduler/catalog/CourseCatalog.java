/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.catalog;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.io.CourseRecordIO;

import java.io.IOException;

import edu.ncsu.csc217.collections.list.SortedList;

/**
 * This is a class that is similar to that of the WolfScheduler class in which it can process courses and get them from a file made 
 * up of courses with a given format.
 * @author Jakob Woodard
 *
 */
public class CourseCatalog {
	
	/** A SortedList that will be used by the class when needing to add/remove instances of classes */
	private SortedList<Course> catalog;
	
	/** Constructor method for the CourseCatalog */
	public CourseCatalog() {
		this.catalog = new SortedList<Course>();
	}
	
	/** Constructor for a new CourseCatalog which is a new, empty catalog */
	public void newCourseCatalog() {
		this.catalog = new SortedList<Course>();
	}
	
	/**
	 * Method to load Courses from a file to then be made into a catalog
	 * @param fileName the name of the file being loaded from
	 */
	public void loadCoursesFromFile(String fileName) {
		try {
			this.catalog = CourseRecordIO.readCourseRecords(fileName);
		}
		catch(Exception e) {
			throw new IllegalArgumentException("Cannot find file");
		}
	}
	/**
	 * Method that adds a course to the catalog. If the course already exists, then the course is not added to the catalog
	 * @param name name of the course
	 * @param title title of the course
	 * @param section course section
	 * @param credits course's credits
	 * @param instructorId course's instructorId
	 * @param enrollmentCap the capacity for the class
	 * @param meetingDays meetingDays of the course
	 * @param startTime start time of the course
	 * @param endTime end time of the course
	 * @return true if the course is added, false if not
	 */
	public boolean addCourseToCatalog(String name, String title, String section, int credits, String instructorId, int enrollmentCap, String meetingDays, int startTime, int endTime) {
		try {
		Course newCourse = new Course(name, title, section, credits, instructorId, enrollmentCap, meetingDays, startTime, endTime);
			for (int i = 0; i < catalog.size(); i++) {
				if (catalog.get(i).isDuplicate(newCourse)) {
					return false;
				}
			}
			catalog.add(newCourse);
			return true;
		}
		catch (Exception e) {
			throw new IllegalArgumentException(e.getMessage());
		}
		
		
	}
	/**
	 * Method that checks the catalog to see if a desired course is in it. If it is, the course is removed and true is returned
	 * @param name name of the course
	 * @param section section of the course
	 * @return true if the course is in the catalog and is removed, false if not
	 */
	public boolean removeCourseFromCatalog(String name, String section) {
		for (int i = 0; i < catalog.size(); i++) {
			if (catalog.get(i).getName().equals(name) && catalog.get(i).getSection().equals(section)) {
				catalog.remove(i);
				return true;
			}
		}
		return false;
	}
	/**
	 * Method for finding a course in the catalog and returning it. If the course isn't in the catalog, null is returned
	 * @param name name of the course
	 * @param section section of the course
	 * @return the desired course if it is in the catalog, null if not
	 */
	public Course getCourseFromCatalog(String name, String section) {
		for (int i = 0; i < catalog.size(); i++) {
			if (catalog.get(i).getName().equals(name) && catalog.get(i).getSection().equals(section)) {
				Course desired = catalog.get(i);
				return desired;
			}
		}
		return null;
	}
	/**
	 * Getter method for the course catalog. This method will return, for each course in the catalog, the course's name, section, title, and meeting information.
	 * @return 2D string array of each courses information
	 */
	public String[][] getCourseCatalog() {
		String[][] courseCatalog = new String[catalog.size()][5];
		for (int i = 0; i < catalog.size(); i++) {
			courseCatalog[i][0] = catalog.get(i).getShortDisplayArray()[0];
			courseCatalog[i][1] = catalog.get(i).getShortDisplayArray()[1];
			courseCatalog[i][2] = catalog.get(i).getShortDisplayArray()[2];
			courseCatalog[i][3] = catalog.get(i).getShortDisplayArray()[3];
			courseCatalog[i][4] = catalog.get(i).getShortDisplayArray()[4];
		}
		return courseCatalog;
	}
	/**
	 * Method to save the course catalog to the file of the user's choosing
	 * @param fileName the name of the file that the user wants the course to be saved to
	 */
	public void saveCourseCatalog(String fileName) {
		try {
			CourseRecordIO.writeCourseRecords(fileName, catalog);
		}
		catch (IOException e) {
			throw new IllegalArgumentException("The file cannot be saved.");
		}
	}
}
