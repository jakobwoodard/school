/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for LinkedAbstractList class
 * @author Jakob Woodard
 *
 */
public class LinkedAbstractListTest {

	/**
	 * Test method for the Constructor. The created list should have size 0 and capacity 10.
	 */
	@Test
	public void testLinkedAbstractList() {
		LinkedAbstractList<String> list = new LinkedAbstractList<String>(10);
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		//Invalid get to avoid writing new test
		try {
			list.get(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.get(100);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			new LinkedAbstractList<String>(-1);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid capacity", e.getMessage());
		}
			
	}
	/**
	 * Tests the add method for ArrayList
	 */
	@Test
	public void testAdd() {
		LinkedAbstractList<String> list = new LinkedAbstractList<String>(10);
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		//Invalid adds
		try {
			list.add(4, null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals("Element is null", e.getMessage());
		}
		try {
			list.add(-1, "New");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.add(100, "New");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.add(4, "Zero");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Element already exists", e.getMessage());
		}
		try {
			list.add(9, "Nine");
			list.add(10, "Ten");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Size cannot equal capacity", e.getMessage());
		}
		
		//Adding more capacity then adding an element
		list.setCapacity(11);
		list.add(10, "Ten");
		assertEquals("Ten", list.get(10));
		
	}
	
	/**
	 * Tests the remove method for ArrayList
	 */
	@Test
	public void testRemove() {
		LinkedAbstractList<String> list = new LinkedAbstractList<String>(10);
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		
		list.remove(5);
		
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Six", list.get(5));
		assertEquals("Seven", list.get(6));
		assertEquals("Eight", list.get(7));
		assertEquals("Nine", list.get(8));
		
		list.remove(0);
		assertEquals("One", list.get(0));
		assertEquals("Two", list.get(1));
		assertEquals("Three", list.get(2));
		assertEquals("Four", list.get(3));
		assertEquals("Six", list.get(4));
		assertEquals("Seven", list.get(5));
		assertEquals("Eight", list.get(6));
		assertEquals("Nine", list.get(7));
		
		//Invalid removes
		try {
			list.remove(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.remove(100);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		

	}
	
	/**
	 * Tests the set method for ArrayList
	 */
	@Test
	public void testSet() {
		LinkedAbstractList<String> list = new LinkedAbstractList<String>(10);
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		list.set(0, "New");
		assertEquals("New", list.get(0));
		
		list.set(5, "Not Five");
		assertEquals("Not Five", list.get(5));
		
		//Invalid sets
		try {
			list.set(4, null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals("Element is null", e.getMessage());
		}
		try {
			list.set(-1, "New");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.set(100, "New");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Invalid index", e.getMessage());
		}
		try {
			list.set(4, "One");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Element already exists", e.getMessage());
		}
	}

}
