/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import java.util.EmptyStackException;

import org.junit.Test;

/**
 * Test cases for LinkedStack class
 * @author Jakob Woodard
 *
 */
public class LinkedStackTest {

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.util.LinkedStack#push(java.lang.Object)}.
	 */
	@Test
	public void testPush() {
		LinkedStack<String> ar = new LinkedStack<String>(0);
		
		
		
		try {
			ar.push("1");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Stack is full", e.getMessage());
		}
		
		ar.setCapacity(10);

		
		assertTrue(ar.isEmpty());
		
		ar.push("Zero");
		
		
		assertFalse(ar.isEmpty());
		
		ar.push("One");
		ar.push("Two");
		ar.push("Three");
		assertEquals("Three", ar.pop());
		assertEquals("Two", ar.pop());
		assertEquals("One", ar.pop());
		assertEquals("Zero", ar.pop());
		
		try {
			ar.pop();
			fail();
		}
		catch (EmptyStackException e) {
			assertEquals(e.getMessage(), e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.util.LinkedStack#setCapacity(int)}.
	 */
	@Test
	public void testSetCapacity() {
		LinkedStack<String> ar = new LinkedStack<String>(0);
		ar.setCapacity(10);
		
		
		try {
			ar.setCapacity(-1);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid capacity", e.getMessage());
		}
		
		ar.push("One");
		ar.push("Two");
		ar.push("Three");
		
		try {
			ar.setCapacity(1);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid capacity", e.getMessage());
		}
	}

}
