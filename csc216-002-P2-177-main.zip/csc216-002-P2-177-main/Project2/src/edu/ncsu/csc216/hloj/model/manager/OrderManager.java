/**
 * 
 */
package edu.ncsu.csc216.hloj.model.manager;

import edu.ncsu.csc216.hloj.model.Customer;
import edu.ncsu.csc216.hloj.model.ModelException;
import edu.ncsu.csc216.hloj.model.Order;
import edu.ncsu.csc216.hloj.model.lists.SortedList;

/**
 * This singleton class maintains a sorted list of Orders
 * @author Jakob Woodard
 *
 */
public class OrderManager {
	
	/** The last order number of a placed order */
	private int lastOrderNumber;
	/** Max number of open orders allowed per customer */
	private static final int MAX_ORDERS_PER_CUSTOMER = 3;
	/** Singleton instance of OrderManager */
	private static OrderManager instance;
	/** List of all orders organized by customer */
	private SortedList<Order> orders;
	
	
	private OrderManager() {
		this.orders = new SortedList<Order>();
		setLastOrderNumber(0);
	}
	
	/**
	 * Singleton method for checking that there is only one instance of OrderManager. If the return is null, a new OrderManager
	 * can be created using the private OrderManager() method.
	 * @return instance the singleton instance of OrderManager
	 */
	public static OrderManager getInstance() {
		if (instance == null) {
			OrderManager.instance = new OrderManager();
		}
		return instance;
	}
	
	/**
	 * Returns the last order number
	 * @return lastOrderNumber the order number of the last placed order
	 */
	public int getLastOrderNumber() {
		return lastOrderNumber;
		
	}
	
	/**
	 * Sets the last order number to the specified number
	 * @param number to set the last order number to
	 */
	public void setLastOrderNumber(int number) {
		this.lastOrderNumber = number;
	}
	
	/**
	 * Returns a new order for the provided customer with the next order number. 
	 * If the customer has 3 open orders already, throws a ModelException.
	 * @param c Customer to add the order to
	 * @return order the new Order for the specified customer
	 * @throws ModelException if the specified customer already has 3 open orders
	 */
	public Order getNextOrder(Customer c) throws ModelException {
		Order order = null;
		if (getOrdersByCustomer(c).length >= MAX_ORDERS_PER_CUSTOMER) {
			throw new ModelException("A customer cannot have more than 3 open orders");
			
		}
		for (int i = 0; i < orders.size(); i++) {
			if (orders.get(i).getCustomer().equals(c)) {
				order = orders.get(i);
				setLastOrderNumber(order.getNumber());
				return order;
			}
		}
		order = new Order(lastOrderNumber + 1, c);
		setLastOrderNumber(order.getNumber());
		return order;
	}
	
	/**
	 * Creates a new order
	 * @param o Order to be created
	 * @throws ModelException if the desired order has a duplicate order number or if the order does not contain an item
	 */
	public void placeOrder(Order o) throws ModelException {
		if (o.getItems().length == 0) {
			throw new ModelException("Orders can only be placed if they contain at least one item");
		}
		for (int i = 0; i < orders.size(); i++) {
			if (orders.get(i).getNumber() == o.getNumber()) {
				throw new ModelException("An order with this number already exists");
			}
		}
		orders.add(o);
	}
	
	/**
	 * Gets the 2D array of all orders
	 * @return allOrders orders of all of the Customers
	 */
	public Order[] getOrders() {
		Order[] allOrders = new Order[orders.size()];
		for (int i = 0; i < orders.size(); i++) {
			allOrders[i] = orders.get(i);
		}
		return allOrders;
		
	}
	
	/**
	 * Gets the list of Orders for a specific Customer
	 * @param c Customer whose orders will be given in a list
	 * @return the list of Orders for the specified Customer
	 */
	public Order[] getOrdersByCustomer(Customer c) {
		int orderCount = 0;
		for (int i = 0; i < orders.size(); i++) {
			if (orders.get(i).getCustomer().equals(c)) {
				orderCount++;
			}
		}
		Order customerOrders[] = new Order[orderCount];
		for (int i = 0; i < orders.size(); i++) {
			int j = 0;
			if (orders.get(i).getCustomer().equals(c)) {
				customerOrders[j] = orders.get(i);
				j++;
			}
		}
		return customerOrders;
		
	}
	
	/**
	 * Gets the Order stored at the specified index in the list
	 * @param index of the desired Order
	 * @return the Order at the given index
	 */
	public Order getOrder(int index) {
		if (orders.get(index) != null) {
			return orders.get(index);
		}
		return null;
		
		
	}
	
	/**
	 * Cancels the desired order meaning that the order is no longer open
	 * @param o Order to be canceled
	 * @throws ModelException if the order does not exist
	 */
	public void cancelOrder(Order o) throws ModelException {
		boolean exists = false;
		for (int i = 0; i < orders.size(); i++) {
			if (orders.get(i).equals(o)) {
				orders.remove(i);
				exists = true;
			}
		}
		if (!exists) {
			throw new ModelException("Order does not exist");
		}
		
	}
	
	/**
	 * Sets the value of the specified order to "fulfilled" meaning that the order is no longer open and has been completed
	 * @param o Order to fulfill
	 * @throws ModelException if the Order is not fulfilled in the order in which it was placed
	 */
	public void fulfillOrder(Order o) throws ModelException {
		for (int i = 0; i < orders.size(); i++) {
			if (orders.get(i).getNumber() < o.getNumber()) {
				throw new ModelException("Orders must be fulfilled in the order in which they were placed");
			}
		}
		orders.remove(o);
	}
	
	/**
	 * Removes all orders from the system and resets the last order number
	 */
	public void removeAllOrders() {
		orders = new SortedList<Order>();
	}

}
