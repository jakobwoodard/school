package edu.ncsu.csc216.project_manager.model.user_story;

import edu.ncsu.csc216.project_manager.model.command.Command;

/**
 * Class for the context of a UserStory which will be used by the project manager in order
 * to create and edit user stories.
 * @author Jakob Woodard
 *
 */
public class UserStory {
	/** Name of a submitted story */
	public static final String SUBMITTED_NAME = "Submitted";
	/** Name of a story in the backlog */
	public static final String BACKLOG_NAME = "Backlog";
	/** Name of a working story */
	public static final String WORKING_NAME = "Working";
	/** Name of a story in the verifying state */
	public static final String VERIFYING_NAME = "Verifying";
	/** Name of a story in the completed state */
	public static final String COMPLETED_NAME = "Completed";
	/** Name of a story in the rejected state */
	public static final String REJECTED_NAME = "Rejected";
	/** String for a high-priority story */
	public static final String HIGH_PRIORITY = "High";
	/** String for a medium-priority story */
	public static final String MEDIUM_PRIORITY = "Medium";
	/** String for a low-priority story */
	public static final String LOW_PRIORITY = "Low";
	/** String for a duplicate rejection reasoning */
	public static final String DUPLICATE_REJECTION = "Duplicate";
	/** String for an inappropriate rejection reasoning */
	public static final String INAPPROPRIATE_REJECTION = "Inappropriate";
	/** String for an infeasible rejection reasoning */
	public static final String INFEASIBLE_REJECTION = "Infeasible";
	/** ID of a story */
	private int storyId;
	/** Title of a story */
	private String title;
	/** User information for a story statement */
	private String user;
	/** Action information for a story statement */
	private String action;
	/** Value information for a story statement */
	private String value;
	/** Priority of a user story */
	private String priority;
	/** A story's assigned developer */
	private String developerId;
	/** Rejection reason of the story */
	private String rejectionReason;
	/** State of a story */
	private String state;
	/** Counter for user story IDs */
	private static int counter = 0;
	/** Final instance of the SubmittedState inner class */
	private final SubmittedState submittedState = new SubmittedState();
	/** Final instance of the BacklogState inner class */
	private final BacklogState backlogState = new BacklogState();
	/** Final instance of the WorkingState inner class */
	private final WorkingState workingState = new WorkingState();
	/** Final instance of the VerifyingState inner class */
	private final VerifyingState verifyingState = new VerifyingState();
	/** Final instance of the CompletedState inner class */
	private final CompletedState completedState = new CompletedState();
	/** Final instance of the RejectedState inner class */
	private final RejectedState rejectedState = new RejectedState();
	
	/**
	 * Constructor method for a UserStory using a title, user, action, and value
	 * @param title title of the story
	 * @param user user of the story
	 * @param action action being done to the story
	 * @param value value statement for the story
	 * @throws IllegalArgumentException if any params are empty or null
	 */
	public UserStory(String title, String user, String action, String value) {
		if (title == null || "".equals(title)) {
			throw new IllegalArgumentException("Invalid title");
		}
		if (user == null || "".equals(user)) {
			throw new IllegalArgumentException("Invalid user");
		}
		if (action == null || "".equals(action)) {
			throw new IllegalArgumentException("Invalid action");
		}
		if (value == null || "".equals(value)) {
			throw new IllegalArgumentException("Invalid value");
		}
		setId(UserStory.counter);
		incrementCounter();
		setState(SUBMITTED_NAME);
		setPriority(null);
		setDeveloperId(null);
		setRejectionReason(null);
		setTitle(title);
		setUser(user);
		setAction(action);
		setValue(value);
		
	}
	/**
	 * Second constructor method for UserStory. Used by the ProjectReader class. If any of the parameters
	 * are invalid, an IAE is thrown
	 * @param id id of the story
	 * @param state state of the story
	 * @param title title of the story
	 * @param user user of the story
	 * @param action action to be done in the story statement
	 * @param value value of the story statement
	 * @param priority priority of the story
	 * @param developerId developer id of the story
	 * @param rejectionReason rejection reason of the story
	 * @throws IllegalArgumentException if for each state, there is, or is not, certain params.
	 */
	public UserStory(int id, String state, String title, String user, String action, String value, String priority,
			String developerId, String rejectionReason) {
		if (id < 0) {
			throw new IllegalArgumentException("Invalid id");
		}
		if (id > counter) {
			UserStory.setCounter(id + 1);
		}
		//Submitted state, no priority, developer, rejection
		if (SUBMITTED_NAME.equals(state)) {
			if (priority != null && !"".equals(priority)) {
				throw new IllegalArgumentException("Invalid priority");
			}
			else if (developerId != null && !"".equals(developerId)) {
				throw new IllegalArgumentException("Invalid developer id");
			}
			else if (rejectionReason != null && !"".equals(rejectionReason)) {
				throw new IllegalArgumentException("Invalid rejection reason");
			}
			else if (title == null || "".equals(title)) {
				throw new IllegalArgumentException("Invalid title");
			}
			else if (user == null || "".equals(user)) {
				throw new IllegalArgumentException("Invalid user");
			}
			else if (action == null || "".equals(action)) {
				throw new IllegalArgumentException("Invalid action");
			}
			else if (value == null || "".equals(value)) {
				throw new IllegalArgumentException("Invalid value");
			}
			
			//Set all valid values = to params
			else {
				setState(state);
				setId(id);
				setTitle(title);
				setUser(user);
				setAction(action);
				setValue(value);
			}
		}
		//Backlog state no developer or rejection; needs priority
		else if (BACKLOG_NAME.equals(state)) {
			if (priority == null || "".equals(priority)) {
				throw new IllegalArgumentException("Invalid priority");
			}
			else if (developerId != null && !"".equals(developerId)) {
				throw new IllegalArgumentException("Invalid developer id");
			}
			else if (rejectionReason != null && !"".equals(rejectionReason)) {
				throw new IllegalArgumentException("Invalid rejection reason");
			}
			
			//Set all valid values = to params
			else {
				setState(state);
				setId(id);
				setTitle(title);
				setUser(user);
				setAction(action);
				setValue(value);
				setPriority(priority);
			}
			
		}
		//Working state no rejection; needs priority and developer
		else if (WORKING_NAME.equals(state)) {
			if (priority == null || "".equals(priority)) {
				throw new IllegalArgumentException("Invalid priority");
			}
			else if (developerId == null || "".equals(developerId)) {
				throw new IllegalArgumentException("Invalid developer id");
			}
			else if (rejectionReason != null && !"".equals(rejectionReason)) {
				throw new IllegalArgumentException("Invalid rejection reason");
			}
			
			//Set all valid values = to params
			else {
				setState(state);
				setId(id);
				setTitle(title);
				setUser(user);
				setAction(action);
				setValue(value);
				setPriority(priority);
				setDeveloperId(developerId);
			}

		}
		//Verifying state no rejection; needs priority and developer
		else if (VERIFYING_NAME.equals(state)) {
			if (priority == null || "".equals(priority)) {
				throw new IllegalArgumentException("Invalid priority");
			}
			else if (developerId == null || "".equals(developerId)) {
				throw new IllegalArgumentException("Invalid developer id");
			}
			else if (rejectionReason != null && !"".equals(rejectionReason)) {
				throw new IllegalArgumentException("Invalid rejection reason");
			}
			
			//Set all valid values = to params
			else {
				setState(state);
				setId(id);
				setTitle(title);
				setUser(user);
				setAction(action);
				setValue(value);
				setPriority(priority);
				setDeveloperId(developerId);
			}
			
		}
		//Completed state no rejection; needs priority and developer
		else if (COMPLETED_NAME.equals(state)) {
			if (priority == null || "".equals(priority)) {
				throw new IllegalArgumentException("Invalid priority");
			}
			else if (developerId == null || "".equals(developerId)) {
				throw new IllegalArgumentException("Invalid developer id");
			}
			else if (rejectionReason != null && !"".equals(rejectionReason)) {
				throw new IllegalArgumentException("Invalid rejection reason");
			}
			
			//Set all valid values = to params
			else {
				setState(state);
				setId(id);
				setTitle(title);
				setUser(user);
				setAction(action);
				setValue(value);
				setPriority(priority);
				setDeveloperId(developerId);
			}
			
		}
		//Rejected state no priority or developer; needs rejection
		else if (REJECTED_NAME.equals(state)) {
			if (priority != null && !"".equals(priority)) {
				throw new IllegalArgumentException("Invalid priority");
			}
			else if (developerId != null && !"".equals(developerId)) {
				throw new IllegalArgumentException("Invalid developer id");
			}
			else if (rejectionReason == null || "".equals(rejectionReason)) {
				throw new IllegalArgumentException("Invalid rejection reason");
			}
			
			//Set all valid values = to params
			else {
				setState(state);
				setId(id);
				setTitle(title);
				setUser(user);
				setAction(action);
				setValue(value);
				setRejectionReason(rejectionReason);
			}

		}
		else {
			throw new IllegalArgumentException("Invalid state");
		}
	}

	/**
	 * Getter method for the story id
	 * @return the storyId
	 */
	public int getId() {
		return storyId;
	}

	/**
	 * Setter method for the story id
	 * @param storyId the storyId to set
	 */
	private void setId(int storyId) {
		this.storyId = storyId;
	}

	/**
	 * Getter method for the story title
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Setter method for the story title
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Getter method for the user
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * Setter story for the user
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Getter method for the state
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	

	/**
	 * Setter method for the state
	 * @param state the state to set
	 * @throws IllegalArgumentException if the given state string is not a valid state
	 */
	public void setState(String state) {
		if (null == this.getState()) {
			this.state = SUBMITTED_NAME;
		}
		if (!SUBMITTED_NAME.equals(state) && !BACKLOG_NAME.equals(state) && !WORKING_NAME.equals(state) &&
				!VERIFYING_NAME.equals(state) && !COMPLETED_NAME.equals(state) && !REJECTED_NAME.equals(state) && null != state && !"".equals(state)) {
			throw new IllegalArgumentException("Invalid state");
		}
		else {
			this.state = state;
		}
		
	}

	/**
	 * Getter method for the action for a story statement
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * Setter method for the action for a story statement
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * Getter method for the value information used in a story
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Setter method for the value information used in a story
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Getter method for the priority of a story
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * Setter method for the priority of a story.
	 * @param priority the priority to set
	 * @throws IllegalArgumentException if the priority given is not a valid priority
	 */
	public void setPriority(String priority) {
		if (this.getPriority() == null) {
			this.priority = priority;
		}
		if (!HIGH_PRIORITY.equals(priority) && !MEDIUM_PRIORITY.equals(priority) && !LOW_PRIORITY.equals(priority) && null != priority && !"".equals(priority)) {
			throw new IllegalArgumentException("Invalid priority");
		}
		else {
			this.priority = priority;
		}
	}

	/**
	 * Getter method for the developer id
	 * @return the developerId
	 */
	public String getDeveloperId() {
		return developerId;
	}

	/**
	 * Setter method for the developer id
	 * @param developerId the developerId to set
	 */
	public void setDeveloperId(String developerId) {
		this.developerId = developerId;
	}

	/**
	 * Getter method for the rejection reason
	 * @return the rejectionReason
	 */
	public String getRejectionReason() {
		return rejectionReason;
	}

	/**
	 * Setter method for the rejection reason
	 * @param rejectionReason the rejectionReason to set
	 */
	public void setRejectionReason(String rejectionReason) {
		if (null == rejectionReason) {
			this.rejectionReason = rejectionReason;
		}
		else if (!DUPLICATE_REJECTION.equals(rejectionReason) && !INAPPROPRIATE_REJECTION.equals(rejectionReason)
				&& !INFEASIBLE_REJECTION.equals(rejectionReason)) {
			throw new IllegalArgumentException("Invalid rejection reason");
		}
		else {
			this.rejectionReason = rejectionReason;
		}
	}
	
	/**
	 * Method to increment the story counter by 1
	 */
	public static void incrementCounter() {
		UserStory.counter++;
	}
	
	/**
	 * Method to set the story counter to any given value
	 * @param newCount the value being set to
	 */
	public static void setCounter(int newCount) {
		UserStory.counter = newCount;
	}
	
	/**
	 * toString method for a UserStory, follows specific outputs depending on the state of the story
	 * @return s string of information in correct format
	 */
	public String toString() {
		String s = "";
		if (SUBMITTED_NAME.equals(state)) {
			s += "* " + this.storyId + "," + this.state + "," + this.title + "," + "\n" + "- " + this.user + "\n" + "- " + this.action + "\n" + "- " + this.value;
		}
		if (BACKLOG_NAME.equals(state)) {
			s += "* " + this.storyId + "," + this.state + "," + this.title + "," + this.priority + "," + "\n" + "- " + this.user + "\n" + "- " + this.action + "\n" + "- " + this.value;
		}
		if (WORKING_NAME.equals(state)) {
			s += "* " + this.storyId + "," + this.state + "," + this.title + "," + this.priority + "," + this.developerId + "\n" + "- " + this.user + "\n" + "- " + this.action + "\n" + "- " + this.value;
		}
		if (VERIFYING_NAME.equals(state)) {
			s += "* " + this.storyId + "," + this.state + "," + this.title + "," + this.priority + "," + this.developerId + "\n" + "- " + this.user + "\n" + "- " + this.action + "\n" + "- " + this.value;
		}
		if (COMPLETED_NAME.equals(state)) {
			s += "* " + this.storyId + "," + this.state + "," + this.title + "," + this.priority + "," + this.developerId + "\n" + "- " + this.user + "\n" + "- " + this.action + "\n" + "- " + this.value;
		}
		if (REJECTED_NAME.equals(state)) {
			s += "* " + this.storyId + "," + this.state + "," + this.title + "," + this.rejectionReason + "\n" + "- " + this.user + "\n" + "- " + this.action + "\n" + "- " + this.value;
		}
		return s;
		
	}
	
	/**
	 * Updated the CommandValue for the given user story
	 * @param c the command being updated to
	 * 
	 */
	public void update(Command c) {
		//Can be backlog or rejected
		if (SUBMITTED_NAME.equals(state)) {
			submittedState.updateState(c);
			if (c.getCommand().equals(Command.CommandValue.BACKLOG)) {
				setState(BACKLOG_NAME);
				setPriority(c.getCommandInformation());
			}
			else if (c.getCommand().equals(Command.CommandValue.REJECT)) {
				setState(REJECTED_NAME);
				setRejectionReason(c.getCommandInformation());
			}
		}
		//Can be working or rejected
		else if (BACKLOG_NAME.equals(state)) {
			backlogState.updateState(c);
			if (c.getCommand().equals(Command.CommandValue.ASSIGN)) {
				setState(WORKING_NAME);
				setDeveloperId(c.getCommandInformation());
			}
			else if (c.getCommand().equals(Command.CommandValue.REJECT)) {
				setState(REJECTED_NAME);
				setPriority(null);
				setRejectionReason(c.getCommandInformation());
			}
		}
		//Can be verifying, working, or rejected
		else if (WORKING_NAME.equals(state)) {
			workingState.updateState(c);
			if (c.getCommand().equals(Command.CommandValue.ASSIGN)) {
				setState(WORKING_NAME);
				setDeveloperId(c.getCommandInformation());
			}
			else if (c.getCommand().equals(Command.CommandValue.REOPEN)) {
				setState(BACKLOG_NAME);
				setDeveloperId(null);
			}
			else if (c.getCommand().equals(Command.CommandValue.REJECT)) {
				setState(REJECTED_NAME);
				setRejectionReason(c.getCommandInformation());
				setDeveloperId(null);
				setPriority(null);
			}
			else if (c.getCommand().equals(Command.CommandValue.REVIEW)) {
				setState(VERIFYING_NAME);
			}
		}
		//Can be completed or working
		else if (VERIFYING_NAME.equals(state)) {
			verifyingState.updateState(c);
			if (c.getCommand().equals(Command.CommandValue.REOPEN)) {
				setState(WORKING_NAME);
			}
			else if (c.getCommand().equals(Command.CommandValue.CONFIRM)) {
				setState(COMPLETED_NAME);
			}
		}
		//Can only be working
		else if (COMPLETED_NAME.equals(state)) {
			completedState.updateState(c);
			if (c.getCommand().equals(Command.CommandValue.REOPEN)) {
				setState(WORKING_NAME);
			}
		}
		//Can only be submitted
		else if (REJECTED_NAME.equals(state)) {
			rejectedState.updateState(c);
			if (c.getCommand().equals(Command.CommandValue.RESUBMIT)) {
				setState(SUBMITTED_NAME);
				setRejectionReason(null);
			}
		}
		else {
			throw new IllegalArgumentException("Invalid state");
		}
		
	}
	
	
	
	/**
	 * Interface for states in the UserStory State Pattern.  All 
	 * concrete user story states must implement the UserStoryState interface.
	 * The UserStoryState interface should be a private interface of the 
	 * UserStory class.
	 * 
	 * @author Dr. Sarah Heckman (sarah_heckman@ncsu.edu) 
	 */
	private interface UserStoryState {
		
		/**
		 * Update the UserStory based on the given Command.
		 * An UnsupportedOperationException is throw if the Command
		 * is not a valid action for the given state.  
		 * @param command Command describing the action that will update the UserStory's
		 * state.
		 * @throws UnsupportedOperationException if the Command is not a valid action
		 * for the given state.
		 */
		void updateState(Command command);
		
		/**
		 * Returns the name of the current state as a String.
		 * @return the name of the current state as a String.
		 */
		String getStateName();

	}
	
	/**
	 * Inner class of UserStory that creates a submitted state object as well as updates a state and gets
	 * the state's name.
	 * @author Jakob Woodard
	 *
	 */
	private class SubmittedState implements UserStoryState {
		
		private SubmittedState() {
			
		}
		
		/**
		 * Updates the state of a story
		 * @param command the command for the story
		 */
		@Override
		public void updateState(Command command) {
			//Can be backlog or rejected
			if (!command.getCommand().equals(Command.CommandValue.BACKLOG) && !command.getCommand().equals(Command.CommandValue.REJECT)) {
				throw new UnsupportedOperationException("Submitted UserStorys can only be updated to the Backlog or Rejected after being Reviewed");
			}
			
		}
		
		/**
		 * Returns the name of the state
		 * @return name the name of the state
		 */
		@Override
		public String getStateName() {
			state = SUBMITTED_NAME;
			return state;
		}
		
	}
	
	/**
	 * Inner class of UserStory that creates a BacklogState object as well as updates the state and
	 * gets the state's name
	 * @author Jakob Woodard
	 *
	 */
	private class BacklogState implements UserStoryState {
		
		/**
		 * Updates the state
		 * @param command the command for the story
		 */
		@Override
		public void updateState(Command command) {
			//Can be working or rejected
			if (!command.getCommand().equals(Command.CommandValue.ASSIGN) && !command.getCommand().equals(Command.CommandValue.REJECT)) {
				throw new UnsupportedOperationException("Backloged UserStorys can only be Assigned a developer or Rejected");
			}
			
		}
		
		/**
		 * Returns the state's name
		 * @return name the name of the state
		 */
		@Override
		public String getStateName() {
			state = BACKLOG_NAME;
			return state;
		}
		
	}
	
	/**
	 * Inner class of UserStory that creates a WorkingState object as well as updates the state
	 * and gets the state's name
	 * @author Jakob Woodard
	 *
	 */
	private class WorkingState implements UserStoryState {
		
		/**
		 * Updates the state of the story
		 * @param command the command for the story
		 */
		@Override
		public void updateState(Command command) {
			//Can be verifying, working, or rejected
			if (!command.getCommand().equals(Command.CommandValue.ASSIGN) && !command.getCommand().equals(Command.CommandValue.REOPEN) 
					&& !command.getCommand().equals(Command.CommandValue.REJECT) && !command.getCommand().equals(Command.CommandValue.REVIEW)) {
				throw new UnsupportedOperationException("Working UserStorys can only be Assigned a new developer, moved to Backlog, or Rejected");
			}
		}
		
		/**
		 * Gets the name of the state
		 * @return name the name of the state
		 */
		@Override
		public String getStateName() {
			state = WORKING_NAME;
			return state;
		}
		
	}
	
	/**
	 * Inner class of UserStory that creates a VerifyingState object as well as updates the state 
	 * and get the state's name.
	 * @author Jakob Woodard
	 *
	 */
	private class VerifyingState implements UserStoryState {
		
		/**
		 * Updates the state of the story
		 * @param command the command for the story
		 */
		@Override
		public void updateState(Command command) {
			//Can be verifying, working, or rejected
			if (!command.getCommand().equals(Command.CommandValue.CONFIRM) && !command.getCommand().equals(Command.CommandValue.REOPEN)) {
				throw new UnsupportedOperationException("Verifying UserStorys can only be sent to Confirm or Reviewed and sent back to Working");
			}
		}
		
		/**
		 * Gets the name of the state
		 * @return name the name of the state
		 */
		@Override
		public String getStateName() {
			state = VERIFYING_NAME;
			return state;
		}
		
	}
	
	/**
	 * Inner class of UserStory that creates a CompletedState object as well as updates the state
	 * and gets the state's name
	 * @author Jakob Woodard
	 *
	 */
	private class CompletedState implements UserStoryState {
		
		/**
		 * Updates the state of the story
		 * @param command the command for the story
		 */
		@Override
		public void updateState(Command command) {
			//Can only be working
			if (!command.getCommand().equals(Command.CommandValue.REOPEN)) {
				throw new UnsupportedOperationException("Completed UserStorys can only be Reopened");
			}
		}
		
		/**
		 * Gets the name of the state
		 * @return name the name of the state
		 */
		@Override
		public String getStateName() {
			state = COMPLETED_NAME;
			return state;
		}
		
	}
	
	/**
	 * Inner class of UserStory that creates a RejectedState class as well as updates the state
	 * and gets the state's name
	 * @author Jakob Woodard
	 *
	 */
	private class RejectedState implements UserStoryState {
		
		/**
		 * Updates the state of the story
		 * @param command the command for the story
		 */
		@Override
		public void updateState(Command command) {
			//Can only be submitted
			if (!command.getCommand().equals(Command.CommandValue.RESUBMIT)) {
				throw new UnsupportedOperationException("Rejected UserStorys can only be Resubmitted");
			}
		}
		
		/**
		 * Gets the name of the state
		 * @return name the name of the state
		 */
		@Override
		public String getStateName() {
			state = REJECTED_NAME;
			return state;
		}
		
	}

}
