package edu.ncsu.csc216.pack_scheduler.user;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.user.schedule.Schedule;

/**
 * Class to create a student object
 * @author Jakob Woodard
 *
 */

public class Student extends User implements Comparable<Student> {
	
	/** max number of credits for all students */
	public static final int MAX_CREDITS = 18;
	/** max credits per student */
	private int maxCredits;
	/** Student's personal schedule */
	private Schedule schedule;
	
	
	/**
	 * Student constructor object
	 * @param firstName student first name
	 * @param lastName student last name
	 * @param id student id
	 * @param email student email
	 * @param password student password
	 * @param maxCredits max amount of credits
	 */
	public Student(String firstName, String lastName, String id, String email, String password, int maxCredits) {
		super(firstName, lastName, id, email, password);
		setMaxCredits(maxCredits);
		schedule = new Schedule();
	}
	
	

	/**
	 * Constructor for Student Object
	 * @param firstName student first name
	 * @param lastName student last name
	 * @param id student id
	 * @param email student email
	 * @param password student password
	 */
	public Student(String firstName, String lastName, String id, String email, String password) {
		super(firstName, lastName, id, email, password);
		this.maxCredits = MAX_CREDITS;
		schedule = new Schedule();
	}
	

	
	
	
	
	
	
	/**
	 * getter for max credits
	 * @return the maxCredits
	 */
	public int getMaxCredits() {
		return maxCredits;
	}

	/**
	 * setter for max credits
	 * @param maxCredits the maxCredits to set
	 * @throws IllegalArgumentException if credits are less than 3 or greater than 18
	 */
	public void setMaxCredits(int maxCredits) {
		if (maxCredits < 3) {
			throw new IllegalArgumentException("Invalid max credits");
		}
		if (maxCredits > 15) {
			this.maxCredits = MAX_CREDITS;
		}
		this.maxCredits = maxCredits;
	}


	/**
	 * Creates a String describing the entirety of the student object that 
	 * was created.
	 */
	@Override
	public String toString() {
		return getFirstName() + "," + getLastName() + "," + getId() + "," + getEmail()
				+ "," + getPassword() + "," + maxCredits;

	}

	/**
	 * Overrides the compareTo() method to be usable for student objects. If either the last name, first name, or id is different between objects,
	 * then either -1 or 1 is returned depending on which is greater. If all parts of the objects are the same, 0 is returned.
	 * @return -1 if .this should come before comparing student, 1 if .this should come after comparing student, or 0 if the students are equal.
	 */
	@Override
	public int compareTo(Student s) {
		//.this comes before compared
		if (this.getLastName().compareToIgnoreCase(s.getLastName()) < 0) {
			return -1;
		}
		//.this comes after compared
		if (this.getLastName().compareToIgnoreCase(s.getLastName()) > 0) {
			return 1;
		}
		if (this.getLastName().compareToIgnoreCase(s.getLastName()) == 0) {
			//.this comes before compared
			if (this.getFirstName().compareToIgnoreCase(s.getFirstName()) < 0) {
				return -1;
			}
			//.this comes after compared
			if (this.getFirstName().compareToIgnoreCase(s.getFirstName()) > 0) {
				return 1;
			}
			if (this.getFirstName().compareToIgnoreCase(s.getFirstName()) == 0) {
				//.this comes before compared
				if (this.getId().compareToIgnoreCase(s.getId()) < 0) {
					return -1;
				}
				//.this comes after compared
				if (this.getId().compareToIgnoreCase(s.getId()) > 0) {
					return 1;
				}
				//.this and compared have same order
				if (this.getId().compareToIgnoreCase(s.getId()) == 0) {
					return 0;
				}
			}
		}
		return 1000000; //This should never be reached
	}



	/**
	 * Checks that the hashCode is generated correctly
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + maxCredits;
		return result;
	}


	/**
	 * Checks that the Student object is created correctly
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return maxCredits == other.maxCredits;
	}
	/**
	 * Getter method for the student's personal schedule
	 * @return schedule of the student
	 */
	public Schedule getSchedule() {
		return schedule;
	}
	
	/**
	 * Boolean method to check that a desired course can be added to a students schedule
	 * @param c course to be added
	 * @return true if the course can be added, false if not
	 */
	public boolean canAdd(Course c) {
		if (!schedule.canAdd(c)) {
			return false;
		}
		return schedule.getScheduleCredits() + c.getCredits() <= maxCredits;

	}

	
	
	
}
