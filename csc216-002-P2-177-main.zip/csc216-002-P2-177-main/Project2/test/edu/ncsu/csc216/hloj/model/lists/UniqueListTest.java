/**
 * 
 */
package edu.ncsu.csc216.hloj.model.lists;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Test cases for UniqueList
 * @author Jakob Woodard
 *
 */
public class UniqueListTest {

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.lists.UniqueList#UniqueList()}.
	 */
	@Test
	public void testUniqueList() {
		UniqueList<String> list = new UniqueList<String>();
		assertEquals(0, list.size());
		
		list.add("Zero");
		list.add("One");
		
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		
		try {
			list.add(null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals("Element is null", e.getMessage());
		}
		
		try {
			list.add("Zero");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Element already exists", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.lists.UniqueList#UniqueList(int)}.
	 */
	@Test
	public void testUniqueListInt() {
		UniqueList<String> list = new UniqueList<String>(10);
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		//Testing that the capacity of the list is properly increased
		list.add(10, "Ten");
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		assertEquals("Ten", list.get(10));
		
		list.add(0, "Twelve");
		assertEquals("Twelve", list.get(0));
		assertEquals("Zero", list.get(1));
		assertEquals("One", list.get(2));
		assertEquals("Two", list.get(3));
		assertEquals("Three", list.get(4));
		assertEquals("Four", list.get(5));
		assertEquals("Five", list.get(6));
		assertEquals("Six", list.get(7));
		assertEquals("Seven", list.get(8));
		assertEquals("Eight", list.get(9));
		assertEquals("Nine", list.get(10));
		assertEquals("Ten", list.get(11));
		
		
		
		
		
		try {
			list.add(15, "Nice");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Index of 15 is out of bounds for size 12", e.getMessage());
		}
		
		try {
			list.add(11, null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals("Element is null", e.getMessage());
		}
		
		try {
			list.add(-1, "Potato");
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals("Index of -1 is out of bounds for size 12", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.lists.UniqueList#remove(int)}.
	 */
	@Test
	public void testRemoveInt() {
		
		UniqueList<String> list = new UniqueList<String>(10);
		assertEquals(0, list.size());
		//Adding 10 elements
		list.add(0, "Zero");
		list.add(1, "One");
		list.add(2, "Two");
		list.add(3, "Three");
		list.add(4, "Four");
		list.add(5, "Five");
		list.add(6, "Six");
		list.add(7, "Seven");
		list.add(8, "Eight");
		list.add(9, "Nine");
		//Asserting that all values are where they should be
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		
		//Testing that the capacity of the list is properly increased
		list.add(10, "Ten");
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Four", list.get(4));
		assertEquals("Five", list.get(5));
		assertEquals("Six", list.get(6));
		assertEquals("Seven", list.get(7));
		assertEquals("Eight", list.get(8));
		assertEquals("Nine", list.get(9));
		assertEquals("Ten", list.get(10));
	
		
		list.remove(4);
		assertEquals("Zero", list.get(0));
		assertEquals("One", list.get(1));
		assertEquals("Two", list.get(2));
		assertEquals("Three", list.get(3));
		assertEquals("Five", list.get(4));
		assertEquals("Six", list.get(5));
		assertEquals("Seven", list.get(6));
		assertEquals("Eight", list.get(7));
		assertEquals("Nine", list.get(8));
		assertEquals("Ten", list.get(9));
	}

}
