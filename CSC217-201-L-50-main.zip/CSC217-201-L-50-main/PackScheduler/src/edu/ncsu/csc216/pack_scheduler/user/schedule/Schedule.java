/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.user.schedule;

import edu.ncsu.csc216.pack_scheduler.course.ConflictException;
import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.util.ArrayList;

/**
 * Class using the custom ArrayList to create a schedule that consists of courses for a student to use
 * @author Jakob Woodard
 *
 */
public class Schedule {
	/** Custom ArrayList of Courses */
	private ArrayList<Course> schedule;
	/** Title of the schedule */
	private String title;
	/**
	 * Constructor for the schedule, creates an empty ArrayList and sets the title to "My Schedule"
	 */
	public Schedule() {
		this.schedule = new ArrayList<>();
		setTitle("My Schedule");
		
	}
	
	/**
	 * Adds a course to the schedule. Throws IAEs if the course already exists in the schedule or if there is a 
	 * conflict exception that is thrown
	 * @param c course to be added
	 * @return true if the course was added
	 * @throws IllegalArgumentException if the course exists within the schedule
	 * @throws IllegalArgumentException if a ConflictException is thrown
	 */
	public boolean addCourseToSchedule(Course c) {
		for (int i = 0; i < schedule.size(); i++) {
			if (c.getName().equals(schedule.get(i).getName()) && c.getSection().equals(schedule.get(i).getSection()) 
					|| c.isDuplicate(schedule.get(i))) {
				throw new IllegalArgumentException("You are already enrolled in " + c.getName());
			}
			try {
				schedule.get(i).checkConflict(c);
			}
			catch (ConflictException e) {
				throw new IllegalArgumentException("The course cannot be added due to a conflict.");
			}
		}
		schedule.add(schedule.size(), c);
		return true;
	}
	/**
	 * Removes a course from the schedule
	 * @param c course to be removed
	 * @return true if the course was removed, false if there was no such course
	 */
	public boolean removeCourseFromSchedule(Course c) {
		for (int i = 0; i < schedule.size(); i++) {
			if (c.equals(schedule.get(i))) {
				schedule.remove(i);
				return true;
			}
		}
		return false;
	}
	/**
	 * Resets the schedule, making a new empty ArrayList and setting the title to "My Schedule"
	 */
	public void resetSchedule() {
		schedule = new ArrayList<Course>();
		setTitle("My Schedule");
	}
	/**
	 * Creates and returns a 2D array of course information for each course within the schedule
	 * @return courses the 2D array of course information
	 */
	public String[][] getScheduledCourses() {
		String[][] courses = new String[schedule.size()][5];
		for (int i = 0; i < schedule.size(); i++) {
			courses[i][0] = schedule.get(i).getName();
			courses[i][1] = schedule.get(i).getSection();
			courses[i][2] = schedule.get(i).getTitle();
			courses[i][3] = schedule.get(i).getMeetingString();
			courses[i][4] = schedule.get(i).getShortDisplayArray()[4];
		}
		return courses;
	}
	/**
	 * Sets the title of the schedule. No null titles are allowed
	 * @param title of the schedule
	 * @throws IllegalArgumentException if the title is null
	 */
	public void setTitle(String title) {
		if (title == null) {
			throw new IllegalArgumentException("Title cannot be null.");
		}
		this.title = title;
	}
	/**
	 * Getter method for the title
	 * @return title of the schedule
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * Getter method for the total scheduled credits. This method goes through each scheduled course and sums up the amount of
	 * credit hours that each course has.
	 * @return sum the sum of all credit hours
	 */
	public int getScheduleCredits() {
		int sum = 0;
		for (int i = 0; i < schedule.size(); i++) {
			sum += schedule.get(i).getCredits();
		}
		return sum;
	}
	/**
	 * Boolean method that returns true if the course can be added to the schedule and false if not. 
	 * @param c course attempting to be added
	 * @return true if the course can be added to the schedule
	 */
	public boolean canAdd(Course c) {
		if (c == null) {
			return false;
		}
		for (int i = 0; i < schedule.size(); i++) {
			if (schedule.get(i).getName().equals(c.getName()) && schedule.get(i).getTitle().equals(c.getTitle())) {
				return false;
			}
			try {
				schedule.get(i).checkConflict(c);
			} catch (ConflictException e) {
				return false;
			}
		}
		return true;
	}

}
