package edu.ncsu.csc216.pack_scheduler.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.NoSuchElementException;
import java.util.Scanner;




import edu.ncsu.csc216.pack_scheduler.user.Student;
import edu.ncsu.csc217.collections.list.SortedList;
/**
 * Class to process a file with a student record and write it into a file.
 * @author Jakob Woodard
 *
 */
public class StudentRecordIO {
	/**
	 * Reads in a student record and generates a valid list of directories. Invalid students are
	 * ignored and a FNFE is thrown if permissions are incorrect or if a file cannot be
	 * read
	 * @param fileName name of file being read
	 * @return a list of valid directories
	 * @throws FileNotFoundException if the file could not be found
	 */
	public static SortedList<Student> readStudentRecords(String fileName) throws FileNotFoundException {
		Scanner fileReader = new Scanner(new FileInputStream(fileName));  //Create a file scanner to read the file
	    SortedList<Student> students = new SortedList<Student>(); //Create an empty array of Course objects
	    while (fileReader.hasNextLine()) { //While we have more lines in the file
	        try { //Attempt to do the following
	            //Read the line, process it in readCourse, and get the object
	            //If trying to construct a Course in readCourse() results in an exception, flow of control will transfer to the catch block, below
	            Student student = processStudent(fileReader.nextLine()); 

	            //Create a flag to see if the newly created Course is a duplicate of something already in the list  
	            boolean duplicate = false;
	            //Look at all the courses in our list
	            for (int i = 0; i < students.size(); i++) {
	                //Get the student at index i
	                Student current = students.get(i);
	                //Check if the first and last names are the same
	                if (student.getFirstName().equals(current.getFirstName()) &&
	                        student.getLastName().equals(current.getLastName())) {
	                    //It's a duplicate!
	                    duplicate = true;
						break; //We can break out of the loop, no need to continue searching
	                }
	            }
	            //If the course is NOT a duplicate
	            if (!duplicate) {
	                students.add(student); //Add to the ArrayList!
	            } //Otherwise ignore
	        } 
	        catch (IllegalArgumentException e) {
	        	try {
	        		fileReader.nextLine();
	        	}
	        	catch (NoSuchElementException f) {
	        		break;
	        	}
	            //The line is invalid b/c we couldn't create a course, skip it!
	        }
	    }
	    //Close the Scanner b/c we're responsible with our file handles
	    fileReader.close();
	    //Return the ArrayList with all the courses we read!
	    return students;
	}
	/**
	 * Helper method for the readStudentRecords method	
	 * @param nextLine next line of file being read
	 * @return processed student
	 */
	private static Student processStudent(String nextLine) {
			Scanner in = new Scanner(nextLine);
			in.useDelimiter(",");
			String first = "";
			String last = "";
			String id = "";
			String email = "";
			String password = "";
			int credits = 0;
			while (in.hasNext()) {
				try {
					first = in.next();
					last = in.next();
					id = in.next();
					email = in.next();
					password = in.next();
					if (!in.hasNext()) {
						in.close();
						throw new IllegalArgumentException();
					}
					credits = in.nextInt();	
				}
				catch (NoSuchElementException e) {
					throw new IllegalArgumentException();
				}
			}
			Student student = new Student(first, last, id, email, password, credits);
			in.close();
			return student;
		}
	/**
	 * Writes a list of student records onto a file
	 * @param fileName name of file to write Students to
	 * @param studentDirectory list of students to write
	 * @throws IOException if cannot write to a file
	 */
	public static void writeStudentRecords(String fileName, SortedList<Student> studentDirectory) throws IOException {
		PrintStream fileWriter = new PrintStream(new File(fileName));

		for (int i = 0; i < studentDirectory.size(); i++) {
		    fileWriter.println(studentDirectory.get(i).toString());
		}

		fileWriter.close();
		
	}

}