/**
 * 
 */
package edu.ncsu.csc216.hloj.model;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for Order
 * @author Jakob Woodard
 *
 */
public class OrderTest {
	
	/** First name for testing */
	private static final String FIRST = "first";
	/** Last name for testing */
	private static final String LAST = "last";
	/** Id for testing */
	private static final String ID = "id";
	/** Margin of error for doubles */
	private static final double DELTA = .001;

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Order#Order(int, edu.ncsu.csc216.hloj.model.Customer)}.
	 */
	@Test
	public void testOrder() {
		
		try {
			Customer c = new Customer(FIRST, LAST, ID);
			Order o = new Order(1, c);
			assertEquals(1, o.getNumber());
			assertEquals(c, o.getCustomer());
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
		
		try {
			Customer c = new Customer(FIRST, LAST, ID);
			new Order(0, c);
			fail();
		}
		catch (ModelException e) {
			assertEquals("Order numbers must be larger than zero", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Order#addMenuItem(edu.ncsu.csc216.hloj.model.MenuItem)}.
	 */
	@Test
	public void testAddMenuItem() {
		
		try {
			Customer c = new Customer("First", "Last", "flast");
			Order o = new Order(1, c);
			MenuItem m = new MenuItem("Coffe", "Black", 1.5);
			o.addMenuItem(m);
			assertEquals(1, o.getItems().length);
			assertEquals(1, o.getItems()[0].getQuantity());
			o.addMenuItem(m);
			assertEquals(1, o.getItems().length);
			assertEquals(2, o.getItems()[0].getQuantity());
			
		} catch (ModelException e) {
			fail("Unexpected ModelException");
		}
		
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Order#removeMenuItem(edu.ncsu.csc216.hloj.model.MenuItem)}.
	 */
	@Test
	public void testRemoveMenuItem() {
		try {
			Customer c = new Customer("First", "Last", "flast");
			Order o = new Order(1, c);
			MenuItem m = new MenuItem("Coffe", "Black", 1.5);
			o.addMenuItem(m);
			assertEquals(1, o.getItems().length);
			o.removeMenuItem(m);
			assertEquals(0, o.getItems().length);
			
		} catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Order#toString()}.
	 */
	@Test
	public void testToString() {

		try {
			Customer c = new Customer(FIRST, LAST, ID);
			Order o = new Order(1, c);
			assertEquals("#" + o.getNumber() + " for " + c.getFirstName() + " " + c.getLastName() + "- Total: $" + o.getTotal(), o.toString());
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Order#compareTo(edu.ncsu.csc216.hloj.model.Order)}.
	 */
	@Test
	public void testCompareTo() {
		
		try {
			Customer c = new Customer(FIRST, LAST, ID);
			Customer c2 = new Customer("Different", LAST, "Different");
			Order o = new Order(1, c);
			Order o2 = new Order(2, c2);
			
			assertEquals(-1, o.compareTo(o2));
			assertEquals(1, o2.compareTo(o));
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}
	
	/**
	 * Test method for getTotal()
	 */
	@Test
	public void testGetTotal() {
		try {
			Customer c = new Customer("First", "Last", "flast");
			Order o = new Order(1, c);
			MenuItem m = new MenuItem("Coffe", "Black", 1.5);
			o.addMenuItem(m);
			assertEquals(1, o.getItems().length);
			assertEquals(1, o.getItems()[0].getQuantity());
			o.addMenuItem(m);
			assertEquals(1, o.getItems().length);
			assertEquals(2, o.getItems()[0].getQuantity());
			assertEquals(3.0, o.getTotal(), DELTA);
			
		} catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

}
