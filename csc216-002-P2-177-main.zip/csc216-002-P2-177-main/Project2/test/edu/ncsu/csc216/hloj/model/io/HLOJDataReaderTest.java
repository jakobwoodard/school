/**
 * 
 */
package edu.ncsu.csc216.hloj.model.io;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.hloj.model.manager.CustomerManager;
import edu.ncsu.csc216.hloj.model.manager.MenuManager;
import edu.ncsu.csc216.hloj.model.manager.OrderManager;

/**
 * Test cases for HLOJDataReader
 * @author Jakob Woodard
 *
 */
public class HLOJDataReaderTest {
	
	/** Data file for testing */
	private final String testFile1 = "test-files/data1.txt";
	/** Data file for testing */
	private final String testFile2 = "test-files/data2.txt";
	/** Data file for testing */
	private final String testFile3 = "test-files/data3.txt";

	
	/**
	 * Resetting all of the managers before each test
	 */
	@Before
	public void resetManagers() {
		OrderManager.getInstance().removeAllOrders();
		MenuManager.getInstance().removeAllMenuItems();
		CustomerManager.getInstance().removeAllCustomers();
	}
	
	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.io.HLOJDataReader#readData(java.lang.String)}.
	 */
	@Test
	public void testReadData() {
		OrderManager om = OrderManager.getInstance();
		
		HLOJDataReader.readData(testFile1);
		
		assertEquals(om.getOrders().length, 3);
		assertEquals(om.getOrders()[om.getOrders().length - 1].getCustomer().getId(), "jctetter");
		
		HLOJDataReader.readData(testFile2);
		assertEquals(om.getOrders().length, 3);
		assertEquals(om.getOrders()[om.getOrders().length - 1].getCustomer().getId(), "jctetter");
		
		HLOJDataReader.readData(testFile3);
		assertEquals(om.getOrders().length, 5);
		assertEquals(om.getOrders()[om.getOrders().length - 1].getCustomer().getId(), "jd1");
	}

}
