package edu.ncsu.csc216.project_manager.model.command;


import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.ncsu.csc216.project_manager.model.command.Command.CommandValue;
/**
 * Tests for the Command class
 * @author Jakob Woodard
 *
 */
public class CommandTest {

	/**
	 * Testing method for creating a valid command and that the getters for both command and commandInformation work properly
	 */
	@Test
	public void testCommand() {
		
		//Creating valid Command with info
		Command c = new Command(CommandValue.BACKLOG, "info");
		assertEquals(c.getCommand(), CommandValue.BACKLOG);
		assertEquals(c.getCommandInformation(), "info");
		
		//Creating valid Command without info
		Command c2 = new Command(CommandValue.CONFIRM, null);
		assertEquals(c2.getCommand(), CommandValue.CONFIRM);
		
		//Testing creating with null command
		try {
			new Command(null, "info");
		}
		catch (IllegalArgumentException e) {
			assertEquals("A Command MUST have a CommandValue", e.getMessage());
		}
		//Testing for BACKLOG CommandValue
		try {
			new Command(CommandValue.BACKLOG, "");
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command requires an additional piece of information", e.getMessage());
		}
		try {
			new Command(CommandValue.BACKLOG, null);
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command requires an additional piece of information", e.getMessage());
		}
		//Testing for ASSIGN CommandValue
		try {
			new Command(CommandValue.ASSIGN, "");
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command requires an additional piece of information", e.getMessage());
		}
		try {
			new Command(CommandValue.ASSIGN, null);
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command requires an additional piece of information", e.getMessage());
		}
		//Testing for REJECT CommandValue
		try {
			new Command(CommandValue.REJECT, "");
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command requires an additional piece of information", e.getMessage());
		}
		try {
			new Command(CommandValue.REJECT, null);
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command requires an additional piece of information", e.getMessage());
		}
		//Testing for REVIEW CommandValue
		try {
			new Command(CommandValue.REVIEW, "info");
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command doesn't requires an additional piece of information", e.getMessage());
		}
		//Testing for CONFIRM CommandValue
		try {
			new Command(CommandValue.CONFIRM, "info");
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command doesn't requires an additional piece of information", e.getMessage());
		}
		//Testing for REOPEN CommandValue
		try {
			new Command(CommandValue.REOPEN, "info");
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command doesn't requires an additional piece of information", e.getMessage());
		}
		//Testing for RESUBMIT CommandValue
		try {
			new Command(CommandValue.RESUBMIT, "info");
		}
		catch (IllegalArgumentException e) {
			assertEquals("This command doesn't requires an additional piece of information", e.getMessage());
		}
	}

}
