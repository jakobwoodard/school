/**
 * 
 */
package edu.ncsu.csc216.hloj.model;

/**
 * An order item stores a menu item and the quantity of that item that was ordered.
 * @author Jakob Woodard
 *
 */
public class OrderItem implements Comparable<OrderItem> {
	
	/** Quantity of specific MenuItem's ordered */
	private int quantity;
	/** Menu item being ordered */
	private MenuItem menuItem;
	
	/**
	 * Constructor for an OrderItem which specifies a singular MenuItem
	 * @param m MenuItem being ordered
	 */
	public OrderItem(MenuItem m) {
		this.menuItem = m;
	}

	/**
	 * Gets the quantity of MenuItem's ordered
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * Error checks the quantity and then sets it equal to the OrderItem's quantity
	 * @param quantity the quantity to set
	 * @throws ModelException if the quantity is less than 1
	 */
	public void setQuantity(int quantity) throws ModelException {
		if (quantity < 1) {
			throw new ModelException("The quantity of an item in an order has to be greater than zero");
		}
		this.quantity = quantity;
	}

	/**
	 * Gets the MenuItem being ordered
	 * @return the menuItem
	 */
	public MenuItem getMenuItem() {
		return menuItem;
	}

	/**
	 * Sets the MenuItem of the OrderItem equal to the passed MenuItem
	 * @param menuItem the menuItem to set to
	 */
	public void setMenuItem(MenuItem menuItem) {
		this.menuItem = menuItem;
	}
	
	/**
	 * Compares two order items and returns -1 if the passed order item is "less" than another, 1 if the passed order item
	 *  is "greater" than the other, or 0 if the two order items are equal
	 * @param o new order item being compared with
	 * @return -1, 0, or 1 depending on how the passed order item compares to the one being constructed.
	 */
	@Override
	public int compareTo(OrderItem o) {
		//Setting return value to ensure statement coverage at the end 
		int returnValue = 100;
		//.this comes before compared
		if (this.getMenuItem().compareTo(o.getMenuItem()) < 0) {
			returnValue = -1;
		}
		//.this comes after compared
		if (this.getMenuItem().compareTo(o.getMenuItem()) > 0) {
			returnValue = 1;
		}
		if (this.getMenuItem().compareTo(o.getMenuItem()) == 0) {
			returnValue = 0;
		}
		return returnValue;
	}
	
	
	

}
