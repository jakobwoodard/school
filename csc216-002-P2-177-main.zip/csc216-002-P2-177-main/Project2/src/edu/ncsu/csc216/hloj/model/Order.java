/**
 * 
 */
package edu.ncsu.csc216.hloj.model;

import edu.ncsu.csc216.hloj.model.lists.SortedList;

/**
 * An order has a number, the customer that placed the order, and a list of OrderItems. 
 * Only one OrderItem with the same MenuItem is allowed�the quantity can be updated as needed.
 * @author Jakob Woodard
 *
 */
public class Order implements Comparable<Order> {
	
	/** Number of the order */
	private int number;
	/** Items in the order */
	private SortedList<OrderItem> items = new SortedList<OrderItem>();
	/** Customer who ordered */
	private Customer customer;
	
	/**
	 * Constructor for an order that uses a number to create an order number and a customer to associate the order with
	 * @param number order number
	 * @param customer customer whose order it is
	 * @throws ModelException if the number is not larger than 0
	 */
	public Order(int number, Customer customer) throws ModelException {
		if (number < 1) {
			throw new ModelException("Order numbers must be larger than zero");
		}
		this.number = number;
		this.customer = customer;
	}
	
	/**
	 * Gets and returns the index of a passed menu item in the list of order items. If the menu item does not correspond
	 * to an order item index, -1 is returned
	 * @param m MenuItem user wants the index of
	 * @return index of the menu item in terms of the order items that the user wants, or -1 if the item is not in the list.
	 */
	private int getOrderItemIndexForMenuItem(MenuItem m) {
		for (int i = 0; i < items.size(); i++) {
			if (items.get(i).getMenuItem().equals(m)) {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * Adds a MenuItem to the list of OrderItems
	 * @param m menu item to be added
	 */
	public void addMenuItem(MenuItem m) {
		OrderItem item = new OrderItem(m);
		for (int i = 0; i < items.size(); i++) {
			if (items.get(i).getMenuItem().equals(m)) {
				try {
					items.get(i).setQuantity(items.get(i).getQuantity() + 1);
				} catch (ModelException e) {
					throw new IllegalArgumentException("Unexpected ModelException");
				}
			}
		}
		if (getOrderItemIndexForMenuItem(m) == -1) {
			try {
				item.setQuantity(1);
			} catch (ModelException e) {
				// Since we check for the item being in the list first, this is guarenteed to word
				// and thus, the catch block is not needed
			}
			items.add(item);
		}
		
		
	}
	
	/**
	 * Removes a specified MenuItem from the list of OrderItems
	 * @param m menu item to be removed
	 */
	public void removeMenuItem(MenuItem m) {
		for (int i = 0; i < items.size(); i++) {
			if (items.get(i).getMenuItem().equals(m)) {
				items.remove(i);
			}
		}
	}


	/**
	 * Gets the order
	 * @return number the number of the order
	 */
	public int getNumber() {
		return number;
	}


	/**
	 * Gets a 2D array of items within the order
	 * @return orderItems all of the order items
	 */
	public OrderItem[] getItems() {
		OrderItem[] orderItems = new OrderItem[items.size()];
		for (int i = 0; i < items.size(); i++) {
			orderItems[i] = items.get(i);
		}
		return orderItems;
	}


	/**
	 * Gets the details for the customer who ordered
	 * @return customer the customer
	 */
	public Customer getCustomer() {
		return customer;
	}
	
	/**
	 * Gets the total for the order
	 * @return total of the order
	 */
	public double getTotal() {
		double total = 0;
		for (int i = 0; i < items.size(); i++) {
			total += items.get(i).getQuantity() * items.get(i).getMenuItem().getPrice();
		}
		return total;
	}
	
	/**
	 * Creates a string representation of an order to be used by the GUI
	 * @return a string representation formatted as �#number for customerFirstName customerLastName - Total: $total�.
	 */
	public String toString() {
		return "#" + number + " for " + customer.getFirstName() + " " + customer.getLastName() + "- Total: $" + getTotal();
	}
	
	/**
	 * Compares two orders and returns -1 if the passed order is "less" than another, 1 if the passed order
	 *  is "greater" than the other, or 0 if the two orders are equal
	 * @param o new order being compared with
	 * @return -1, 0, or 1 depending on how the passed order compares to the one being constructed.
	 */
	@Override
	public int compareTo(Order o) {
		//Setting return value to ensure statement coverage at the end 
		int returnValue = 100;
		//.this comes before compared
		if (this.getNumber() < o.getNumber()) {
			returnValue = -1;
		}
		//.this comes after compared
		if (this.getNumber() > o.getNumber()) {
			returnValue = 1;
		}
		return returnValue;
	}
	
	
	
}
