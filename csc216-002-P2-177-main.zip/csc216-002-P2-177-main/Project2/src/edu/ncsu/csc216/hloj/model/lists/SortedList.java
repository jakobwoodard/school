/**
 * 
 */
package edu.ncsu.csc216.hloj.model.lists;

import java.util.AbstractList;






/**
 * This is a generic class that extends AbstractList and keeps elements in sorted order by leveraging the Comparable interface.
 * It will be used by the classes in the edu.ncsu.csc216.hloj.model.manager package
 * @author Jakob Woodard
 * @param <E> generic type that the list can hold.
 *
 */
public class SortedList<E extends Comparable<E>> extends AbstractList<E>  {
	
	/** The size of the sorted list */
	private int size;
	/** ListNode of type E */
	private ListNode list;
	
	/**
	 * Creates a SortedList which uses an underlying linked list as a data structure.
	 */
	public SortedList() {
		this.list = new ListNode(null);
		this.size = 0;
	}
	
	/**
	 * Method to add an element to the SortedList
	 * @param element the element to be added
	 * @return true if the item was added, false if not
	 * @throws NullPointerException if the element being added is null
	 * @throws IllegalArgumentException if the element being added is already in the list
	 */
	@Override
	public boolean add(E element) {
		
		if (element == null) {
			throw new NullPointerException("Element is null");
		}
		else {
			ListNode current = list;
			if (size() == 0) {
				list = new ListNode(element, list);		
			}
			else if (element.compareTo(get(0)) < 1) {
				list = new ListNode(element, list);
			}
			else {
				for (int i = 1; i <= size() - 1; i++) {
					if (element.compareTo(get(i)) < 1 || element.compareTo(get(i)) == 0) {
						current = new ListNode(element, current);
					}
					current = current.next;

				}
				current.next = new ListNode(element, current.next);
			}
		}
		size++;
		return true;
	}
	
	/**
	 * Method to remove an element at a specific index from the sorted list
	 * @param index the index of the item to be removed
	 * @return the removed item
	 * @throws IndexOutOfBoundsException if the index is greater than the size or less than 0
	 */
	@Override
	public E remove(int index) {
		if (size() == 0) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		E value = null;
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		if (index == 0) {
			value = list.data;
			list = list.next;
		}
		else {
			ListNode current = list;
			for (int i = 0; i < index - 1; i++) {
				current = current.next;
			}
			value = current.next.data;
			current.next = current.next.next;
		}
		size--;
		return value;
		
	}
	
	/**
	 * Method to get a specific item in the list
	 * @param index the index of the desired item
	 * @return the item at the specified index
	 * @throws IndexOutOfBoundsException if the index is greater than size or less than 0.
	 */
	@Override
	public E get(int index) {
		if (index < 0 || index >= size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		ListNode current = list;
		for (int i = 0; i < index; i++) {
			current = current.next;
		}
		return current.data;
		
	}
	
	/**
	 * Method to get the size of the SortedList
	 * @return size of the SortedList
	 */
	@Override
	public int size() {
		return size;
	}

	
	/**
	 * Inner class of SortedList which is used to organize the SortedList
	 * @author Jakob Woodard
	 *
	 */
	private class ListNode {
		
		/** The data in the node */
		private E data;
		/** The next node in the list */
		private ListNode next;
		
		
		/**
		 * Constructor for a ListNode with only a data value
		 * @param data the data in the node
		 */
		public ListNode(E data) {
			this.data = data;
		}

		/**
		 * Constructor for a ListNode with a next value
		 * @param data the data in the node
		 * @param next the next node in the list
		 */
		public ListNode(E data, ListNode next) {
			this.data = data;
			this.next = next;
		}
		
	}


}
