/**
 * 
 */
package edu.ncsu.csc216.hloj.model;

/**
 * Customer exception class that is thrown when a business rule is broken
 * @author Jakob Woodard
 *
 */
public class ModelException extends Exception {
	
	/**
	 * Default serialID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Basic constructor for the exception, uses a standardized message
	 */
	public ModelException() {
		this("Model Exception");
	}
	
	/**
	 * Constructor for the exception that uses a specified message
	 * @param message the message of the thrown exception
	 */
	public ModelException(String message) {
		super(message);
	}

}
