/**
 * 
 */
package edu.ncsu.csc216.hloj.model;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for Customer
 * @author Jakob Woodard
 *
 */
public class CustomerTest {
	
	/** First name for testing */
	private static final String FIRST = "first";
	/** Last name for testing */
	private static final String LAST = "last";
	/** Id for testing */
	private static final String ID = "id";

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Customer#Customer(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testCustomer() {
		
		try {
			Customer c = new Customer(FIRST, LAST, ID);
			assertEquals("first", c.getFirstName());
			assertEquals("last", c.getLastName());
			assertEquals("id", c.getId());
		} 
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Customer#setFirstName(java.lang.String)}.
	 */
	@Test
	public void testSetFirstName() {
		
		try {
			Customer c = new Customer(FIRST, LAST, ID);
			c.setFirstName(" ");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The first name of the customer cannot be empty", e.getMessage());
		}
		
		try {
			Customer c = new Customer(FIRST, LAST, ID);
			c.setFirstName("");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The first name of the customer cannot be empty", e.getMessage());
		}
		
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Customer#setLastName(java.lang.String)}.
	 */
	@Test
	public void testSetLastName() {

		try {
			Customer c = new Customer(FIRST, LAST, ID);
			c.setLastName(" ");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The last name of the customer cannot be empty", e.getMessage());
		}
		
		try {
			Customer c = new Customer(FIRST, LAST, ID);
			c.setLastName("");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The last name of the customer cannot be empty", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Customer#setId(java.lang.String)}.
	 */
	@Test
	public void testSetId() {

		try {
			Customer c = new Customer(FIRST, LAST, ID);
			c.setId(" ");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The id of the customer cannot be empty", e.getMessage());
		}
		
		try {
			Customer c = new Customer(FIRST, LAST, ID);
			c.setId("");
			fail();
		}
		catch (ModelException e) {
			assertEquals("The id of the customer cannot be empty", e.getMessage());
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Customer#toString()}.
	 */
	@Test
	public void testToString() {

		try {
			Customer c = new Customer(FIRST, LAST, ID);
			assertEquals("first last (id)", c.toString());
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.Customer#compareTo(edu.ncsu.csc216.hloj.model.Customer)}.
	 */
	@Test
	public void testCompareTo() {
		try {
			Customer c1 = new Customer(FIRST, LAST, ID);
			Customer c2 = new Customer(FIRST, LAST, ID);
			Customer c3 = new Customer(LAST, LAST, ID);
			Customer c4 = new Customer(FIRST, LAST, FIRST);
			Customer c5 = new Customer(FIRST, FIRST, FIRST);
			Customer c6 = new Customer(FIRST, FIRST, ID);
			assertEquals(0, c1.compareTo(c2));
			assertEquals(-1, c1.compareTo(c3));
			assertEquals(0, c1.compareTo(c4));
			assertEquals(1, c3.compareTo(c1));
			assertEquals(1, c3.compareTo(c4));
			assertEquals(0, c5.compareTo(c6));
			assertEquals(0, c6.compareTo(c5));
			assertEquals(1, c4.compareTo(c5));
			assertEquals(-1, c5.compareTo(c4));
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

}
