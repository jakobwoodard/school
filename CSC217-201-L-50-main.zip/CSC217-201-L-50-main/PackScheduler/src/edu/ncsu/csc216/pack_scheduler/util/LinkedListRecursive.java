/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;


/**
 * Custom implementation of a linked recursive list to be used to create faculty schedules
 * @author Jakob Woodard
 * @param <E> the generic type that a list can hold
 *
 */
public class LinkedListRecursive<E> {
	
	/** The size of the list */
	private int size;
	/** The first Node in the list */
	private ListNode front;
	
	/**
	 * Constructor for a recursive linked list. Sets the front node to null and the size to 0.
	 */
	public LinkedListRecursive() {
		front = null;
		this.size = 0;
	}
	
	/**
	 * Method to get the size of a list
	 * @return size of the list
	 */
	public int size() {
		return size;
	}
	
	/**
	 * Method to see if a list is empty
	 * @return true if the list is empty
	 */
	public boolean isEmpty() {
		return size == 0;
	}
	
	/**
	 * Method to see if a list contains a given value
	 * @param data the value being sought
	 * @return true if the list contains the value
	 */
	public boolean contains(E data) {
		if (isEmpty()) {
			return false;
		}
		return front.contains(data);
		
	}
	
	/**
	 * Adds data to the list
	 * @param data the data to add to the list
	 * @return true if the data is added
	 */
	public boolean add(E data) {
		if (contains(data)) {
			throw new IllegalArgumentException("Duplicate element");
		}
		if (isEmpty()) {
			front = new ListNode(data, front);
			size++;
		}
		else {
			add(size(), data);
		}
		return contains(data);
		
	}
	
	/**
	 * Adds data to a specified index
	 * @param index index to be added at
	 * @param data data being added to the list
	 */
	public void add(int index, E data) {
		if (contains(data)) {
			throw new IllegalArgumentException("Duplicate element");
		}
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		if (data == null) {
			throw new NullPointerException("Null element");
		}
		if (index == 0) {
			front = new ListNode(data, front);
			size++;
		}
		else {
			front.add(index, data);
		}
		
		
	}
	
	/**
	 * Gets the data of the list node at the specified index
	 * @param index the index of the list node
	 * @return the value at the given index
	 */
	public E get(int index) {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		return front.get(index);
	}
	
	/**
	 * Removes data from a list and returns true
	 * @param data data to remove
	 * @return true if the data is removed
	 */
	public boolean remove(E data) {
		if (data == null) {
			return false;
		}
		if (isEmpty()) {
			return false;
		}
		if (front.data.equals(data)) {
			front = front.next;
			size--;
			return true;
		}
		else {
			return front.remove(data);
		}
	}
	
	/**
	 * Removes the data at a given index
	 * @param index the index being removed at
	 * @return the value being removed
	 */
	public E remove(int index) {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		if (index == 0) {
			ListNode temp = front;
			if (front.next != null) {
				front = front.next;
				size--;
				return temp.data;
			}
			else {
				front = null;
				size--;
				return temp.data;
			}
			
		}
		else {
			front.remove(index);
		}
		return null;
		
	}
	
	/**
	 * Sets the value at a given index to the given data
	 * @param index the index being set at
	 * @param data the data being set to
	 * @return the value of the previous set
	 */
	public E set(int index, E data) {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException("Invalid index");
		}
		else if (data == null) {
			throw new NullPointerException("Null element");
		}
		else if (contains(data)) {
			throw new IllegalArgumentException("Duplicate element");
		}
		else {
			return front.set(index, data);
		}
	}

	private class ListNode {
		
		/** The data of the list node */
		public E data;
		/** The next list node */
		public ListNode next;
		
		/**
		 * Constructor for a list node, sets the data and the next list node to the param.
		 * @param data the data being put into the list node
		 * @param next the next list node for  a list
		 */
		public ListNode(E data, ListNode next) {
			this.data = data;
			this.next = next;
		}
		
		/** 
		 * Adds a value to the list node at a given index
		 * @param index the index of the value
		 * @param data the value being added
		 */
		public void add(int index, E data) {
			if (index == 1) {
				next = new ListNode(data, next);
				size++;
			}
			else {
				next.add(index - 1, data);
			}
		}
		
		/**
		 * Getter for a specific ListNode's data
		 * @param index the index of the list node
		 * @return the desired list node
		 */
		public E get(int index) {
			if (index == 0) {
				return data;
			}
			else if (next != null) {
				return next.get(index - 1);
			}
			else {
				return null;
			}
		}
		
		/**
		 * Helper method to remove a value at a given index
		 * @param index the index being removed at
		 * @return the element that was removed
		 */
		public E remove(int index) {
			if (index == 1) {
				ListNode temp = next;
				next = next.next;
				size--;
				return temp.data;
			}
			else {
				next.remove(index - 1);
			}
			return null;
		}
		
		/**
		 * Removes an element from a list node
		 * @param data the data being removed
		 * @return true if the data was removed
		 */
		public boolean remove(E data) {
			if (next.data.equals(data)) {
				next = next.next;
				size--;
				return true;
			}
			else {
				next.remove(data);
			}
			return false;
		}
		
		/**
		 * Sets the value at a given index to the given data
		 * @param index the index being set at
		 * @param data the data being set to
		 * @return the list node being set to
		 */
		public E set(int index, E data) {
			if (index == 0) {
				E temp = this.data;
				this.data = data;
				return temp;
			}
			else {
				return next.set(index - 1, data);
			}
		}
		
		/**
		 * Determines if a given element is in a list node
		 * @param data the data that is or is not contained
		 * @return true if the data is contained in the list node
		 */
		public boolean contains(E data) {
			if (this.data == null) {
				return false;
			}
			if (this.data == data) {
				return true;
			}
			if (next != null) {
				return next.contains(data);
			}
			return false;
		}
		
		
	}
}
