package edu.ncsu.csc216.pack_scheduler.user;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.course.Course;
/**
 * Tests the Student class.
 * 
 * Tests for getters are omitted.
 * @author Jakob Wodoard
 * 
 *
 */
public class StudentTest {
	/** Student first name */
	private static final String FIRST = "first";
	/** Student last name */
	private static final String LAST = "last";
	/** Student id */
	private static final String ID = "flast";
	/** Student email */
	private static final String EMAIL = "flast@ncsu.edu";
	/** Student password */
	private static final String PASSWORD = "password";
	/** Max credits for class */
	private static final int CREDITS = 15;
	/**
	 * Tests that hashCode() works correctly.
	 */
	@Test
	public void testHashCode() {
		Student s1 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s2 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s3 = new Student(FIRST, "Different", ID, EMAIL, PASSWORD, CREDITS);
		Student s4 = new Student(FIRST, LAST, "Different", EMAIL, PASSWORD, CREDITS);
		Student s5 = new Student(FIRST, LAST, ID, "different@ncsu.edu", PASSWORD, CREDITS);
		Student s6 = new Student(FIRST, LAST, ID, EMAIL, "Different", CREDITS);
		Student s7 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, 3);
		
		// Tests for the same hash code for the same values
		assertEquals(s1.hashCode(), s2.hashCode());
		
		// Test for each of the fields
		assertNotEquals(s1.hashCode(), s3.hashCode());
		assertNotEquals(s1.hashCode(), s4.hashCode());
		assertNotEquals(s1.hashCode(), s5.hashCode());
		assertNotEquals(s1.hashCode(), s6.hashCode());
		assertNotEquals(s1.hashCode(), s7.hashCode());
	}
	
	/**
	 * Tests the Student constructor with all field parameters.
	 */
	@Test
	public void testStudentStringStringStringStringStringInt() {
		Student s = null;
		try {
			s = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());		
		}
		catch (IllegalArgumentException e) {
			fail(e.getMessage());
		}
	}
	/**
	 * Tests equalsObject() works for all Student fields.
	 */
	@Test
	public void testEqualsObject() {
		Student s1 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s2 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		Student s3 = new Student(FIRST, "Different", ID, EMAIL, PASSWORD, CREDITS);
		Student s4 = new Student(FIRST, LAST, "Different", EMAIL, PASSWORD, CREDITS);
		Student s5 = new Student(FIRST, LAST, ID, "different@ncsu.edu", PASSWORD, CREDITS);
		Student s6 = new Student(FIRST, LAST, ID, EMAIL, "Different", CREDITS);
		Student s7 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, 3);
		
		// Test for equality in both directions
		assertTrue(s1.equals(s2));
		assertTrue(s2.equals(s1));
		
		// Test for each of the fields
		assertFalse(s1.equals(s3));
		assertFalse(s1.equals(s4));
		assertFalse(s1.equals(s5));
		assertFalse(s1.equals(s6));
		assertFalse(s1.equals(s7));
		
	}
	/**
	 * Tests the Student constructor with 5 parameters.
	 */
	@Test
	public void testStudentStringStringStringStringString() {
		Student s = null;
		try {
			s = new Student(FIRST, LAST, ID, EMAIL, PASSWORD);
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(18, s.getMaxCredits());
		}
		catch (IllegalArgumentException e) {
			fail();
		}
	}
	/**
	 * Tests setEmail().
	 */
	@Test
	public void testSetEmail() {
		Student s = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		assertEquals(FIRST, s.getFirstName());
		assertEquals(LAST, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(PASSWORD, s.getPassword());
		assertEquals(CREDITS, s.getMaxCredits());
		
		// Tests that setting the email to null doesn't change the email (or anything
		// else.)
		try {
			s.setEmail(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid email", e.getMessage());
		}
		
		// Tests that setting the email to "" doesn't change the email (or anything
		// else.)
		
		try {
			s.setEmail("");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid email", e.getMessage());
		}
		
		// Tests that setting the email to "flast@ncsuedu" doesn't change the email (or
		// anything else.)
		
		try {
			s.setEmail("flast@ncsuedu");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid email", e.getMessage());
		}
		
		// Tests that setting the email to "flastncsu.edu" doesn't change the email (or
		// anything else.)
		
		try {
			s.setEmail("flastncsu.edu");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid email", e.getMessage());
		}
		
		// Tests that setting the email to "f.last@ncsuedu" doesn't change the email (or
		// anything else.)
		
		try {
			s.setEmail("f.last@ncsuedu");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid email", e.getMessage());
		}
		
		// Tests that setting the email to "f.l.ast@ncsuedu" doesn't change the email (or
		// anything else.)
		
		try {
			s.setEmail("f.l.ast@ncsuedu");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid email", e.getMessage());
		}
		
		
		// Valid set
		s.setEmail("first.last@ncsu.edu");
		assertEquals(FIRST, s.getFirstName());
		assertEquals(LAST, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals("first.last@ncsu.edu", s.getEmail());
		assertEquals(PASSWORD, s.getPassword());
		assertEquals(CREDITS, s.getMaxCredits());
	}
	/**
	 * Tests setPassword().
	 */
	@Test
	public void testSetPassword() {
		Student s = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		assertEquals(FIRST, s.getFirstName());
		assertEquals(LAST, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(PASSWORD, s.getPassword());
		assertEquals(CREDITS, s.getMaxCredits());
		
		// Tests to see if setting the password to null doesn't change the password 
		// (or anything else.)
		
		try {
			s.setPassword(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid password", e.getMessage());
		}
		
		// Tests to see if setting the password to "" doesn't change the password
		// (or anything else.)
		
		try {
			s.setPassword("");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid password", e.getMessage());
		}
		
		// Valid set
		s.setPassword("123");
		assertEquals(FIRST, s.getFirstName());
		assertEquals(LAST, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals("123", s.getPassword());
		assertEquals(CREDITS, s.getMaxCredits());
	}
	/**
	 * Tests setMaxCredits().
	 */
	@Test
	public void testSetMaxCredits() {
		Student s = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		assertEquals(FIRST, s.getFirstName());
		assertEquals(LAST, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(PASSWORD, s.getPassword());
		assertEquals(CREDITS, s.getMaxCredits());
		
		// Tests that setting the max credits to below 3 doesn't change the credits
		// (or anything else.)
		
		try {
			s.setMaxCredits(2);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid max credits", e.getMessage());
		}
		
		// Test that setting the max credits to above 18 doesn't change the credits
		// (or anyting else.)
		
		try {
			s.setMaxCredits(19);
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid max credits", e.getMessage());
		}
		
		// Valid set
		
		s.setMaxCredits(15);
		assertEquals(FIRST, s.getFirstName());
		assertEquals(LAST, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(PASSWORD, s.getPassword());
		assertEquals(15, s.getMaxCredits());
		
	}
	/**
	 * Test setFirstName().
	 */
	@Test
	public void testSetFirstName() {
		Student s = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		assertEquals(FIRST, s.getFirstName());
		assertEquals(LAST, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(PASSWORD, s.getPassword());
		assertEquals(CREDITS, s.getMaxCredits());
		
		// Tests that setting first name to null doens't change the first name (or
		// anything else.)
		
		try {
			s.setFirstName(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid first name", e.getMessage());
		}
		
		// Tests that setting first name to "" doesn't change the first name (or
		// anything else.)
		
		try {
			s.setFirstName("");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid first name", e.getMessage());
		}
		
		// Valid set
		
		s.setFirstName("newfirst");
		assertEquals("newfirst", s.getFirstName());
		assertEquals(LAST, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(PASSWORD, s.getPassword());
		assertEquals(CREDITS, s.getMaxCredits());
	}
	/**
	 * Tests setLastName().
	 */
	@Test
	public void testSetLastName() {
		Student s = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		assertEquals(FIRST, s.getFirstName());
		assertEquals(LAST, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(PASSWORD, s.getPassword());
		assertEquals(CREDITS, s.getMaxCredits());
		
		// Tests that setting last name to null doens't change the last name (or
		// anything else.)
		
		try {
			s.setLastName(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid last name", e.getMessage());
		}
		
		// Tests that setting last name to "" doesn't change the last name (or
		// anything else.)
		
		try {
			s.setLastName("");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(FIRST, s.getFirstName());
			assertEquals(LAST, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(CREDITS, s.getMaxCredits());
			assertEquals("Invalid last name", e.getMessage());
		}
		
		// Valid set
		
		s.setLastName("newlast");
		assertEquals(FIRST, s.getFirstName());
		assertEquals("newlast", s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(PASSWORD, s.getPassword());
		assertEquals(CREDITS, s.getMaxCredits());
	}
	/**
	 * Tests that toString returns the correct comma-separated value.
	 */
	@Test
	public void testToString() {
		Student s1 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS);
		String st1 = "first,last,flast,flast@ncsu.edu,password,15";
		assertEquals(st1, s1.toString());
		
		Student s2 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD);
		String st2 = "first,last,flast,flast@ncsu.edu,password,18";
		assertEquals(st2, s2.toString());
	}
	/**
	 * Tests the compareTo() method which compares 2 student strings to see in which order they should appear in by creating 5 students, 2 being equal. The unequal students
	 * are then compared to see which should come "first" when being sorted.
	 */
	@Test
	public void testCompareTo() {
		Student s1 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS); //Same as s2
		Student s2 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, CREDITS); //Same as s1
		Student s3 = new Student("girst", LAST, ID, EMAIL, PASSWORD, CREDITS); //First name is "greater" than s1/s2
		Student s4 = new Student(FIRST, "mast", ID, EMAIL, PASSWORD, CREDITS); //Last name is "greater" than s1/s2
		Student s5 = new Student(FIRST, LAST, "glast", EMAIL, PASSWORD, CREDITS); //ID is "greater" than s1/s2
		
		//Testing equal students
		assertEquals(0, s1.compareTo(s2));
		
		//Testing first name less than compared student
		assertEquals(-1, s1.compareTo(s3));
		
		//Testing last name less than compared student
		assertEquals(-1, s1.compareTo(s4));
		
		//Testing id less than compared student
		assertEquals(-1, s1.compareTo(s5));
		
		//Testing first name greater than compared student
		assertEquals(1, s3.compareTo(s1));
				
		//Testing last name greater than compared student
		assertEquals(1, s4.compareTo(s1));
				
		//Testing id greater than compared student
		assertEquals(1, s5.compareTo(s1));
	}
	
	/**
	 * Tests the canAdd() method in Student. Similar to canAdd() in Schedule with the added instance in which the max credits would 
	 * be above the students max credits
	 */
	@Test
	public void testCanAdd() {
		Student s1 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, 3);
		
		Course c1 = new Course("CSC116", "Intro to Java", "001", 3, "flast", 10, "MWF", 100, 400);
		Course c2 = new Course("CSC116", "Intro to Java", "002", 3, "flast", 10, "MWF", 500, 800);
		Course c3 = new Course("CSC216", "Java", "001", 5, "flast", 10, "MWF", 900, 1200);
		Course c4 = new Course("CSC217", "Java Lab", "001", 3, "flast", 10, "MWF", 900, 1200);
		
		s1.getSchedule().addCourseToSchedule(c1);
		assertFalse(s1.canAdd(c3));
		
		Student s2 = new Student(FIRST, LAST, ID, EMAIL, PASSWORD, 6);
		s2.getSchedule().addCourseToSchedule(c1);
		s2.getSchedule().addCourseToSchedule(c3);
		
		assertFalse(s2.canAdd(c2));		
		assertFalse(s2.canAdd(c4));
	}

}
