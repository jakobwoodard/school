package edu.ncsu.csc216.project_manager.model.manager;

import java.util.ArrayList;

import edu.ncsu.csc216.project_manager.model.command.Command;
import edu.ncsu.csc216.project_manager.model.user_story.UserStory;

/**
 * This class gives a holds a project's name and maintains a List of UserStorys
 * @author Jakob Woodard
 *
 */
public class Project {
	/** Name of the project */
	private String projectName;
	/** ArrayList to hold user stories */
	private ArrayList<UserStory> stories;
	
	/**
	 * Constructor class for a project. If the name is empty or null, an IAE is thrown
	 * @param name of the project
	 * @throws IllegalArgumentException if the name is null or empty
	 */
	public Project(String name) {
		setProjectName(name);
		this.stories = new ArrayList<UserStory>();
		UserStory.setCounter(0);
	}
	
	/**
	 * Sets the counter for the UserStory instances to the max value in the list of UserStorys plus 1
	 */
	public void setUserStoryId() {
		int count = 0;
		for (int i = 0; i <= stories.size() - 1; i++) {
			if (stories.get(i).getId() > count) {
				UserStory.setCounter(stories.get(i).getId() + 1);
			}
		}
	}
	
	/**
	 * Sets the name of the project
	 * @param name of the project
	 * @throws IllegalArgumentException if the name is null or empty
	 */
	private void setProjectName(String name) {
		if (name == null || "".equals(name)) {
			throw new IllegalArgumentException("Invalid name");
		}
		this.projectName = name;
	}
	
	/**
	 * Getter method for the project name
	 * @return projectName the name of the project
	 */
	public String getProjectName() {
		return projectName;
	}
	
	/**
	 * Creates a new UserStory and adds it to the list in sorted order, then returns the id. Throws an IAE if a story already exists with the given id
	 * @param title title of the story
	 * @param user of the story
	 * @param action to be done to the story statement
	 * @param value of the story statement
	 * @return id of the added story
	 * @throws IllegalArgumentException if a story already exists with the given id
	 */
	public int addUserStory(String title, String user, String action, String value) {
		UserStory us = new UserStory(title, user, action, value);
		addUserStory(us);
		return us.getId();
		
	}
	
	/**
	 * Adds the user story to the list in sorted order by id. An IAE is thrown if a story exists with the given id
	 * @param story the story to be added
	 * @throws IllegalArgumentException if a story already exists with the same id
	 */
	public void addUserStory(UserStory story) {
		for (int i = 0; i < stories.size(); i++) {
			if (story.getId() == stories.get(i).getId()) {
				throw new IllegalArgumentException("A story already exists with that id");
			}
		}
		//Adding in the middle, can only happen with 2 or more elements
		if (stories.size() >= 2) {
			for (int j = 2; j < stories.size(); j++) {
				if (story.getId() > stories.get(j - 1).getId() && story.getId() < stories.get(j).getId()) {
					stories.add(j, story);
				}
				//Adding at the end
				else if (story.getId() > stories.get(stories.size() - 1).getId()) {
					stories.add(stories.size(), story);
				}
				//Adding at the beginning
				else if (story.getId() < stories.get(0).getId()) {
					stories.add(0, story);
				}
			}
			if (story.getId() > stories.get(stories.size() - 1).getId()) {
				stories.add(stories.size(), story);
			}
		}
		//If the size is 1
		else if (stories.size() == 1) {
			//Adding at the end
			if (story.getId() > stories.get(stories.size() - 1).getId()) {
				stories.add(stories.size(), story);
			}
			//Adding at the beginning
			if (story.getId() < stories.get(0).getId()) {
				stories.add(0, story);
			}
		}
		//If the size is 0, just add the element at index 0
		else {
			stories.add(0, story);
		}



		

	}
	
	/**
	 * Getter for the list of user stories
	 * @return stories the list of user stories
	 */
	public ArrayList<UserStory> getUserStories() {
		return stories;
		
	}
	
	/**
	 * Gets the UserStory in the list with the given id. if there is no such UserStory, null is returned
	 * @param id of the wanted story
	 * @return the id of the story or null if no story is found
	 */
	public UserStory getUserStoryById(int id) {
		for (int i = 0; i < stories.size(); i++) {
			if (stories.get(i).getId() == id) {
				return stories.get(i);
			}
		}
		return null;
		
	}
	
	/**
	 * Removes the UserStory in the list with the given id.
	 * @param id of the story to be removed
	 */
	public void deleteUserStoryById(int id) {
		for (int i = 0; i < stories.size(); i++) {
			if (stories.get(i).getId() == id) {
				stories.remove(i);
			}
		}
	}
	
	/**
	 * Finds the UserStory with the given id and updates it by passing the given Command
	 * @param id of story being updated
	 * @param c command that is being executed on the specified id
	 */
	public void executeCommand(int id, Command c) {
		for (int i = 0; i < stories.size(); i++) {
			if (stories.get(i).getId() == id) {
				stories.get(i).update(c);
			}
		}
	}
	
	
	

}
