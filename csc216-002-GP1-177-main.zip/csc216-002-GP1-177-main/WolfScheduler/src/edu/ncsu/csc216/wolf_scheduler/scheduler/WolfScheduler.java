package edu.ncsu.csc216.wolf_scheduler.scheduler;

import java.io.IOException;
import java.util.ArrayList;
import edu.ncsu.csc216.wolf_scheduler.course.Course;
import edu.ncsu.csc216.wolf_scheduler.io.CourseRecordIO;
/**
 * Compiling class for Course and CourseRecordIO. Creates an ArrayList of courses in a catalog
 * and allows for those courses to be added to a specified schedule in another ArrayList. The schedule can
 * also be modified in this class.
 * @author Jakob Woodard
 *
 */
public class WolfScheduler {
	
	/** title for the schedule */
	private String title;
	/** ArrayList of courses for schedule */
	private ArrayList<Course> schedule;
	/** ArrayList of courses in the catalog */
	private ArrayList<Course> catalog;

	/**
	 * Constructor for the WolfScheduler
	 * @param fileName name of file with courses
	 * @throws IllegalArgumentException if a file cannot be found
	 */
	public WolfScheduler(String fileName) {
		this.schedule = new ArrayList<Course>();
		this.title = "My Schedule";
		try {
			this.catalog = CourseRecordIO.readCourseRecords(fileName);
		}
		catch(Exception e) {
			throw new IllegalArgumentException("Cannot find file");
		}
		
	}
	/**
	 * Getter method for the course catalog returns empty if the catalog is empty
	 * @return courses a 2D array of courses with name, title, and section fields.
	 */
	public String[][] getCourseCatalog() {
		if (catalog.size() == 0) {
			String courses[][] = {};
			return courses;
		}
		String[][] courses = new String[catalog.size()][3];
		for (int i = 0; i < catalog.size(); i++) {
			String name = catalog.get(i).getName();
			String courseTitle = catalog.get(i).getTitle();
			String section = catalog.get(i).getSection();
			courses[i][0] = name;
			courses[i][1] = section;
			courses[i][2] = courseTitle;
		}
		
		return courses;
	}
	/**
	 * Getter method for scheduled courses
	 * @return scheduledCourses array of scheduled courses
	 */
	public String[][] getScheduledCourses() {
		
		if (schedule.size() == 0) {
			String[][] scheduledCourses = {};
			return scheduledCourses;
		}
		String[][] scheduledCourses = new String[schedule.size()][3];
		for (int i = 0; i < schedule.size(); i++) {
			String name = schedule.get(i).getName();
			String courseTitle = schedule.get(i).getTitle();
			String section = schedule.get(i).getSection();
			scheduledCourses[i][0] = name;
			scheduledCourses[i][1] = section;
			scheduledCourses[i][2] = courseTitle;
		}
		return scheduledCourses;
	}
	/**
	 * Getter method for full schedule
	 * @return fullScheduledCourses a 2D array of all of the scheduled courses and their details
	 */
	public String[][] getFullScheduledCourses() {
		if (schedule.size() == 0) {
			String[][] fullScheduledCourses = {};
			return fullScheduledCourses;
		}
		String[][] fullScheduledCourses = new String[schedule.size()][6];
		for (int i = 0; i < schedule.size(); i++) {
			String name = schedule.get(i).getName();
			String section = schedule.get(i).getSection();
			String courseTitle = schedule.get(i).getTitle();
			int creditsInt = schedule.get(i).getCredits();
			String credits = Integer.toString(creditsInt);
			String instructorId = schedule.get(i).getInstructorId();
			String meetingDays = schedule.get(i).getMeetingString();
			fullScheduledCourses[i][0] = name;
			fullScheduledCourses[i][1] = section;
			fullScheduledCourses[i][2] = courseTitle;
			fullScheduledCourses[i][3] = credits;
			fullScheduledCourses[i][4] = instructorId;
			fullScheduledCourses[i][5] = meetingDays;
		}
		return fullScheduledCourses;
	}
	/**
	 * Getter for ScheduleTitle
	 * @return title of schedule
	 */
	public String getScheduleTitle() {
		return title;
	}
	/**
	 * Writes a schedule to a specified file name
	 * @param fileName name of the file to be written to
	 * @throws IllegalArgumentException if the file cannot be saved to.
	 */
	public void exportSchedule(String fileName) {
		try {
			CourseRecordIO.writeCourseRecords(fileName, schedule);
		}
		catch (IOException e) {
			throw new IllegalArgumentException("The file cannot be saved.");
		}
		
	}
	/**
	 * Getter for Course from catalog. Method searches the catalog for a course with the same
	 * section number and name, returning it when found. If no such course is found, method 
	 * returns null
	 * @param name name of course searching for
	 * @param section section of course searching for
	 * @return course that has said name/section or null
	 */
	public Course getCourseFromCatalog(String name, String section) {
		for (int i = 0; i < catalog.size(); i++) {
			if (catalog.get(i).getName().equals(name) && catalog.get(i).getSection().equals(section)) {
				Course wantedCourse = catalog.get(i);
				return wantedCourse;
			}
		}
		return null;
	}
	/**
	 * Boolean that returns true if a course is successfully added and false if not
	 * @param name name of desired course
	 * @param section section of desired course
	 * @return false if course is not added, true if added
	 */
	public boolean addCourseToSchedule(String name, String section) {
		if (getCourseFromCatalog(name, section) == null) {
			return false;
		}
		for (int i = 0; i < schedule.size(); i++) {
			if (name.equals(schedule.get(i).getName())){
				String repeatedName = schedule.get(i).getName();
				throw new IllegalArgumentException("You are already enrolled in " + repeatedName);
			}
		}
		Course newCourse = getCourseFromCatalog(name, section);
		schedule.add(newCourse);
		return true;
	}
	/**
	 * Boolean to see if a course is in a schedule and has been removed
	 * @param name the name of the course being removed
	 * @param section the section of the course being removed
	 * @return true if course is in schedule and was removed
	 */
	public boolean removeCourseFromSchedule(String name, String section) {
		for (int i = 0; i < schedule.size(); i++) {
			if (name.equals(schedule.get(i).getName()) && section.equals(schedule.get(i).getSection())){
				schedule.remove(i);
				return true;
			}
		}
		return false;
	}
	/**
	 * Resets the schedule to an empty ArrayList
	 */
	public void resetSchedule() {
		this.schedule = new ArrayList<Course>();
		
	}
	/**
	 * Setter method for schedule title
	 * @param title new title of the schedule
	 */
	public void setScheduleTitle(String title) {
		if (title == null) {
			throw new IllegalArgumentException("Title cannot be null.");
		}
		this.title = title;
		
	}

}
