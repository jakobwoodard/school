/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.NoSuchElementException;

/**
 * Queue in the form of a LinkedList to be used as a wait list for students in a course
 * @author Jakob Woodard
 * @param <E> generic type being held in the queue
 *
 */
public class LinkedQueue<E> implements Queue<E> {
	
	/** LinkedAbstractList to be used as a queue */
	private LinkedAbstractList<E> list;
	/** Capacity of the list */
	private int capacity;

	/**
	 * Constructor for a LinkedQueue. Creates an empty LinkedAbstractList with the passed capacity and sets the capacity equal
	 * to the passed parameter.
	 * @param capacity of the queue.
	 */
	public LinkedQueue(int capacity) {
		list = new LinkedAbstractList<E>(capacity);
		setCapacity(capacity);
	}
	
	/**
	 * Adds the element to the back of the Queue. If there is no room (capacity has been reached), 
	 * an IllegalArgumentException is thrown
	 * @param element the element to be added
	 * @throws IllegalArgumentException if the queue is full
	 */
	@Override
	public void enqueue(E element) throws IllegalArgumentException {
		if (capacity == size()) {
			throw new IllegalArgumentException("Queue is full");
		}
		list.add(size(), element);
	}

	/**
	 * Removes and returns the element at the front of the Queue. If the Queue is empty, an NoSuchElementException is thrown
	 * @return value the value being removed
	 * @throws NoSuchElementException if there is no element to be removed
	 */
	@Override
	public E dequeue() throws NoSuchElementException {
		if (list.isEmpty()) {
			throw new NoSuchElementException("No element in queue");
		}
		else {
			E value = list.get(0);
			list.remove(0);
			return value;
		}
	}

	/**
	 * Checks if the Queue is empty
	 * @return true if the queue is empty
	 */
	@Override
	public boolean isEmpty() {
		return list.isEmpty();
	}

	/**
	 * Checks the number of elements in the queue
	 * @return the amount of elements in the queue.
	 */
	@Override
	public int size() {
		return list.size();
	}

	/**
	 * Sets the Queue�s capacity. If the actual parameter is negative or if it is less than the number of 
	 * elements in the Queue, an 1IllegalArgumentException is thrown
	 * @param capacity the desired capacity
	 * @throws IllegalArgumentException if the capacity is negative or less than the number of elements currently in the queue.
	 */
	@Override
	public void setCapacity(int capacity) throws IllegalArgumentException {
		if (capacity < 0 || capacity < size()) {
			throw new IllegalArgumentException("Invalid capacity");
		}
		this.capacity = capacity;
	}

}
