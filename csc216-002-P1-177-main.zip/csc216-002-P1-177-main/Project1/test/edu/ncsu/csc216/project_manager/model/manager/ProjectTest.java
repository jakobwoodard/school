package edu.ncsu.csc216.project_manager.model.manager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import org.junit.Test;

import edu.ncsu.csc216.project_manager.model.command.Command;
import edu.ncsu.csc216.project_manager.model.user_story.UserStory;
/**
 * Tests for the Project class
 * @author Jakob Woodard
 *
 */
public class ProjectTest {
	/** Example of a story title */
	private final String title = "title";
	/** Example of a story user */
	private final String user = "user";
	/** Example of a story action */
	private final String action = "action";
	/** Example of a story value */
	private final String value = "value";
	/** Valid story priority */
	private final String priority3 = "Low";
	/** Example of dev id for story */
	private final String developerId = "id";
	/** Valid story priority */
	private final String priority = "High";

	/**
	 * Tests properly creating a project object
	 */
	@Test
	public void testProject() {
		//Invalid tests
		//Project name empty
		try {
			new Project("");
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid name", e.getMessage());
		}
		//Project name null
		try {
			new Project(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Invalid name", e.getMessage());
		}
		
		//Valid tests
		Project p = new Project("Project");
		assertEquals("Project", p.getProjectName());
		
		//Invalid name sets

	}
	/**
	 * Tests setting the UserStoryId
	 */
	@Test
	public void testSetUserStoryId() {
		//Creating Project to add stories to
		Project p = new Project("Project");
		//Creating UserStories to be added to the list
		UserStory s1 = new UserStory(title, user, action, value);
		UserStory b1 = new UserStory(1, "Backlog", title, user, action, value, priority, null, null);
		UserStory w1 = new UserStory(2, "Working", title, user, action, value, priority, developerId, null);
		UserStory v1 = new UserStory(3, "Verifying", title, user, action, value, priority3, developerId, null);
		UserStory c1 = new UserStory(4, "Completed", title, user, action, value, priority, developerId, null);
		
		p.addUserStory(s1);
		p.addUserStory(b1);
		p.addUserStory(w1);
		p.addUserStory(v1);
		p.addUserStory(c1);
		
		assertEquals(s1, p.getUserStoryById(0));
		assertEquals(b1, p.getUserStoryById(1));
		assertEquals(w1, p.getUserStoryById(2));
		assertEquals(v1, p.getUserStoryById(3));
		assertEquals(c1, p.getUserStoryById(4));
		
		
		
	}
	/**
	 * Tests the addUserStory when the input is a UserStory
	 */
	@Test
	public void testAddUserStoryUserStory() {
		//Creating Project to add stories to
		Project p = new Project("Project");
		//Creating UserStories to be added to the list
		UserStory s1 = new UserStory(1, "Submitted", title, user, action, value, null, null, null);
		UserStory s2 = new UserStory(0, "Submitted", title, user, action, value, null, null, null);
		UserStory b1 = new UserStory(2, "Backlog", title, user, action, value, priority, null, null);
		UserStory w1 = new UserStory(3, "Working", title, user, action, value, priority, developerId, null);
		UserStory v1 = new UserStory(4, "Verifying", title, user, action, value, priority3, developerId, null);
		UserStory c1 = new UserStory(5, "Completed", title, user, action, value, priority, developerId, null);
		UserStory c2 = new UserStory(7, "Completed", title, user, action, value, priority, developerId, null);
		UserStory c3 = new UserStory(6, "Completed", title, user, action, value, priority, developerId, null);
		
		
		p.addUserStory(s1);
		assertEquals(1, s1.getId());
		assertEquals(1, p.getUserStories().size());
		assertEquals(s1, p.getUserStoryById(1));
		
		p.addUserStory(b1);
		assertEquals(2, b1.getId());
		assertEquals(2, p.getUserStories().size());
		assertEquals(b1, p.getUserStoryById(2));
		
		p.addUserStory(w1);
		assertEquals(3, w1.getId());
		assertEquals(3, p.getUserStories().size());
		assertEquals(w1, p.getUserStoryById(3));
		
		p.addUserStory(v1);
		assertEquals(4, v1.getId());
		assertEquals(4, p.getUserStories().size());
		assertEquals(v1, p.getUserStoryById(4));
		
		p.addUserStory(c1);
		assertEquals(5, c1.getId());
		assertEquals(5, p.getUserStories().size());
		assertEquals(c1, p.getUserStoryById(5));
		
		//Adding IDs not in order
		p.addUserStory(c2);
		assertEquals(7, c2.getId());
		assertEquals(6, p.getUserStories().size());
		assertEquals(c2, p.getUserStoryById(7));
		
		//New Project for simplicity
		Project p2 = new Project("Project2");
		
		p2.addUserStory(c3);
		assertEquals(6, c3.getId());
		assertEquals(1, p2.getUserStories().size());
		
		//Adding to the beginning
		p2.addUserStory(s1);
		assertEquals(1, s1.getId());
		assertEquals(2, p2.getUserStories().size());
		assertEquals(s1, p2.getUserStories().get(0));
		
		//Adding UserStory with already existing id
		try {
			p.addUserStory(c2);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("A story already exists with that id", e.getMessage());
			assertEquals(6, p.getUserStories().size());
		}
		
		//Adding UserStory in the middle
		p.addUserStory(c3);
		assertEquals(6, c3.getId());
		assertEquals(7, p.getUserStories().size());
		assertEquals(c3, p.getUserStories().get(5));
		
		//Adding UserStory at the beginning
		p.addUserStory(s2);
		assertEquals(0, s2.getId());
		assertEquals(8, p.getUserStories().size());
		assertEquals(s2, p.getUserStories().get(0));
		

		
	}
	/**
	 * Tests the addUserStory method when the UserStory has 4 inputs
	 */
	@Test
	public void testAddUserStoryStringStringStringString() {
		//Creating Project to add stories to
		Project p = new Project("Project");
		
		assertEquals(0, p.addUserStory(title, user, action, value));
		
	}
	/**
	 * Tests the getUserStories method
	 */
	@Test
	public void testGetUserStories() {
		//This method has been tested heavily within other methods so not much extra testing is needed
		Project p = new Project("Project");
		UserStory s1 = new UserStory(1, "Submitted", title, user, action, value, null, null, null);
		UserStory s2 = new UserStory(0, "Submitted", title, user, action, value, null, null, null);
		
		p.addUserStory(s1);
		p.addUserStory(s2);
		assertEquals(2, p.getUserStories().size());
		assertNull(p.getUserStoryById(5));
		
	}
	/**
	 * Tests the deleteUserStoryById method
	 */
	@Test
	public void testDeleteUserStoryById() {
		//Creating Project to add stories to
		Project p = new Project("Project");
		//Creating UserStories to be added to the list
		UserStory s1 = new UserStory(1, "Submitted", title, user, action, value, null, null, null);
		UserStory s2 = new UserStory(0, "Submitted", title, user, action, value, null, null, null);
		UserStory b1 = new UserStory(2, "Backlog", title, user, action, value, priority, null, null);
		UserStory w1 = new UserStory(3, "Working", title, user, action, value, priority, developerId, null);

		
		p.addUserStory(s1);
		p.addUserStory(s2);
		p.addUserStory(b1);
		p.addUserStory(w1);
		assertEquals(4, p.getUserStories().size());
		
		p.deleteUserStoryById(3);
		assertEquals(3, p.getUserStories().size());
		
	}
	/**
	 * Tests the executeCommand method
	 */
	@Test
	public void testExecuteCommand() {
		//Creating Project to add stories to
		Project p = new Project("Project");
		//Creating UserStories to be added to the list
		UserStory s1 = new UserStory(1, "Submitted", title, user, action, value, null, null, null);
		UserStory s2 = new UserStory(0, "Submitted", title, user, action, value, null, null, null);
		UserStory b1 = new UserStory(2, "Backlog", title, user, action, value, priority, null, null);
		UserStory w1 = new UserStory(3, "Working", title, user, action, value, priority, developerId, null);
		//Command to be tested with
		Command c1 = new Command(Command.CommandValue.BACKLOG, priority);
		
		p.addUserStory(s1);
		p.addUserStory(s2);
		p.addUserStory(b1);
		p.addUserStory(w1);
		
		p.executeCommand(1, c1);
		assertEquals("Backlog", s1.getState());
		assertEquals(priority, s1.getPriority());
	}

}
