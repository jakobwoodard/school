/**
 * 
 */
package edu.ncsu.csc216.hloj.model.manager;

import edu.ncsu.csc216.hloj.model.MenuItem;
import edu.ncsu.csc216.hloj.model.ModelException;
import edu.ncsu.csc216.hloj.model.lists.SortedList;

/**
 * This singleton class maintains a sorted list of MenuItems
 * @author Jakob Woodard
 *
 */
public class MenuManager {
	
	/** Singleton instance of MenuManager */
	private static MenuManager instance;
	/** List of all menu items */
	private SortedList<MenuItem> menu;
	
	/**
	 * Private constructor for the MenuManager. Can only be constructed if the getInstance() method returns null.
	 */
	private MenuManager() {
		this.menu = new SortedList<MenuItem>();
	}
	
	/**
	 * Returns the instance of the MenuManager. If the instance is null, then a new MenuManager can be created through the 
	 * private constructor
	 * @return instance of the MenuManager
	 */
	public static MenuManager getInstance() {
		if (instance == null) {
			MenuManager.instance = new MenuManager();
		}
		return instance;
		
	}
	
	/**
	 * Adds a item to the Menu
	 * @param m the item to be added
	 */
	public void addMenuItem(MenuItem m) {
		menu.add(m);
	}
	
	/**
	 * Gets a 2D array of all items on the Menu
	 * @return menuItems all of the items on the menu
	 */
	public MenuItem[] getMenuItems() {
		
		MenuItem[] menuItems = new MenuItem[menu.size()];
		for (int i = 0; i < menu.size(); i++) {
			menuItems[i] = menu.get(i);
		}
		return menuItems;
		
	}
	
	/**
	 * Gets the menu item at a desired index
	 * @param index of the desired menu item
	 * @return the wanted menu item
	 */
	public MenuItem getMenuItem(int index) {
		return menu.get(index);
	}
	
	/**
	 * Removes a MenuItem at the desired index
	 * @param index of the MenuItem to be removed
	 * @throws ModelException if the MenuItem being removed is part of an open order
	 */
	public void removeMenuItem(int index) throws ModelException {
		MenuItem wanted = menu.get(index);
		for (int i = 0; i < OrderManager.getInstance().getOrders().length; i++) {
			for (int j = 0; j < OrderManager.getInstance().getOrders()[i].getItems().length; j++) {
				if (wanted.equals(OrderManager.getInstance().getOrders()[i].getItems()[j].getMenuItem())) {
					throw new ModelException("Cannot delete a menu item that is part of an open order");
				}
			}
		}
		menu.remove(index);
	}
	
	/**
	 * Receives a new instance of a MenuItem to replace the one stored at the given index. 
	 * Thanks to reference semantics, open orders should preserve the menu item as it was when the order was placed.
	 * @param index of the MenuItem being replaced
	 * @param m MenuItem replacing previous item
	 */
	public void editMenuItem(int index, MenuItem m) throws ModelException {
		menu.remove(index);
		addMenuItem(m);
	}
	
	/**
	 * Removes all MenuItems from the system by creating an empty Sorted List of Menu items
	 * Used for testing to reset the state of the MenuManager
	 */
	public void removeAllMenuItems() {
		menu = new SortedList<MenuItem>();
	}

}
