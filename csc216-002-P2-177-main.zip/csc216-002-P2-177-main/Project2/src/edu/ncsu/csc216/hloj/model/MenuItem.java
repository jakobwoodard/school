package edu.ncsu.csc216.hloj.model;

/**
 * This class will hold the name, type and price of a menu item. Leading and trailing whitespaces 
 * should be removed and strings cannot be empty.
 * @author Jakob Woodard
 *
 */
public class MenuItem implements Comparable<MenuItem> {
	
	/** Type of menu item */
	private String type;
	/** Name of the menu item */
	private String name;
	/** Price of the menu item */
	private double price;
	
	/**
	 * Constructor for a MenuItem that takes the type, name, and price of a desired MenuItem. Throws a ModelException if one of the
	 * setters used throws a ModelException
	 * @param type MenuItem type
	 * @param name MenuItem name
	 * @param price MenuItem price
	 * @throws ModelException if a ModelException is thrown by one of the setters used in construction.
	 */
	public MenuItem(String type, String name, double price) throws ModelException {
		setType(type);
		setName(name);
		setPrice(price);
	}

	/**
	 * Gets the type of the MenuItem
	 * @return type of the MenuItem
	 */
	public String getType() {
		return type;
	}

	/**
	 * Error checks and trims the passed type then sets it to the MenuItem's type
	 * @param type the type to set
	 * @throws ModelException if the string is empty or has only whitespace
	 */
	public void setType(String type) throws ModelException {
		String check = type.trim();
		if ("".equals(check)) {
			throw new ModelException("The type of the menu item cannot be empty");
		}
		this.type = check;
	}

	/**
	 * Gets the name of the MenuItem
	 * @return name of the MenuItem
	 */
	public String getName() {
		return name;
	}

	/**
	 * Error checks and trims the passed name then sets it to the MenuItem's name
	 * @param name the name to set
	 * @throws ModelException if the string is empty or has only whitespaces
	 */
	public void setName(String name) throws ModelException {
		String check = name.trim();
		if ("".equals(check)) {
			throw new ModelException("The name of the menu item cannot be empty");
		}
		this.name = check;
	}

	/**
	 * Gets the price of the menu item.
	 * @return price of the MenuItem
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * Error checks and trims the passed price then sets it to the MenuItem's price
	 * @param price the price to set
	 * @throws ModelException if the price is 0 or less
	 */
	public void setPrice(double price) throws ModelException {
		if (price <= 0) {
			throw new ModelException("The price of the menu item must be greater than zero");
		}
		this.price = price;
	}

	/**
	 * Creates the string object of the MenuItem's unique information to be used to render values into the GUI
	 */
	@Override
	public String toString() {
		return "(" + type + ") " + name + " - " + "$" + price;
	}
	
	/**
	 * Compares two MenuItems and returns -1 if the passed item is "less" than another, 1 if the passed item is "greater"
	 * than the other, or 0 if the two items are equal
	 * @param m new MenuItem being compared with
	 * @return -1, 0, or 1 depending on how the passed MenuItem compares to the one being constructed.
	 */
	@Override
	public int compareTo(MenuItem m) {
		//Setting return value to ensure statement coverage at the end 
		int returnValue = 100;
		//.this comes before compared
		if (this.getType().compareToIgnoreCase(m.getType()) < 0) {
			returnValue = -1;
		}
		//.this comes after compared
		if (this.getType().compareToIgnoreCase(m.getType()) > 0) {
			returnValue = 1;
		}
		if (this.getType().compareToIgnoreCase(m.getType()) == 0) {
			returnValue = 0;
		}
		return returnValue;
	}
	
	
	
}
