/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.user.schedule;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.course.Course;

/**
 * Test cases for the Schedule class
 * @author Jakob Woodard
 *
 */
public class ScheduleTest {

	/**
	 * Tests the constructor
	 */
	@Test
	public void testSchedule() {
		Schedule s = new Schedule();
		assertEquals("My Schedule", s.getTitle());
		assertEquals(0, s.getScheduledCourses().length);
	}
	/**
	 * Tests the addCourseToSchedule method
	 */
	@Test
	public void testAddCourseToSchedule() {
		Schedule s = new Schedule();
		
		Course c1 = new Course("CSC116", "Intro to Java", "001", 3, "flast", 10, "MWF", 100, 400);
		Course c2 = new Course("CSC116", "Intro to Java", "002", 3, "flast", 10, "MWF", 500, 800);
		Course c3 = new Course("CSC216", "Java", "001", 3, "flast", 10, "MWF", 900, 1200);
		Course c4 = new Course("CSC217", "Java Lab", "001", 3, "flast", 10, "MWF", 900, 1200);
		
		s.addCourseToSchedule(c1);
		s.addCourseToSchedule(c3);
		assertEquals(2, s.getScheduledCourses().length);
		
		//Adding same course, different section
		try {
			s.addCourseToSchedule(c2);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("You are already enrolled in " + c2.getName(), e.getMessage());
		}
		//Conflict
		try {
			s.addCourseToSchedule(c4);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("The course cannot be added due to a conflict.", e.getMessage());
		}
	}
	/**
	 * Test method for removeCourseFromSchedule method
	 */
	@Test
	public void testRemoveCourseFromSchedule() {
		Schedule s = new Schedule();
		
		Course c1 = new Course("CSC116", "Intro to Java", "001", 3, "flast", 10, "MWF", 100, 400);
		Course c2 = new Course("CSC116", "Intro to Java", "002", 3, "flast", 10, "MWF", 500, 800);
		Course c3 = new Course("CSC216", "Java", "001", 3, "flast", 10, "MWF", 900, 1200);
		
		s.addCourseToSchedule(c1);
		s.addCourseToSchedule(c3);
		assertEquals(2, s.getScheduledCourses().length);
		
		assertTrue(s.removeCourseFromSchedule(c1));
		assertEquals(1, s.getScheduledCourses().length);
		
		//Course that isn't in the schedule
		assertFalse(s.removeCourseFromSchedule(c2));
	}
	/**
	 * Tests the resetSchedule method
	 */
	@Test
	public void testResetSchedule() {
		Schedule s = new Schedule();
		
		Course c1 = new Course("CSC116", "Intro to Java", "001", 3, "flast", 10, "MWF", 100, 400);
		Course c3 = new Course("CSC216", "Java", "001", 3, "flast", 10, "MWF", 900, 1200);
		
		s.addCourseToSchedule(c1);
		s.addCourseToSchedule(c3);
		
		s.resetSchedule();
		assertEquals("My Schedule", s.getTitle());
		assertEquals(0, s.getScheduledCourses().length);
		
	}
	/**
	 * Tests the setTitle method
	 */
	@Test
	public void testSetTitle() {
		Schedule s = new Schedule();
		
		s.setTitle("New Title");
		assertEquals("New Title", s.getTitle());
		
		try {
			s.setTitle(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals("Title cannot be null.", e.getMessage());
		}
	}
	
	/**
	 * Tests the getScheduledCredits method, making sure that the total hours for all scheduled courses are correct.
	 */
	@Test
	public void testGetScheduledCredits() {
		Schedule s = new Schedule();
		
		Course c1 = new Course("CSC116", "Intro to Java", "001", 3, "flast", 10, "MWF", 100, 400);
		Course c3 = new Course("CSC216", "Java", "001", 3, "flast", 10, "MWF", 900, 1200);
		
		s.addCourseToSchedule(c1);
		s.addCourseToSchedule(c3);
		
		assertEquals(6, s.getScheduleCredits());
	}
	
	/**
	 * Tests the canAdd() method to ensure that no class can be added improperly
	 */
	@Test
	public void testCanAdd() {
		Schedule s = new Schedule();
		
		Course c1 = new Course("CSC116", "Intro to Java", "001", 3, "flast", 10, "MWF", 100, 400);
		Course c2 = new Course("CSC116", "Intro to Java", "002", 3, "flast", 10, "MWF", 500, 800);
		Course c3 = new Course("CSC216", "Java", "001", 3, "flast", 10, "MWF", 900, 1200);
		Course c4 = new Course("CSC217", "Java Lab", "001", 3, "flast", 10, "MWF", 900, 1200);
		
		s.addCourseToSchedule(c1);
		assertTrue(s.canAdd(c3));
		s.addCourseToSchedule(c3);
		
		assertFalse(s.canAdd(c2));
		assertFalse(s.canAdd(c4));
		assertFalse(s.canAdd(null));
	}
	
	

}
