/**
 * 
 */
package edu.ncsu.csc216.hloj.model.manager;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.hloj.model.Customer;
import edu.ncsu.csc216.hloj.model.MenuItem;
import edu.ncsu.csc216.hloj.model.ModelException;
import edu.ncsu.csc216.hloj.model.Order;

/**
 * Test cases for OrderManager
 * @author Jakob Woodard
 *
 */
public class OrderManagerTest {

	
	/**
	 * Resets the OrderManager for future tests
	 */
	@Before
	public void resetManager() {
		OrderManager.getInstance().removeAllOrders();
		CustomerManager.getInstance().removeAllCustomers();
		MenuManager.getInstance().removeAllMenuItems();
		OrderManager.getInstance().setLastOrderNumber(0);
	}
	
	/**
	 * Test method for OrderManager()
	 */
	@Test
	public void testOrderManager() {
		OrderManager om = OrderManager.getInstance();
		
		assertEquals(0, om.getOrders().length);
		assertEquals(0, om.getLastOrderNumber());
		
		om.setLastOrderNumber(1);
		assertEquals(1, om.getLastOrderNumber());
	}
	

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.manager.OrderManager#placeOrder(edu.ncsu.csc216.hloj.model.Order)}.
	 */
	@Test
	public void testPlaceOrder() {
		OrderManager om = OrderManager.getInstance();
		try {
			//Creating Customers, orders, and menuitems
			Customer c = new Customer("first", "last", "flast");
			Order o = om.getNextOrder(c);
			Order o2 = new Order(1, c);
			MenuItem m = new MenuItem("Coffee", "Mocha", 1.5);
			MenuItem m2 = new MenuItem("Coffee", "Black", 1.5);
			
			//Trying empty order
			try {
				om.placeOrder(o2);
				fail();
			}
			catch (ModelException e) {
				assertEquals("Orders can only be placed if they contain at least one item", e.getMessage());
			}
			
			//Placing a valid order
			o2.addMenuItem(m2);
			o.addMenuItem(m);
			om.placeOrder(o);
			assertEquals(1, om.getLastOrderNumber());
			assertEquals(1, om.getOrders().length);
			
			//Trying to place an order with the same order number
			try {
				om.placeOrder(o2);
				fail();
			}
			catch (ModelException e) {
				assertEquals("An order with this number already exists", e.getMessage());
			}
			
		} catch (ModelException e) {
			fail("Unexpected ModelException");
		}
		
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.manager.OrderManager#cancelOrder(edu.ncsu.csc216.hloj.model.Order)}.
	 */
	@Test
	public void testCancelOrder() {
		OrderManager om = OrderManager.getInstance();
		try {
			//Creating Customers, orders, and menuitems
			Customer c = new Customer("first", "last", "flast");
			Order o = om.getNextOrder(c);
			Order o2 = new Order(1, c);
			MenuItem m = new MenuItem("Coffee", "Mocha", 1.5);
			MenuItem m2 = new MenuItem("Coffee", "Black", 1.5);
			
			
			//Placing a valid order
			o2.addMenuItem(m2);
			o.addMenuItem(m);
			om.placeOrder(o);
			assertEquals(1, om.getOrders().length);
			assertEquals(1, om.getOrders()[0].getNumber());
			assertEquals(1, om.getLastOrderNumber());
			
			om.cancelOrder(o);
			assertEquals(0, om.getOrders().length);
			
			try {
				om.cancelOrder(o2);
				fail();
			}
			catch (ModelException e) {
				assertEquals("Order does not exist", e.getMessage());
			}
			
		} catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.manager.OrderManager#fulfillOrder(edu.ncsu.csc216.hloj.model.Order)}.
	 */
	@Test
	public void testFulfillOrder() {
		OrderManager om = OrderManager.getInstance();
		try {
			//Creating Customers, orders, and menuitems
			Customer c = new Customer("first", "last", "flast");
			Order o = om.getNextOrder(c);
			Order o2 = new Order(2, c);
			MenuItem m = new MenuItem("Coffee", "Mocha", 1.5);
			MenuItem m2 = new MenuItem("Coffee", "Black", 1.5);
			
			
			//Placing a valid order
			o2.addMenuItem(m2);
			o.addMenuItem(m);
			om.placeOrder(o);
			om.placeOrder(o2);
			assertEquals(o, om.getOrder(0));
			assertEquals(o2, om.getOrder(1));
			
			//Making sure last order number hasn't changed since the order hasn't been fulfilled/cancelled
			assertEquals(1, om.getLastOrderNumber());
			assertEquals(2, om.getOrders().length);
			
			//Fulfilling orders in the wrong order
			try {
				om.fulfillOrder(o2);
				fail();
			}
			catch (ModelException e) {
				assertEquals("Orders must be fulfilled in the order in which they were placed", e.getMessage());
			}
			
			om.fulfillOrder(o);
			assertEquals(o2, om.getNextOrder(c));
			om.getNextOrder(c);
			assertEquals(2, om.getLastOrderNumber());
			
		} catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}
	
	/**
	 * Tests for getNextOrder() invalid cases
	 */
	@Test
	public void testGetNextOrder() {
		OrderManager om = OrderManager.getInstance();
		try {
			//Creating Customers, orders, and menuitems
			Customer c = new Customer("first", "last", "flast");
			Order o = om.getNextOrder(c);
			Order o2 = new Order(2, c);
			Order o3 = new Order(3, c);
			Order o4 = new Order(4, c);
			MenuItem m = new MenuItem("Coffee", "Mocha", 1.5);
			MenuItem m2 = new MenuItem("Coffee", "Black", 1.5);
			MenuItem m3 = new MenuItem("Pastery", "Muffin", 2.0);
			
			
			//Placing a valid order
			o.addMenuItem(m);
			o2.addMenuItem(m2);
			o3.addMenuItem(m3);
			o4.addMenuItem(m);
			om.placeOrder(o);
			om.placeOrder(o2);
			assertEquals(o, om.getOrder(0));
			assertEquals(o2, om.getOrder(1));
			
			//Making sure last order number hasn't changed since the order hasn't been fulfilled/cancelled
			assertEquals(1, om.getLastOrderNumber());
			assertEquals(2, om.getOrders().length);
			
			om.placeOrder(o3);
			assertEquals(3, om.getOrdersByCustomer(c).length);
			try {
				om.getNextOrder(c);
				fail();
			}
			catch (ModelException e) {
				assertEquals("A customer cannot have more than 3 open orders", e.getMessage());
			}
			

			
		} catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

}
