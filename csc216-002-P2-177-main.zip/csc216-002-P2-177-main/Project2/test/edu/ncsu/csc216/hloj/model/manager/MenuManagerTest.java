/**
 * 
 */
package edu.ncsu.csc216.hloj.model.manager;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.hloj.model.Customer;
import edu.ncsu.csc216.hloj.model.MenuItem;
import edu.ncsu.csc216.hloj.model.ModelException;
import edu.ncsu.csc216.hloj.model.Order;

/**
 * Test cases for MenuManager
 * @author Jakob Woodard
 *
 */
public class MenuManagerTest {

	/**
	 * Resets the menu manager to have no items before each test
	 */
	@Before
	public void resetManager() {
		MenuManager.getInstance().removeAllMenuItems();
		OrderManager.getInstance().removeAllOrders();
	}
	/**
	 * Test method for MenuManager()
	 */
	@Test
	public void testMenuManager() {
		MenuManager mm = MenuManager.getInstance();
		assertEquals(0, mm.getMenuItems().length);
	}
	
	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.manager.MenuManager#addMenuItem(edu.ncsu.csc216.hloj.model.MenuItem)}.
	 */
	@Test
	public void testAddMenuItem() {
		MenuManager mm = MenuManager.getInstance();
		assertEquals(0, mm.getMenuItems().length);
		
		try {
			MenuItem m = new MenuItem("Coffee", "Black", 1.5);
			MenuItem m2 = new MenuItem("Coffee", "Mocha", 1.0);
			
			
			mm.addMenuItem(m);
			assertEquals(mm.getMenuItem(0), m);
			mm.addMenuItem(m2);
			assertEquals(m, mm.getMenuItems()[1]);
			
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
		
		mm.removeAllMenuItems();
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.manager.MenuManager#removeMenuItem(int)}.
	 */
	@Test
	public void testRemoveMenuItem() {
		MenuManager mm = MenuManager.getInstance();
		assertEquals(0, mm.getMenuItems().length);
		
		try {
			MenuItem m = new MenuItem("Coffee", "Black", 1.5);
			MenuItem m2 = new MenuItem("Coffee", "Mocha", 1.0);
			Customer c = new Customer("First", "Last", "flast");
			Order o = new Order(1, c);
			o.addMenuItem(m);
			
			OrderManager om = OrderManager.getInstance();
			om.placeOrder(o);
			mm.addMenuItem(m);
			assertEquals(1, om.getOrders().length);
			assertEquals(m, om.getOrders()[0].getItems()[0].getMenuItem());
			
			try {
				mm.removeMenuItem(0);
				fail();
			}
			catch (ModelException e) {
				assertEquals("Cannot delete a menu item that is part of an open order", e.getMessage());
			}
			
			
			assertEquals(mm.getMenuItem(0), m);
			mm.addMenuItem(m2);
			assertEquals(m, mm.getMenuItems()[1]);
			assertEquals(2, mm.getMenuItems().length);
			
			mm.removeMenuItem(0);
			assertEquals(1, mm.getMenuItems().length);
			assertEquals(m, mm.getMenuItem(0));
			
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
		
		mm.removeAllMenuItems();
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.hloj.model.manager.MenuManager#editMenuItem(int, edu.ncsu.csc216.hloj.model.MenuItem)}.
	 */
	@Test
	public void testEditMenuItem() {
		MenuManager mm = MenuManager.getInstance();
		assertEquals(0, mm.getMenuItems().length);
		
		try {
			MenuItem m = new MenuItem("Coffee", "Black", 1.5);
			MenuItem m2 = new MenuItem("Coffee", "Mocha", 1.0);
			MenuItem m3 = new MenuItem("Pastery", "Muffin", 2.0);
			
			mm.addMenuItem(m);
			mm.addMenuItem(m2);

			assertEquals(mm.getMenuItem(0), m2);
			assertEquals(m, mm.getMenuItems()[1]);
			
			mm.editMenuItem(1, m3);
			assertEquals(m3, mm.getMenuItem(1));
			
		}
		catch (ModelException e) {
			fail("Unexpected ModelException");
		}
	}

}
