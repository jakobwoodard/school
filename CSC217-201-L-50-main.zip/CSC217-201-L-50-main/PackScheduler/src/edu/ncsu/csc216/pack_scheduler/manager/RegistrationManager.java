package edu.ncsu.csc216.pack_scheduler.manager;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;

import edu.ncsu.csc216.pack_scheduler.catalog.CourseCatalog;
import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.course.roll.CourseRoll;
import edu.ncsu.csc216.pack_scheduler.directory.FacultyDirectory;
import edu.ncsu.csc216.pack_scheduler.directory.StudentDirectory;
import edu.ncsu.csc216.pack_scheduler.user.Faculty;
import edu.ncsu.csc216.pack_scheduler.user.Student;
import edu.ncsu.csc216.pack_scheduler.user.User;
import edu.ncsu.csc216.pack_scheduler.user.schedule.Schedule;
/**
 * Class that handles registration for courses using the catalog and User classes
 * @author Jakob Woodard
 *
 */
public class RegistrationManager {
	
	/** Instance of a Registration manager */
	private static RegistrationManager instance;
	/** Course catalog being used */
	  private CourseCatalog courseCatalog = new CourseCatalog();
	  /** Student directory being used */
	private StudentDirectory studentDirectory = new StudentDirectory();
	/** Faculty directory being used */
	private FacultyDirectory facultyDirectory = new FacultyDirectory();
	/** Registrar doing inputs */
	  private Registrar registrar;
	  /** Current user of the Manager */
	   private User currentUser;
	/** Hashing algorithm */
	private static final String HASH_ALGORITHM = "SHA-256";
	/** File used that has properties for registrar */
	private static final String PROP_FILE = "registrar.properties";

	private RegistrationManager() {
		createRegistrar();
	}
	
	private void createRegistrar() {
		Properties prop = new Properties();
		
		try (InputStream input = new FileInputStream(PROP_FILE)) {
			prop.load(input);
			
			String hashPW = hashPW(prop.getProperty("pw"));
			
			registrar = new Registrar(prop.getProperty("first"), prop.getProperty("last"), prop.getProperty("id"), prop.getProperty("email"), hashPW);
		} catch (IOException e) {
			throw new IllegalArgumentException("Cannot create registrar.");
		}
	}
	
	private String hashPW(String pw) {
		try {
			MessageDigest digest1 = MessageDigest.getInstance(HASH_ALGORITHM);
			digest1.update(pw.getBytes());
			return new String(digest1.digest());
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalArgumentException("Cannot hash password");
		}
	}
	
	/**
	 * Gets the instance of the RegistrationManager, if it is not null, a RegistrationManager is not created.
	 * @return instance how many instances of RegistrationManager there are, null if none.
	 */
	public static RegistrationManager getInstance() {
		  if (instance == null) {
			instance = new RegistrationManager();
		}
		return instance;
	}
	
	/**
	 * Getter method for the course catalog
	 * @return courseCatalog for the RegistrationManager
	 */
	public CourseCatalog getCourseCatalog() {
		return courseCatalog;
	}
	
	/**
	 * Getter method for the student directory
	 * @return studentDirectory of the RegistrationManager
	 */
	public StudentDirectory getStudentDirectory() {
		return studentDirectory;
	}

	/**
	 * Method to check that the login information of a user matches the information that should be used to have a valid login
	 * @param id of the User
	 * @param password of the user
	 * @return true if all login fields match their valid inputs
	 * @throws IllegalArgumentException if there is no Hash Algorithm to get the instance of.
	 */
	public boolean login(String id, String password) {
		Student s = studentDirectory.getStudentById(id);
		Faculty f = facultyDirectory.getFacultyById(id);
		if (s != null) {	
			try {
				MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
				digest.update(password.getBytes());
				String localHashPW = new String(digest.digest());
				if (s.getPassword().equals(localHashPW)) {
					currentUser = s;
					return true;
				}
			} catch (NoSuchAlgorithmException e) {
				throw new IllegalArgumentException();
			}	
		}
		if (f != null) {
			try {
				MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
				digest.update(password.getBytes());
				String localHashPW = new String(digest.digest());
				if (f.getPassword().equals(localHashPW)) {
					currentUser = f;
					return true;
				}
			} catch (NoSuchAlgorithmException e) {
				throw new IllegalArgumentException();
			}	
		}
		
		if (registrar.getId().equals(id)) {
				MessageDigest digest;
			try {
			digest = MessageDigest.getInstance(HASH_ALGORITHM);
				digest.update(password.getBytes());
				String localHashPW = new String(digest.digest());
			if (registrar.getPassword().equals(localHashPW)) {
				currentUser = registrar;
					return true;
			}
			} catch (NoSuchAlgorithmException e) {
				throw new IllegalArgumentException();
			}
		}
		
		if (s == null) {
			throw new IllegalArgumentException("User doesn't exist.");
		}
			
				return false;
	}

	/**
	 * Makes the current user of the system to null
	 */
	public void logout() {
		currentUser = null; 
	}
	
	/**
	 * Getter method for the current user
	 * @return currentUser of the registrar
	 */
	public User getCurrentUser() {
		return currentUser;
	}
	
	/**
	 * Clears both the CoursecCatalog and the StudentDirectory
	 */
	public void clearData() {
		courseCatalog.newCourseCatalog();
		studentDirectory.newStudentDirectory();
		facultyDirectory.newFacultyDirectory();
	}
	
	/**
	 * Returns true if the logged in student can enroll in the given course.
	 * @param c Course to enroll in
	 * @return true if enrolled
	 */
	public boolean enrollStudentInCourse(Course c) {
	    if (!(currentUser instanceof Student)) {
	        throw new IllegalArgumentException("Illegal Action");
	    }
	    try {
	        Student s = (Student)currentUser;
	        CourseRoll roll = c.getCourseRoll();
	        
	        if (s.canAdd(c) && roll.canEnroll(s)) {
	            roll.enroll(s);
	            return true;
	        } 
	    } 
	    catch (Exception e) {
	        return false;
	    }
	    return false;
	}

	/**
	 * Returns true if the logged in student can drop the given course.
	 * @param c Course to drop
	 * @return true if dropped
	 */
	public boolean dropStudentFromCourse(Course c) {
	    if (!(currentUser instanceof Student)) {
	        throw new IllegalArgumentException("Illegal Action");
	    }
	    try {
	        Student s = (Student)currentUser;
	        for (int i = 0; i < s.getSchedule().getScheduledCourses().length; i++) {
	        	if (c.getName().equals(s.getSchedule().getScheduledCourses()[i][0])) {
	        		c.getCourseRoll().drop(s);
	        		return true;
	        	}
	        }
	        return false;
	    } 
	    catch (IllegalArgumentException e) {
	    	return false;
	    }
	}

	/**
	 * Resets the logged in student's schedule by dropping them
	 * from every course and then resetting the schedule.
	 */
	public void resetSchedule() {
	    if (!(currentUser instanceof Student)) {
	        throw new IllegalArgumentException("Illegal Action");
	    }
	    try {
	        Student s = (Student)currentUser;
	        Schedule schedule = s.getSchedule();
	        String [][] scheduleArray = schedule.getScheduledCourses();
	        for (int i = 0; i < scheduleArray.length; i++) {
	            Course c = courseCatalog.getCourseFromCatalog(scheduleArray[i][0], scheduleArray[i][1]);
	            c.getCourseRoll().drop(s);
	        }
	        schedule.resetSchedule();
	    } catch (IllegalArgumentException e) {
	        //do nothing 
	    }
	}
	
	/**
	 * Adds the specified course to the specified faculty's schedule
	 * @param c the course being added
	 * @param f the faculty adding the course
	 * @return true if the course is added to the faculty's schedule
	 */
	public boolean addFacultyToCourse(Course c, Faculty f) {
		if (currentUser != null && currentUser.equals(registrar)) {
			f.getSchedule().addCourseToSchedule(c);
			return true;
		}
		if (currentUser != null && !currentUser.equals(registrar) ) {
			throw new IllegalArgumentException("Invalid user");
		}
		return false;
	}
	
	/**
	 * Removes a given course from a faculty's schedule
	 * @param c the course being removed
	 * @param f the faculty who is having the course dropped
	 * @return true if the course is dropped
	 */
	public boolean removeFacultyFromCourse(Course c, Faculty f) {
		if (currentUser != null && currentUser.equals(registrar)) {
			f.getSchedule().removeCourseFromSchedule(c);
			return true;
		}
		if (currentUser != null && !currentUser.equals(registrar) ) {
			throw new IllegalArgumentException("Invalid user");
		}
		return false;
	}
	
	/**
	 * Resets the given faculty's schedule
	 * @param f the faculty whose schedule is being reset
	 */
	public void resetFacultySchedule(Faculty f) {
		if (currentUser != null && currentUser.equals(registrar)) {
			f.getSchedule().resetSchedule();
		}
		if (currentUser != null && !currentUser.equals(registrar) ) {
			throw new IllegalArgumentException("Invalid user");
		}
	}
	
	private static class Registrar extends User {
		/**
		 * Create a registrar user
		 * @param firstName of the User
		 * @param lastName of the User
		 * @param id of the User
		 * @param email of the User
		 * @param hashPW of the User
		 */
		public Registrar(String firstName, String lastName, String id, String email, String hashPW) {
			super(firstName, lastName, id, email, hashPW);
		}
	}
	
	/**
	 * Returns the full faculty directory
	 * @return facultyDirectory the full faculty directory
	 */
	public FacultyDirectory getFacultyDirectory() {
		return facultyDirectory;
	}
}
